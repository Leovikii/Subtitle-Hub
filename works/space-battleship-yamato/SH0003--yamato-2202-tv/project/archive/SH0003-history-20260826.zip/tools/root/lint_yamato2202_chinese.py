from __future__ import annotations

import re
import sys

from audit_yamato2202_chinese_language import effective_events


PATTERN = re.compile(
    r"继绩|应读|住何|送些|继绫|特蓍|份子|即时|大田|继续向前前进|"
    r"操舵|航宙|空母|宙雷|幻影|幻觉信息|加密狗|一尉|发进|格纳库|"
    r"复横阵|船速|侧上层|加军|俩人|全能的大帝|加速度质量|"
    r"不作出选择|有何贵干|清晰地说|进行.{0,8}(?:作业|操作|处理)"
    r"|毕竞|大轴|,|一副烈药|单纯的被|避运动|有很大的机会它|"
    r"加特蒂斯|直援|这么单纯的|还有缺乏|既然是送样|么……|"
    r"信息的源头|一大和号|最糟糕的情况下|正确的才是|不能算是错误|"
    r"有着.{0,12}(?:关系|意志|目的|能力|优势|弱点|责任)|"
    r"迪斯拉|戴斯拉|库劳|克劳乌|[一二三]尉|格纳库|航宙|复横|发进|"
    r"辛亏|其它|座手旁观|即复杂|大加|大轴|佐藤医生|与加特兰蒂斯君|“银河”"
)

sys.stdout.reconfigure(encoding="utf-8")


for episode in range(1, 27):
    for event in effective_events(episode):
        if PATTERN.search(event["effective"]):
            print(f"EP{episode:02d} {event['start_raw']}\t{event['effective']}")
