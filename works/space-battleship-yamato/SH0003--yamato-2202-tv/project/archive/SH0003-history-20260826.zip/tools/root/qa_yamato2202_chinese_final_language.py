from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / "build" / "yamato2202" / "tools"
sys.path.insert(0, str(TOOLS))

from align_yamato2202 import read_ass

sys.stdout.reconfigure(encoding="utf-8")

root = Path(sys.argv[1])
files = sorted(root.glob("*.ass"))
tag_re = re.compile(r"\{[^}]*\}")
malformed_re = re.compile(
    r"继绩|应读|住何|送些|继绫|特蓍|毕竞|一副烈药|单纯的被|"
    r"继续向前前进|进行避运动|大轴|加特蒂斯|辛亏|座手旁观|即复杂|"
    r"的的|又还|有很大的机会它|佐藤医生"
)
banned_terms = [
    "加特兰提斯", "加密拉斯", "迪斯拉", "戴斯拉", "特瑞莎",
    "克劳乌斯", "库劳乌斯", "格纳库", "航宙母舰", "复横阵", "一尉", "三尉",
]

errors: list[str] = []
warnings: list[str] = []
counts = {"files": len(files), "chinese_main": 0}
all_text: list[str] = []
long_lines: list[tuple[int, str, str]] = []

for path in files:
    episode = int(re.search(r"S02E(\d{2})", path.name).group(1))
    events = [event for event in read_ass(path) if event["style"] == "DefaultCN-2202"]
    counts["chinese_main"] += len(events)
    previous = None
    for event in events:
        text = tag_re.sub("", event["text"]).replace(r"\N", " ").strip()
        all_text.append(text)
        label = f"EP{episode:02d} {event['start_raw']}"
        long_lines.append((len(text), label, text))
        if malformed_re.search(text):
            errors.append(f"{label}: malformed Chinese: {text}")
        if re.search(r"[A-Za-z\u4e00-\u9fff][,;][A-Za-z\u4e00-\u9fff]", text):
            errors.append(f"{label}: ASCII punctuation in Chinese: {text}")
        if text.count("“") != text.count("”"):
            errors.append(f"{label}: unbalanced Chinese quotes: {text}")
        if previous and text == previous["text"] and event["start"] - previous["end"] < 0.3:
            warnings.append(f"{label}: adjacent repeated cue: {text}")
        previous = {"text": text, "end": event["end"]}

joined = "\n".join(all_text)
for term in banned_terms:
    if term in joined:
        errors.append(f"banned terminology remains: {term}")

required_terms = ["加特兰蒂斯", "加米拉斯", "德斯拉", "特蕾莎", "克劳斯·基曼", "银河号"]
for term in required_terms:
    if term not in joined:
        errors.append(f"required unified terminology missing: {term}")

counts["errors"] = len(errors)
counts["warnings"] = len(warnings)
print(json.dumps({
    "stats": counts,
    "errors": errors,
    "warnings": warnings,
    "longest_lines": [
        {"length": length, "cue": label, "text": text}
        for length, label, text in sorted(long_lines, reverse=True)[:20]
    ],
}, ensure_ascii=False, indent=2))
if errors:
    raise SystemExit(1)
