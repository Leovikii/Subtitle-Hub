from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUILD_ROOT = ROOT / "build" / "yamato2202"
TOOLS = BUILD_ROOT / "tools"
sys.path.insert(0, str(TOOLS))

from align_yamato2202 import read_ass

sys.stdout.reconfigure(encoding="utf-8")

root = BUILD_ROOT / "work" / "yamato2202_review"
polish = json.loads(
    (BUILD_ROOT / "data" / "yamato2202_chinese_polish.json")
    .read_text(encoding="utf-8")
)
tag_re = re.compile(r"\{[^}]*\}")


def visible(text: str) -> str:
    return tag_re.sub("", text).replace(r"\N", " ").strip()


for episode, replacements in polish.items():
    source = next(path for path in root.glob("*.ass") if f"[{episode}][CHS]" in path.name)
    by_start = {event["start_raw"]: visible(event["text"]) for event in read_ass(source)}
    for start, replacement in replacements.items():
        before = by_start[start]
        after = visible(replacement)
        if (len(before) <= 3 and len(after) >= 8) or (len(before) >= 12 and len(after) <= 2):
            print(f"EP{episode} {start}\t{before}\t=>\t{after}")
