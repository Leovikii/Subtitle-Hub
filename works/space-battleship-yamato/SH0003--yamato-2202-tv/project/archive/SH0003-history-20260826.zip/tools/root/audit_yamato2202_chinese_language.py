from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUILD_ROOT = ROOT / "build" / "yamato2202"
TOOLS = BUILD_ROOT / "tools"
sys.path.insert(0, str(TOOLS))

from align_yamato2202 import read_ass
from build_yamato2202_bilingual import (
    DIALOGUE_SUPPRESS_OVERRIDES,
    GLOBAL_REPLACEMENTS,
    apply_global,
)


SOURCE_ROOT = BUILD_ROOT / "work" / "yamato2202_review"
CORRECTIONS = json.loads(
    (BUILD_ROOT / "data" / "yamato2202_corrections.json")
    .read_text(encoding="utf-8")
)
POLISH = json.loads(
    (BUILD_ROOT / "data" / "yamato2202_chinese_polish.json")
    .read_text(encoding="utf-8")
)
TAG_RE = re.compile(r"\{[^}]*\}")


def source_file(episode: int) -> Path:
    marker = f"[{episode:02d}][CHS]"
    return next(path for path in SOURCE_ROOT.glob("*.ass") if marker in path.name)


def effective_events(episode: int) -> list[dict]:
    corrections = dict(CORRECTIONS.get(f"{episode:02d}", {}))
    corrections.update(POLISH.get(f"{episode:02d}", {}))
    result = []
    for event in read_ass(source_file(episode)):
        if event["style"] != "DefaultCN-2202":
            continue
        if event["start_raw"] in DIALOGUE_SUPPRESS_OVERRIDES.get(episode, set()):
            continue
        text = corrections.get(event["start_raw"], event["text"])
        text = apply_global(text)
        visible = TAG_RE.sub("", text).replace(r"\N", " ").strip()
        if visible:
            result.append({**event, "effective": visible})
    return result


def main(episodes: list[int]) -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    for episode in episodes:
        print(f"=== EP{episode:02d} ===")
        for event in effective_events(episode):
            print(f"{event['start_raw']}\t{event['effective']}")


if __name__ == "__main__":
    main([int(value) for value in sys.argv[1].split(",")])
