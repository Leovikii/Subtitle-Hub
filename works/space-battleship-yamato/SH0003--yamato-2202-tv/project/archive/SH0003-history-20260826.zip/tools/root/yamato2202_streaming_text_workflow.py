from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path


TAG_RE = re.compile(r"\{[^}]*\}")
EP_RE = re.compile(r"S02E(\d{2})")
HAN_RE = re.compile(r"[\u3400-\u9fff]")
ASCII_ALNUM_RE = re.compile(r"[A-Za-z0-9]")
FORBIDDEN_RE = re.compile(r"[，。、；]")


def episode(path: Path) -> int:
    match = EP_RE.search(path.name)
    if not match:
        raise ValueError(f"Cannot read episode number from {path.name}")
    return int(match.group(1))


def visible(text: str) -> str:
    return TAG_RE.sub("", text).replace(r"\N", " ").strip()


def parse_dialogue(line: str) -> list[str] | None:
    if not line.startswith("Dialogue:"):
        return None
    fields = line.split(":", 1)[1].lstrip().split(",", 9)
    return fields if len(fields) == 10 else None


def read_dialogues(path: Path) -> list[dict]:
    events = []
    style_occurrence: dict[str, int] = {}
    for line_no, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        fields = parse_dialogue(line)
        if fields is None:
            continue
        layer, start, end, style, name, ml, mr, mv, effect, text = fields
        index = style_occurrence.get(style, 0)
        style_occurrence[style] = index + 1
        events.append({
            "line_no": line_no,
            "index": index,
            "layer": layer,
            "start": start,
            "end": end,
            "style": style,
            "name": name,
            "margin_l": ml,
            "margin_r": mr,
            "margin_v": mv,
            "effect": effect,
            "raw_text": text,
            "text": visible(text),
        })
    return events


def structural_record(path: Path) -> dict:
    events = read_dialogues(path)
    structure = [
        [e[k] for k in ("layer", "start", "end", "style", "name", "margin_l", "margin_r", "margin_v", "effect")]
        for e in events
    ]
    encoded = json.dumps(structure, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return {
        "episode": episode(path),
        "file": path.name,
        "events": len(events),
        "chinese_main": sum(e["style"] == "DefaultCN-2202" for e in events),
        "japanese_main": sum(e["style"] in {"JapaneseAux", "JapaneseAuxTop"} for e in events),
        "structure_sha256": hashlib.sha256(encoded).hexdigest().upper(),
        "file_sha256": hashlib.sha256(path.read_bytes()).hexdigest().upper(),
    }


def snapshot(root: Path, output: Path) -> None:
    files = sorted(root.glob("*.ass"), key=episode)
    if len(files) != 26:
        raise RuntimeError(f"Expected 26 ASS files, found {len(files)}")
    records = [structural_record(path) for path in files]
    payload = {
        "root": str(root.resolve()),
        "files": records,
        "totals": {
            "files": len(records),
            "events": sum(item["events"] for item in records),
            "chinese_main": sum(item["chinese_main"] for item in records),
            "japanese_main": sum(item["japanese_main"] for item in records),
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload["totals"], ensure_ascii=False))


def catalogue(root: Path, output: Path) -> None:
    payload: dict[str, list[dict]] = {}
    for path in sorted(root.glob("*.ass"), key=episode):
        ep = f"{episode(path):02d}"
        items = []
        for event in read_dialogues(path):
            if event["style"] != "DefaultCN-2202":
                continue
            text = event["text"]
            items.append({
                "index": event["index"],
                "start": event["start"],
                "end": event["end"],
                "text": text,
                "length": len(text),
                "forbidden": "".join(sorted(set(FORBIDDEN_RE.findall(text)))),
            })
        payload[ep] = items
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"catalogued={sum(map(len, payload.values()))}")


def apply_overrides(source: Path, target: Path, overrides_path: Path) -> None:
    overrides = json.loads(overrides_path.read_text(encoding="utf-8"))
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    changed = 0
    for source_path in sorted(source.glob("*.ass"), key=episode):
        ep = f"{episode(source_path):02d}"
        by_index = {int(item["index"]): item for item in overrides.get(ep, [])}
        style_occurrence: dict[str, int] = {}
        out = []
        for line in source_path.read_text(encoding="utf-8-sig").splitlines():
            fields = parse_dialogue(line)
            if fields is None:
                out.append(line)
                continue
            style = fields[3]
            index = style_occurrence.get(style, 0)
            style_occurrence[style] = index + 1
            item = by_index.get(index) if style == "DefaultCN-2202" else None
            if item is not None:
                expected = (item["start"], item["end"], item["before"])
                actual = (fields[1], fields[2], visible(fields[9]))
                if actual != expected:
                    raise RuntimeError(f"EP{ep} index={index}: expected {expected!r}, got {actual!r}")
                if TAG_RE.search(fields[9]) or r"\N" in fields[9]:
                    raise RuntimeError(f"EP{ep} index={index}: refusing tagged or multiline main cue")
                fields[9] = item["after"]
                line = "Dialogue: " + ",".join(fields)
                changed += 1
            out.append(line)
        target_path = target / source_path.name
        target_path.write_text("\ufeff" + "\n".join(out) + "\n", encoding="utf-8")
    print(f"changed={changed}")


def verify(before_manifest: Path, root: Path) -> None:
    baseline = json.loads(before_manifest.read_text(encoding="utf-8"))
    expected = {item["episode"]: item for item in baseline["files"]}
    current = [structural_record(path) for path in sorted(root.glob("*.ass"), key=episode)]
    errors = []
    for item in current:
        old = expected.get(item["episode"])
        if old is None:
            errors.append(f"unexpected episode {item['episode']}")
            continue
        for key in ("file", "events", "chinese_main", "japanese_main", "structure_sha256"):
            if item[key] != old[key]:
                errors.append(f"EP{item['episode']:02d} {key}: {old[key]} -> {item[key]}")
    if len(current) != len(expected):
        errors.append(f"file count: {len(expected)} -> {len(current)}")
    forbidden = []
    colons = []
    composites = []
    malformed_ellipsis = []
    malformed_dash = []
    spacing = []
    mixed_spacing = []
    quote_balance = []
    hard_breaks = []
    lengths = []
    for path in sorted(root.glob("*.ass"), key=episode):
        ep = episode(path)
        for event in read_dialogues(path):
            if event["style"] != "DefaultCN-2202":
                continue
            text = event["text"]
            lengths.append(len(text))
            if FORBIDDEN_RE.search(text):
                forbidden.append(f"EP{ep:02d} {event['start']} {text}")
            if "：" in text:
                colons.append(f"EP{ep:02d} {event['start']} {text}")
            if re.search(r"[？！!?]{2,}", text):
                composites.append(f"EP{ep:02d} {event['start']} {text}")
            if re.search(r"(?<!…)…(?!…)", text):
                malformed_ellipsis.append(f"EP{ep:02d} {event['start']} {text}")
            if re.search(r"(?<!—)—(?!—)", text):
                malformed_dash.append(f"EP{ep:02d} {event['start']} {text}")
            if "  " in text or "　" in text or re.search(r"\s+[？！……——]", text):
                spacing.append(f"EP{ep:02d} {event['start']} {text}")
            if re.search(r"(?:[\u3400-\u9fff][A-Za-z0-9]|[A-Za-z0-9][\u3400-\u9fff])", text):
                mixed_spacing.append(f"EP{ep:02d} {event['start']} {text}")
            if text.count("“") != text.count("”") or text.count("‘") != text.count("’"):
                quote_balance.append(f"EP{ep:02d} {event['start']} {text}")
            if r"\N" in event["raw_text"] or r"\n" in event["raw_text"]:
                hard_breaks.append(f"EP{ep:02d} {event['start']} {text}")
    errors.extend(forbidden)
    errors.extend(colons)
    errors.extend(composites)
    errors.extend(malformed_ellipsis)
    errors.extend(malformed_dash)
    errors.extend(spacing)
    errors.extend(mixed_spacing)
    errors.extend(quote_balance)
    errors.extend(hard_breaks)
    result = {
        "files": len(current),
        "chinese_main": sum(item["chinese_main"] for item in current),
        "japanese_main": sum(item["japanese_main"] for item in current),
        "structure_errors": len(errors),
        "forbidden_punctuation": len(forbidden),
        "ordinary_dialogue_colons": len(colons),
        "composite_question_exclamation": len(composites),
        "malformed_ellipsis": len(malformed_ellipsis),
        "malformed_dash": len(malformed_dash),
        "spacing_errors": len(spacing),
        "mixed_spacing_errors": len(mixed_spacing),
        "quote_balance_errors": len(quote_balance),
        "hard_line_breaks": len(hard_breaks),
        "longer_than_24": sum(value > 24 for value in lengths),
        "longer_than_28": sum(value > 28 for value in lengths),
        "maximum_length": max(lengths, default=0),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if errors:
        print("\n".join(errors[:100]))
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    snap = sub.add_parser("snapshot")
    snap.add_argument("root", type=Path)
    snap.add_argument("output", type=Path)
    cat = sub.add_parser("catalogue")
    cat.add_argument("root", type=Path)
    cat.add_argument("output", type=Path)
    apply_cmd = sub.add_parser("apply")
    apply_cmd.add_argument("source", type=Path)
    apply_cmd.add_argument("target", type=Path)
    apply_cmd.add_argument("overrides", type=Path)
    check = sub.add_parser("verify")
    check.add_argument("baseline", type=Path)
    check.add_argument("root", type=Path)
    args = parser.parse_args()
    if args.command == "snapshot":
        snapshot(args.root, args.output)
    elif args.command == "catalogue":
        catalogue(args.root, args.output)
    elif args.command == "apply":
        apply_overrides(args.source, args.target, args.overrides)
    elif args.command == "verify":
        verify(args.baseline, args.root)


if __name__ == "__main__":
    main()
