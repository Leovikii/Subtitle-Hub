from __future__ import annotations

import sys

from audit_yamato2202_chinese_language import effective_events

sys.stdout.reconfigure(encoding="utf-8")

text = "\n".join(
    event["effective"]
    for episode in range(1, 27)
    for event in effective_events(episode)
)

terms = [
    "加特兰蒂斯", "加特兰提斯", "加米拉斯", "加密拉斯",
    "德斯拉", "迪斯拉", "戴斯拉", "特蕾莎", "特瑞莎",
    "克劳斯", "克劳乌斯", "库劳乌斯", "银河号", "“银河”", "银河舰",
    "航宙", "格纳库", "一尉", "二尉", "三尉", "复横阵", "发进",
    "幻影", "幻象", "幻觉信息", "操舵", "空母", "宙雷",
]

for term in terms:
    count = text.count(term)
    if count:
        print(f"{term}\t{count}")
