from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from yamato2202_streaming_text_workflow import episode, read_dialogues


COLON_REWRITES = {
    "攻击目标：加特兰蒂斯舰队": "攻击目标是加特兰蒂斯舰队",
    "识别信号确认：第二护卫驱逐舰队所属": "识别信号确认 第二护卫驱逐舰队所属",
    "我奉劝贵方：不要再玩火": "我奉劝贵方 不要再玩火",
    "再重复一遍：大和号的叛乱嫌疑已经解除": "再重复一遍 大和号的叛乱嫌疑已经解除",
    "但在那之前，我想清楚地告诉他：我就在这里": "但在那之前 我想明确告诉他 我就在这里",
    "转告对方：“祝贵舰一切顺利”": "转告对方“祝贵舰一切顺利”",
    "目标：修特拉巴泽内核部分！": "目标是修特拉巴泽内核部分！",
    "通知全舰：严禁把它们放出采集瓶": "通知全舰 严禁把它们放出采集瓶",
    "基准航向：特蕾莎特": "基准航向 特蕾莎特",
    "大帝有令：“务必肃清……”，米尔君": "大帝有令“务必肃清……” 米尔君",
    "所有种族的生命都有同一个根本目的：繁衍": "所有种族的生命都有同一根本目的 繁衍",
    "我想请教德斯拉总统：你来这里究竟想得到什么？": "请问德斯拉总统 你来这里究竟想得到什么？",
    "通知大和号全体乘员：弃舰！": "通知大和号全体乘员 弃舰！",
    "型号：佐达。最新型人造士兵，能通过感应波与他人精神相连": "型号 佐达 最新型人造士兵 能通过感应波与他人精神相连",
    "增幅率：800万TPA": "增幅率 800 万 TPA",
    "误差修正：20、15、10": "误差修正 20 15 10",
}


# Exact, context-reviewed condensations only.  Broad grammatical replacement
# is deliberately avoided because the approved scope forbids meaning loss.
CONDENSATIONS: dict[str, str] = {
    "只有一艘小船 却拼命想要阻止加特兰蒂斯战列舰坠落的地球人……": "那个地球人只凭一艘小船 就想阻止加特兰蒂斯巨舰……",
    "真田先生那边传过来的关于“时间断层”的资料 大家都已经看过了": "真田先生传来的“时间断层”资料 大家都看过了",
    "我们相信 即使我们 4 人缺席 大和号也一定能成功完成本次航行！": "即使我们 4 人缺席 大和号也一定能完成这次航行！",
    "非常抱歉 波动核心的更换作业还需要大约 5 个小时才能完成": "抱歉 更换波动线圈还需约 5 小时",
    "三年前 得知伊斯坎达尔向地球伸出援手时 我们不也都心怀感激吗？": "三年前伊斯坎达尔援助地球时 我们不也很感激吗？",
    "这群去过伊斯坎达尔的家伙 看样子真的是已经脱离现实太久了啊": "这些去过伊斯坎达尔的家伙 看来真是脱离现实太久了",
    "“Asteroid Ship”么 就凭这种“发霉”的陈年旧物……": "Asteroid Ship？这种发霉的老古董……",
    "你的意思是 司令部这么做 是考虑到加米拉斯侧的想法么？不会吧？": "你是说司令部在顾虑加米拉斯？不会吧？",
    "尽管如此 却仍然决定“弃眼前即将溺死之人于不顾” 这实在太矛盾了": "尽管如此 却让我们对眼前的落水者见死不救 太矛盾了",
    "对遇险的同胞见死不救 无论地球人还是加米拉斯人都做不到吧？": "地球人与加米拉斯人都无法对遇险同胞见死不救吧？",
    "修复需要两小时 这期间 冲击加农和波动防护罩都无法使用……": "修复需两小时 期间冲击加农和波动防护罩都无法使用……",
    "“眼前即将溺死之人都无法拯救” 必然也无法处理宇宙中的危机": "连眼前的落水者都救不了 又如何应对宇宙危机",
    "哥哥他说过 只要大和号能过来 像这种家伙 三两下就收拾掉了": "哥哥说过 只要大和号来了 这种家伙三两下就能收拾掉",
    "COSMO TIGER 队 在本舰再度联系你们之前请维持待机状态": "COSMO TIGER 队 原地待命 等候本舰联络",
    "如果有什么事情能够证明“地球人不全是这样的” 我就会想要去做": "如果能证明地球人并非全都如此 我就愿意去做",
    "可是……大家也都还年轻 或许真的还需要一位可以依靠的大人呢": "可是大家还年轻 或许真需要一位可以依靠的大人",
    "此前收到特蕾莎特的求救信号时 我们都看见了集体幻象 对吧？": "收到特蕾莎特的求救信号时 我们都看见了幻象 对吧？",
    "话说回来 特蕾莎特星在我们加米拉斯人的历史上也是最大的谜团": "特蕾莎特星也是加米拉斯史上最大的谜团之一",
    "您设计的“让我们与大和号相遇”计划 没想到会以这种方式实现……": "您让我们与大和号相遇的计划 竟以这种方式实现……",
    "现在的情况 不得不暂时分别 虽然我是搞不懂为什么会变成这样": "虽然不明白为何会这样 但我们现在不得不暂时分别",
    "如果真的是这样 为何他们在播种时要执着于维持“人”的形态？": "如果真是这样 为何播种时还要执着于人的形态？",
    "就是爱啊……就是因为爱人会去赴死 星球会崩坏 宇宙也会湮灭": "就是爱……因爱而赴死 星球崩坏 宇宙湮灭",
    "在这 3 艘军舰上我们都已经提前将由尸体制成的“复生体”混了进去": "事先在这 3 艘军舰上混入了以尸体制成的复生体",
    "这 3 艘舰都将失去其轮机 最后与行星崩坏的命运一起走向终结": "这 3 艘舰都将失去引擎 与行星一同毁灭",
    "无论让我背负何种罪业……甚至一生都无法偿清的罪业……我都要……": "无论背负多重甚至毕生难偿的罪业 我都要……",
    "即使是被特蕾莎所召唤之船——宇宙战舰大和号您也仍这么认为？": "即使是特蕾莎召唤的宇宙战舰大和号 您也这么认为？",
    "虽然他一直表现得很坚强 但我们都知道他的内心其实是很纤细的": "他虽然总装得坚强 其实内心很细腻",
    "你也应该知道吧！即使是在真空的宇宙中 人也能嗅到死亡的气息！": "你也知道吧！即使在真空的宇宙中 人也能嗅到死亡！",
    "又出现了！从特蕾莎特星上再次发出了“Cosmo Wave”": "又来了！特蕾莎特再次发出 Cosmo Wave",
    "即便是违反大帝的军令 死后受到地狱之火的炙烤我们也必须……": "即使违抗大帝军令 死后遭地狱烈火焚烧 我们也必须……",
    "不 我只是说到目前为止 我们发现它的某些性质与反物质相似而已": "不 只是发现它有类似反物质的表现",
    "18 秒后 1 点钟又 16 分的方向 敌人的包围网会出现 6 秒的缺口": "18 秒后 1 点 16 分方向会出现持续 6 秒的缺口",
    "波动引擎从真空汲取无限能量 若继续吸收这些粒子并转换能量……": "波动引擎从真空汲取无限能量 若继续吸收并转化这些粒子……",
    "看起来对加特兰蒂斯人来说 你和佐达大帝一样都是很特殊的存在": "你和佐达大帝一样 都是加特兰蒂斯人中的特殊存在",
    "我猜 随着距离缩短 Cosmo Wave 的通信状态也发生了变化": "我想随着距离缩短 Cosmo Wave 也发生了变化",
    "整个空间都会燃烧起来 无论大和号还是大帝托付给我的舰队……": "整个空间都会燃烧 大和号和大帝托付给我的舰队也……",
    "这是……正在接近我舰的波动能量正与这个空间碰撞 产生了冲击波": "接近我舰的波动能量正与空间碰撞 产生冲击波",
    "米尔君 空间崩溃后 你的 Cosmo Wave 感知也会恢复 不该高兴吗？": "米尔君 空间崩溃后 Cosmo Wave 恢复了 你不高兴吗？",
    "可是古代君……代理舰长说 现在的大和号只有老爹您才适合当舰长": "可是代理舰长说 现在只有老爹您适合担任大和号舰长",
    "我们现在已经与米尔阁下失去联络 就算是再珍贵的标本 也……": "如今我们已与米尔阁下失联 即便是再珍贵的标本也……",
    "特蕾莎所召唤之船的故乡 已注定灭亡的可悲行星 就由吾等来……": "特蕾莎召唤之船的故乡 那颗注定毁灭的可悲星球 由吾等……",
    "大和号……扰乱那个人的内心 给我们加特兰蒂斯带来灾厄的不祥之船": "大和号……扰乱那个人的心 为加特兰蒂斯带来灾厄的不祥之船",
    "懂了么？诺尔 在传承的过程中并没有“爱”这种不合理的感情掺杂其中": "懂了吗 诺尔 其中并不存在爱这种不合理的感情",
    "我养育并锻炼你 只为让“戈兰德”这一存在继续效忠加特兰蒂斯帝国": "我养育并锻炼你 只为让戈兰德继续效忠加特兰蒂斯帝国",
    "你即将迎来初战 继承戈兰德之名 成为新一代诺尔的日子也不远了": "你即将迎来初战 继承戈兰德之名 成为新诺尔的日子也不远了",
    "“在第十一行星会合 再调查修特拉巴泽”这就是原定计划 对吧？": "在第十一行星会合并调查修特拉巴泽 这才是原定计划吧？",
    "也就是说 任何人都可能冒充桂木透子 哪怕冒充者并非地球人……": "也就是说任何人都能冒充桂木透子 哪怕并非地球人……",
    "根据特蕾莎通过 Cosmo Wave 传来的数据 敌军正在搬运最后一块岩板": "特蕾莎的数据显示 敌军正在搬运最后一块岩板",
    "先用跃迁推进器 把 Cosmo TigerⅡ与机动甲胄突击队传送到这里": "先用跃迁推进器 将 Cosmo TigerⅡ和机动甲胄突击队送到这里",
    "大和号跳出跃迁后立即掉头 180 度 以波动炮粉碎岩板 封锁敌导弹舰队": "大和号跃迁后立即转向 180 度 用波动炮粉碎岩板 封锁敌导弹舰队",
    "这是与特蕾莎特周围的重力场发生干涉 在我舰附近形成了乱流……": "受特蕾莎特周围重力场干扰 我舰附近形成了乱流……",
    "代理舰长！如果想要一击摧毁敌舰队 现在的位置就是最佳射击点": "代理舰长 若想一击摧毁敌舰队 这里就是最佳射击点",
    "大和号的波动炮摧毁了半数中继系统 目前只能达到这种命中精度": "波动炮摧毁了半数中继系统 目前只能达到这种精度",
    "基曼中尉 若真如此 敌军武器的控制系统应与加米拉斯原型相同": "基曼中尉 若真如此 敌军控制系统应沿用加米拉斯原型",
    "她生活在可以看见时间的世界里 而我们正处于这高维世界的入口": "她生活在时间可视的世界 而我们正站在这个世界的入口",
    "在根除这宇宙间所有类人生物之前 他们的进击想必不会停下来吧？": "他们的进击不会停止 直到根除宇宙中所有人类",
    "这不仅是为了地球的居民 更是为了生存在这个宇宙中的所有生命": "不只为了地球 更为了宇宙中的所有生命",
    "与重力有类似之处的它 通过连接事物 穿越维度的障壁而发挥作用": "它如同重力 连接事物 穿越维度障壁发挥作用",
    "你以为凭你手上的东西 就能吓倒一个已经在鬼门关走过一遭的人？": "你以为凭那东西就能吓倒一个死过一次的人？",
    "竟被托付了叔父统一的整个加米拉斯 以及那过于沉重的秘密……": "叔父统一的加米拉斯和那个沉重的秘密 都托付给了我……",
    "为了那些三年来一直反对民主化改革 企图恢复旧制的德斯拉派？": "为了那些反对三年民主化改革 企图恢复旧制的德斯拉派？",
    "如果顺利 我会将特蕾莎星毫发无损地交给大帝 但作为交换条件……": "若一切顺利 我会将特蕾莎特完整献给大帝 但作为交换……",
    "寻找或创造适合加米拉斯人居住的行星 加特兰蒂斯或许能做到……": "加特兰蒂斯或许能找到或创造适合加米拉斯人居住的行星……",
    "占领行星的加特兰蒂斯军已被肃清 如今特蕾莎特由我方舰队控制": "占领特蕾莎特的加特兰蒂斯军已肃清 目前由我方舰队控制",
    "“为了打倒大和号而丧失心智 甚至不惜放弃首都巴雷拉斯的独裁者”": "为打倒大和号而失去理智 甚至牺牲首都巴雷拉斯的独裁者",
    "但我知道 那是为拯救加米拉斯与伊斯坎达尔所作的无奈选择……": "但我知道 那是为拯救加米拉斯和伊斯坎达尔的无奈选择……",
    "若特蕾莎真能被带离这里 我们就不得不怀疑你背叛了我们 不过……": "若特蕾莎能被带离这里 我们就得怀疑你背叛了我们 不过……",
    "这么说 你登上大和号并一直引导我们来到特蕾莎特星也是为了……": "所以你登上大和号 并一路引导我们前往特蕾莎特也是为了……",
    "这里是古代 我们这边丢失了基曼机的信号 你们那边能捕捉到吗？": "这里是古代 我们失去基曼机信号 你们能捕捉到吗？",
    "基曼中尉虽然也在协助我们 但看起来这并不是能轻易除去的东西": "基曼中尉也在协助 但这东西似乎无法轻易除去",
    "我们也不清楚 看着刚制造出的幼体 不知为何就变成了这样……": "不清楚 只是看到刚制造出的幼体 不知为何就变成这样……",
    "我知道你想说什么 但“回转波动炮”可能是对抗白色彗星的王牌": "我知道 但回转波动炮可能是对抗白色彗星的王牌",
    "如果因为高维生命体的干涉 而导致我们生存的维度失去稳定的话……": "如果高维生命体的干涉使我们的维度失去存在基础……",
    "观测到敌 Calakulm 级战舰已经超过百艘 数量仍在增加中": "观测到敌 Calakulm 级战舰超过百艘 数量仍在增加",
    "依靠绝对数量优势直接突破中央吗……与银河号搭载的 AI 预测一致": "凭绝对数量优势突破中央吗……与银河号 AI 预测一致",
    "舰载机方面 已完成对“COSMO TIGERⅡ”的武器换装": "舰载机已完成 COSMO TIGERⅡ换装",
    "巴 巴尔泽阁下 数个方位均出现敌增援部队 数量是以前的一倍以上": "巴 巴尔泽阁下 多个方位出现敌援军 数量超过此前一倍",
    "连永仓也……还有古代 森雪船务长 以及那条加米拉斯的狗……": "连永仓也……还有古代 森船务长和那个加米拉斯混蛋……",
    "但即便如此 为了超越有丰富经验的人类船员的判断 仍需要时间": "但即便如此 要超越经验丰富的人类船员仍需时间",
    "接下来你们会被分配到第一 第二舰桥 所有操作都将受到跟踪记录": "你们将分配到第一 第二舰桥 所有操作都会被记录",
    "大和号已经沉没 为了人类延续 必须让大和号的基因在这艘船上……": "大和号已沉没 为延续人类 必须将它的基因留在这艘船上……",
    "不只波动炮 连使用普通武器都会引发 CRS 系统异常 原因尚未查明": "波动炮与普通武器都会引发 CRS 系统异常 原因不明",
    "将它们散布到敌舰队核心 再利用银河号的 CRS 系统增幅 使其失控": "将它们撒入敌舰队核心 用银河号 CRS 系统增幅至失控",
    "但即使 AI 再先进 要在这种情况下把无人机编队引入敌舰队中心也太……": "即使 AI 再先进 此时要把无人机送入敌舰队中心也……",
    "大和号的诸位 我是冲田舰长 我们终于抵达了目的地伊斯坎达尔": "大和号诸位 我是冲田舰长 我们终于抵达伊斯坎达尔",
    "这可是轻易就控制了分析士的家伙 怎么能这样把它带回大和号呢？": "这家伙轻易控制了分析士 怎么能把它带回大和号？",
    "“加特兰蒂斯不受爱束缚 因此纯粹 能够建立公平和平的社会”": "加特兰蒂斯不受爱束缚 因而纯粹 能建立公平和平的社会",
    "如果温柔与人性会使人失去求生意志 那即使抛弃它们 我也要……": "如果温柔与人性会害死人 即使抛弃它们我也要……",
    "演奏毁灭之物 支配加特兰蒂斯的关键 最大的枷锁 其名为哥雷姆": "演奏毁灭之物 加特兰蒂斯统治的关键与最大枷锁 名为哥雷姆",
    "我们一定要存续下去！不论付出怎样的牺牲 不论身体会变成怎样！": "活下去！无论付出何种牺牲 变成什么模样！",
    "没错 如果是“回转波动炮” 说不定能撕破彗星都市的防御力场": "没错 回转波动炮或许能撕破彗星都市的防御力场",
    "为了拯救加米拉斯 您即使是屈尊于加特兰蒂斯也……我说的没错吧？": "为了拯救加米拉斯 您甚至不惜求助加特兰蒂斯 对吧？",
    "即使他们一时遵守了诺言 但他们终究是与我们不可共存的存在！": "即使他们暂时守约 也终究无法与我们共存！",
    "我舰“诺伊·迪乌斯拉”将保护大和号免受“回转波动炮”能量辐射的影响": "诺伊·迪乌斯拉号会保护大和号 免受回转波动炮能量辐射",
    "是敌 Calakulm 级战舰 但非常小 而且比例各不相同": "是敌 Calakulm 级战舰 但大小比例各异",
    "我们必须让它看见 人类哪怕只能让最后一人多活一秒 也绝不放弃": "我们必须让尽可能多的人活得尽可能久",
    "但若能在敌军完成能量转换前拖延时间 让尽可能多的人逃离地球……": "但若能在敌军完成能量转换前争取时间 让更多人逃离地球……",
    "失控的波动引擎开启了通往高维世界的大门 把特蕾莎带到这里……": "失控的波动引擎打开高维世界之门 把特蕾莎带来这里……",
}


def normalize_ellipsis(text: str) -> str:
    text = re.sub(r"(?<!…)(?:\.{3,}|…+)(?!…)", "……", text)
    text = re.sub(r"……+", "……", text)
    return text


def normalize_question_exclamation(text: str) -> str:
    def repl(match: re.Match[str]) -> str:
        value = match.group(0)
        if "？" in value or "?" in value:
            return "？"
        return "！"

    return re.sub(r"[？！!?]{2,}", repl, text).replace("?", "？").replace("!", "！")


def add_mixed_spacing(text: str) -> str:
    # The supplied commercial guide requests one half-width space at a Han /
    # ASCII letter-or-digit boundary.  Internal model names stay untouched.
    text = re.sub(r"([\u3400-\u9fff])([A-Za-z0-9])", r"\1 \2", text)
    text = re.sub(r"([A-Za-z0-9])([\u3400-\u9fff])", r"\1 \2", text)
    return text


def normalize_a(text: str) -> tuple[str, list[str]]:
    reasons: list[str] = []
    original = text
    if text in COLON_REWRITES:
        text = COLON_REWRITES[text]
        reasons.append("A/B2 冒号语序人工改写")
    elif "：" in text:
        raise RuntimeError(f"Unreviewed colon cue: {text}")

    before = text
    text = re.sub(r"[，。、；]", " ", text)
    text = re.sub(r"(?<=[\u3400-\u9fff])[;,](?=[\u3400-\u9fff])", " ", text)
    if text != before:
        reasons.append("A1 极简标点")

    before = text
    text = normalize_ellipsis(text)
    text = normalize_question_exclamation(text)
    text = text.replace("—", "——") if "—" in text and "——" not in text else text
    if text != before:
        reasons.append("A3 问叹/省略/破折号")

    before = text
    text = add_mixed_spacing(text)
    if text != before:
        reasons.append("A2 中西文数字空格")

    before = text
    text = text.replace("　", " ")
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"(?<=[“‘《〈（(])\s+", "", text)
    text = re.sub(r"\s+(?=[”’》〉）)？！])", "", text)
    text = re.sub(r"\s*(——|……)\s*", r"\1", text)
    if text != before:
        reasons.append("A2 空格清理")

    if text in CONDENSATIONS:
        text = CONDENSATIONS[text]
        reasons.append("B1 无损凝练")

    if text != original and not reasons:
        reasons.append("文本规范")
    return text, reasons


def ass_seconds(raw: str) -> float:
    hour, minute, rest = raw.split(":")
    second, centisecond = rest.split(".")
    return int(hour) * 3600 + int(minute) * 60 + int(second) + int(centisecond) / 100


def overlapping_text(target: dict, events: list[dict], styles: set[str]) -> str:
    start = ass_seconds(target["start"])
    end = ass_seconds(target["end"])
    parts: list[str] = []
    for event in events:
        if event["style"] not in styles:
            continue
        overlap = min(end, ass_seconds(event["end"])) - max(start, ass_seconds(event["start"]))
        if overlap <= 0.10 and abs(start - ass_seconds(event["start"])) > 0.08:
            continue
        value = event["text"]
        if value and value not in parts:
            parts.append(value)
    return " / ".join(parts)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--long-report", type=Path, required=True)
    parser.add_argument("--english-root", type=Path)
    args = parser.parse_args()

    overrides: dict[str, list[dict]] = {}
    long_items: list[dict] = []
    reason_counts: dict[str, int] = {}
    for path in sorted(args.root.glob("*.ass"), key=episode):
        ep = f"{episode(path):02d}"
        all_events = read_dialogues(path)
        english_events = (
            read_dialogues(args.english_root / f"EP{ep}.en.ass")
            if args.english_root is not None
            else []
        )
        episode_overrides = []
        chinese_events = [event for event in all_events if event["style"] == "DefaultCN-2202"]
        for cn_position, event in enumerate(chinese_events):
            if event["style"] != "DefaultCN-2202":
                continue
            before = event["text"]
            after, reasons = normalize_a(before)
            if len(after) > 24:
                long_items.append({
                    "episode": ep,
                    "index": event["index"],
                    "start": event["start"],
                    "end": event["end"],
                    "before": before,
                    "normalized": after,
                    "length": len(after),
                    "previous": chinese_events[cn_position - 1]["text"] if cn_position else "",
                    "next": chinese_events[cn_position + 1]["text"] if cn_position + 1 < len(chinese_events) else "",
                    "japanese": overlapping_text(event, all_events, {"JapaneseAux", "JapaneseAuxTop"}),
                    "english": overlapping_text(event, english_events, {"def2", "Default"}),
                })
            if after == before:
                continue
            for reason in set(reasons):
                reason_counts[reason] = reason_counts.get(reason, 0) + 1
            episode_overrides.append({
                "index": event["index"],
                "start": event["start"],
                "end": event["end"],
                "before": before,
                "after": after,
                "reasons": reasons,
            })
        overrides[ep] = episode_overrides

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(overrides, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    args.long_report.parent.mkdir(parents=True, exist_ok=True)
    args.long_report.write_text(json.dumps(long_items, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "changed": sum(map(len, overrides.values())),
        "longer_than_24": len(long_items),
        "longer_than_28": sum(item["length"] > 28 for item in long_items),
        "reasons": reason_counts,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
