from __future__ import annotations

import re
import sys
from pathlib import Path


DEFAULT_ROOT = Path(r"C:\Users\Vki\Documents\Codex\2026-08-24\hui-2\outputs\宇宙战舰大和号2202 爱的战士们.简日双语.精校")
TAG_RE = re.compile(r"\{[^}]*\}")
TIME_RE = re.compile(r"(\d+):(\d{2}):(\d{2})\.(\d{2})")
LATIN_RE = re.compile(r"[A-Za-z]")
HAN_RE = re.compile(r"[\u3400-\u9fff]")
MIXED_TOKEN_RE = re.compile(r"(?:[A-Za-z][\u3400-\u9fff]|[\u3400-\u9fff][A-Za-z])")


def seconds(raw: str) -> float:
    hour, minute, second, centisecond = map(int, TIME_RE.fullmatch(raw).groups())
    return hour * 3600 + minute * 60 + second + centisecond / 100


def visible(raw: str) -> str:
    return TAG_RE.sub("", raw).replace(r"\N", " / ").strip()


def episode(path: Path) -> int:
    return int(re.search(r"S02E(\d{2})", path.name).group(1))


def read_events(path: Path) -> list[dict]:
    events = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.startswith("Dialogue:"):
            continue
        fields = line.split(":", 1)[1].lstrip().split(",", 9)
        if len(fields) != 10:
            continue
        _, start, end, style, name, *_rest, text = fields
        events.append(
            {
                "line": line_no,
                "start": seconds(start),
                "end": seconds(end),
                "start_raw": start,
                "end_raw": end,
                "style": style,
                "name": name,
                "text": visible(text),
            }
        )
    return events


def main(root: Path) -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    overlap_hits = []
    mixed_hits = []
    mid_episode_english = []
    for path in sorted(root.glob("*.ass"), key=episode):
        ep = episode(path)
        events = read_events(path)
        chinese = [event for event in events if event["style"] == "DefaultCN-2202"]
        for event in events:
            latin = len(LATIN_RE.findall(event["text"]))
            han = len(HAN_RE.findall(event["text"]))
            if event["style"] == "DefaultCN-2202" and MIXED_TOKEN_RE.search(event["text"]):
                mixed_hits.append((ep, event))
            if (
                event["start"] < 22 * 60
                and event["style"] not in {"DefaultCN-2202", "JapaneseAux", "JapaneseAuxTop"}
                and latin >= 4
                and han == 0
            ):
                mid_episode_english.append((ep, event))
            if event["style"] in {"DefaultCN-2202", "JapaneseAux", "JapaneseAuxTop"}:
                continue
            if latin < 4 or han != 0:
                continue
            for cn in chinese:
                overlap = min(event["end"], cn["end"]) - max(event["start"], cn["start"])
                if overlap >= 0.15:
                    overlap_hits.append((ep, event, cn, overlap))

    print("=== ASCII-only non-dialogue event overlapping Chinese ===")
    for ep, foreign, cn, overlap in overlap_hits:
        print(
            f"EP{ep:02d} {foreign['start_raw']} {foreign['style']} line={foreign['line']} "
            f"overlap={overlap:.2f}s | {foreign['text']} || {cn['text']}"
        )
    print(f"count={len(overlap_hits)}")

    print("=== Mid-episode ASCII-only non-dialogue events ===")
    for ep, event in mid_episode_english:
        print(f"EP{ep:02d} {event['start_raw']} {event['style']} line={event['line']} | {event['text']}")
    print(f"count={len(mid_episode_english)}")

    print("=== Mixed Latin-Han tokens inside Chinese events ===")
    for ep, event in mixed_hits:
        print(f"EP{ep:02d} {event['start_raw']} line={event['line']} | {event['text']}")
    print(f"count={len(mixed_hits)}")


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_ROOT)
