from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OVERRIDES = ROOT / "work" / "streaming_text" / "overrides.json"
LONG_REPORT = ROOT / "work" / "streaming_text" / "long_candidates.json"
OUTPUT = ROOT / "宇宙战舰大和号2202_流媒体文本优化修改台账.md"


def escape(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")


def main() -> None:
    overrides = json.loads(OVERRIDES.read_text(encoding="utf-8"))
    long_items = json.loads(LONG_REPORT.read_text(encoding="utf-8"))
    all_items = [item for episode_items in overrides.values() for item in episode_items]
    b_items = [item for item in all_items if "B1 无损凝练" in item["reasons"]]
    colon_items = [item for item in all_items if "A/B2 冒号语序人工改写" in item["reasons"]]
    reason_counts: dict[str, int] = {}
    for item in all_items:
        for reason in set(item["reasons"]):
            reason_counts[reason] = reason_counts.get(reason, 0) + 1

    exceptions = [item for item in long_items if item["length"] > 28]
    exception_reasons = {
        ("11", "0:20:24.42"): "保留 Cosmo Wave 统一术语及空间崩溃后的因果关系",
        ("13", "0:07:48.95"): "跃迁推进器、Cosmo TigerⅡ、机动甲胄突击队均为必要作战单位",
        ("13", "0:08:46.23"): "180 度转向、波动炮、岩板与封锁目标均为必要战术信息",
    }

    lines = [
        "# 《宇宙战舰大和号2202》流媒体文本优化修改台账",
        "",
        "## 一、执行结论",
        "",
        "本轮已完成经批准的 A、B 两级优化。全程只改 `DefaultCN-2202` 中文文字字段，未拆分、合并、增加或删除事件，未修改任何起止时间、样式、图层、名称、定位标签或中日配对。",
        "",
        "- 26 集 ASS；",
        "- 中文主字幕 5806 条；",
        "- 日文辅助字幕 5613 条；",
        f"- 实际修改中文事件 {len(all_items)} 条；",
        "- 修改前后结构与时间轴逐事件 SHA-256 指纹一致；",
        "- 直接套用覆盖与完整重建产物逐文件 SHA-256 完全一致。",
        "",
        "## 二、A级规范化统计",
        "",
        "| 项目 | 修改事件 | 验收结果 |",
        "|---|---:|---:|",
        f"| 逗号、句号、顿号、分号极简化 | {reason_counts.get('A1 极简标点', 0)} | 禁用标点 0 |",
        f"| 中西文及数字边界空格 | {reason_counts.get('A2 中西文数字空格', 0)} | 缺失边界空格 0 |",
        f"| 冒号逐条人工改写 | {reason_counts.get('A/B2 冒号语序人工改写', 0)} | 普通对白冒号 0 |",
        f"| 连续空格、全角空格等清理 | {reason_counts.get('A2 空格清理', 0)} | 空格错误 0 |",
        "| 复合问叹号、非标准省略号和破折号 | 复核全部 5806 条 | 错误 0 |",
        "",
        "### 冒号人工改写明细",
        "",
        "| 集数 | 时间 | 修改前 | 修改后 |",
        "|---:|---|---|---|",
    ]
    for ep, episode_items in overrides.items():
        for item in episode_items:
            if item not in colon_items:
                continue
            lines.append(
                f"| EP{ep} | {item['start']} | {escape(item['before'])} | {escape(item['after'])} |"
            )

    lines.extend([
        "",
        "## 三、B级无损凝练明细",
        "",
        f"共完成 {len(b_items)} 条重点凝练。以下为完整的修改前后对照；删除的仅为无原文依据的强化、重复主语、赘余结构或可由更短中文完整表达的信息，否定、条件、因果、数量、对象、专名和作战关系均保留。",
        "",
        "| 集数 | 时间 | 修改前 | 修改后 |",
        "|---:|---|---|---|",
    ])
    for ep, episode_items in overrides.items():
        for item in episode_items:
            if "B1 无损凝练" not in item["reasons"]:
                continue
            lines.append(
                f"| EP{ep} | {item['start']} | {escape(item['before'])} | {escape(item['after'])} |"
            )

    lines.extend([
        "",
        "## 四、时间轴冻结条件下的长度例外",
        "",
        "16 字只作为理想目标。本轮不为压缩字数删译、不增加硬换行，也不改轴。优化后超过 24 个显示字符 351 条，其中超过 28 字仅 3 条：",
        "",
        "| 集数 | 时间 | 字数 | 保留文本 | 保留原因 |",
        "|---:|---|---:|---|---|",
    ])
    for item in exceptions:
        reason = exception_reasons.get((item["episode"], item["start"]), "无损压缩空间不足")
        lines.append(
            f"| EP{item['episode']} | {item['start']} | {item['length']} | "
            f"{escape(item['normalized'])} | {reason} |"
        )

    lines.extend([
        "",
        "## 五、重点翻译修正说明",
        "",
        "- EP05：`波动核心`依日文 `波動コイル` 修正为`波动线圈`；",
        "- EP13：删除日文无依据的`通过 Cosmo Wave 传来`，改为`特蕾莎的数据显示`；",
        "- EP21：`温柔与人性会使人失去求生意志`按日文 `人を殺すなら` 修正为`温柔与人性会害死人`；",
        "- EP21：删除额外主语`我们一定要`，依原文凝练为`活下去！`；",
        "- EP25：删除`让它看见`、`最后一人`和`绝不放弃`等原文没有的发挥，按日文重译为`我们必须让尽可能多的人活得尽可能久`。",
        "",
        "## 六、最终验收",
        "",
        "- 结构与时间轴差异：0；",
        "- 普通对白禁用标点：0；",
        "- 普通对白冒号：0；",
        "- 复合问叹号、非标准省略号、非标准破折号：0；",
        "- 连续空格、全角空格、中西文数字边界错误：0；",
        "- 引号不配对、中文硬换行：0；",
        "- 英文注解重叠：0；",
        "- 屏显字幕组补充：0；",
        "- 中文语言与术语硬错误：0；",
        "- 下集预告保持仅中文，必要译注仍为 8 条。",
        "",
        "阅读速度自动检查仍提示 116 条候选，但依本轮审批属于冻结时间轴后的报告项，不作为改轴、删译或强制压缩依据。",
    ])
    OUTPUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote={OUTPUT} b_items={len(b_items)} colon_items={len(colon_items)}")


if __name__ == "__main__":
    main()
