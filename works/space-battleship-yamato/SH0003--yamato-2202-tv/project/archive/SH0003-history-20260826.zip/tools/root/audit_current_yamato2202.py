from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FINAL_ROOT = ROOT / "outputs" / "宇宙战舰大和号2202 爱的战士们.简日双语.精校"
ENGLISH_ROOT = ROOT / "build" / "yamato2202" / "work" / "yamato2202_english"
OUTPUT = ROOT / "yamato2202_translation_audit_candidates.json"
ALL_GROUPS_OUTPUT = ROOT / "yamato2202_trilingual_groups.json"

TIME_RE = re.compile(r"(\d+):(\d{2}):(\d{2})\.(\d{2})")
TAG_RE = re.compile(r"\{[^}]*\}")
CN_CORE = re.compile(r"[\u3400-\u9fff]")
JP_CORE = re.compile(r"[一-龯ぁ-ゖァ-ヺー]")
JP_NEG = re.compile(r"ない|ません|なかった|なく|できない|できません|ずに|ざる|まい(?:[\s。！？]|$)|ぬ(?:[\s。！？]|$)")
EN_NEG = re.compile(r"\b(?:not|never|none|no|without|unable|cannot|can't|won't|don't|doesn't|didn't|isn't|aren't|wasn't|weren't|shouldn't|wouldn't|couldn't)\b|n't", re.I)
CN_NEG = re.compile(r"不|没|无|未|别|莫|勿|非|否|不能|不会|无法|甭|休想|难以|免得")
JP_Q = re.compile(r"[？?]|のか|なのか|だと[？?]|かい[？?。！]?$|かね[？?。！]?$|か[？?]$")
EN_Q = re.compile(r"\?")
CN_Q = re.compile(r"[？?]|吗|么|呢|难道|为何|为什么|怎么|什么|谁|哪|多少|几时|如何|是否")

STRONG_MARKERS = {
    "毛骨悚然": 8, "我有一言": 7, "还望": 6, "静听": 5, "恳请": 4,
    "前无古人": 4, "鞠躬尽瘁": 4, "无可替代": 3, "连根拔起": 3,
    "万分": 3, "无比": 3, "极其": 2.5, "必定": 2.5, "无疑": 2.5,
    "务必": 2, "绝对": 2, "彻底": 2, "竟然": 2, "居然": 2,
    "显然": 2, "简直": 2, "根本": 1.5, "甚至": 1.5, "恐怕": 1.5,
    "想必": 1.5, "果然": 1.5, "真正": 1.2, "正因如此": 1.2,
}


def seconds(value: str) -> float:
    h, m, s, cs = map(int, TIME_RE.fullmatch(value).groups())
    return h * 3600 + m * 60 + s + cs / 100


def visible(text: str) -> str:
    return TAG_RE.sub("", text).replace(r"\N", " ").strip()


def read_ass(path: Path) -> list[dict]:
    events = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.startswith("Dialogue:"):
            continue
        fields = line.split(":", 1)[1].lstrip().split(",", 9)
        if len(fields) != 10:
            continue
        layer, start, end, style, name, ml, mr, mv, effect, text = fields
        events.append({
            "line": line_number,
            "start": seconds(start), "end": seconds(end),
            "start_raw": start, "end_raw": end,
            "style": style, "name": name,
            "text": visible(text),
        })
    return events


def overlaps(target: dict, events: list[dict]) -> list[dict]:
    hits = []
    for event in events:
        overlap = min(target["end"], event["end"]) - max(target["start"], event["start"])
        if overlap > 0.10 or abs(target["start"] - event["start"]) <= 0.08:
            hits.append(event)
    return hits


def joined(events: list[dict]) -> str:
    parts = []
    for event in events:
        text = event["text"]
        if text and text not in parts:
            parts.append(text)
    return " / ".join(parts)


def grouped_cn(cn: list[dict], jp: list[dict]) -> list[list[dict]]:
    """Join consecutive Chinese events that share a Japanese event.

    Some source Japanese cues span two or more deliberately split Chinese
    cues. Auditing those Chinese pieces separately creates false omissions.
    """
    groups: list[list[dict]] = []
    current: list[dict] = []
    current_hit_ids: set[int] = set()
    for event in cn:
        hit_ids = {item["line"] for item in overlaps(event, jp)}
        if current and current_hit_ids.intersection(hit_ids):
            current.append(event)
            current_hit_ids.update(hit_ids)
        else:
            if current:
                groups.append(current)
            current = [event]
            current_hit_ids = set(hit_ids)
    if current:
        groups.append(current)
    return groups


def episode_number(path: Path) -> int:
    return int(re.search(r"S02E(\d{2})", path.name).group(1))


def main() -> None:
    report = {}
    all_groups = {}
    final_files = sorted(FINAL_ROOT.glob("*.ass"), key=episode_number)
    for final_path in final_files:
        episode = episode_number(final_path)
        final_events = read_ass(final_path)
        english_events = read_ass(ENGLISH_ROOT / f"EP{episode:02d}.english.ass")
        cn = [event for event in final_events if event["style"] == "DefaultCN-2202"]
        jp = [event for event in final_events if event["style"] == "JapaneseAux"]
        en = [
            event for event in english_events
            if event["style"] in {"def2", "Default"}
            and event["name"].upper() not in {"DUMMY", "ENDSONG", "ENSONG", "TEXT"}
        ]
        items = []
        episode_groups = []
        groups = grouped_cn(cn, jp)
        for index, group in enumerate(groups):
            event = {
                "start": min(item["start"] for item in group),
                "end": max(item["end"] for item in group),
                "start_raw": group[0]["start_raw"],
                "end_raw": group[-1]["end_raw"],
                "line": group[0]["line"],
            }
            jp_hits = overlaps(event, jp)
            en_hits = overlaps(event, en)
            jp_text = joined(jp_hits)
            en_text = joined(en_hits)
            if not jp_text:
                continue
            cn_text = " / ".join(item["text"] for item in group)
            episode_groups.append({
                "episode": episode,
                "line": event["line"],
                "start": event["start_raw"], "end": event["end_raw"],
                "cn": cn_text, "jp": jp_text, "en": en_text,
            })
            cn_len = len(CN_CORE.findall(cn_text))
            jp_len = len(JP_CORE.findall(jp_text))
            ratio = cn_len / max(jp_len, 1)
            score = 0.0
            reasons = []
            if jp_len >= 5 and cn_len - jp_len >= 5 and ratio >= 1.25:
                score += (cn_len - jp_len) * 0.5 + (ratio - 1.18) * 5
                reasons.append(f"中文显长 {cn_len}/{jp_len}")
            if jp_len >= 10 and jp_len - cn_len >= 8 and ratio <= 0.50:
                score += (jp_len - cn_len) * 0.45
                reasons.append(f"中文显短 {cn_len}/{jp_len}")
            jp_neg = bool(JP_NEG.search(jp_text))
            en_neg = bool(EN_NEG.search(en_text))
            cn_neg = bool(CN_NEG.search(cn_text))
            if jp_neg and en_neg and not cn_neg:
                score += 5
                reasons.append("日英含否定，中文无显式否定")
            if JP_Q.search(jp_text) and EN_Q.search(en_text) and not CN_Q.search(cn_text):
                score += 3
                reasons.append("日英为疑问，中文未见疑问")
            markers = []
            for marker, weight in STRONG_MARKERS.items():
                if marker in cn_text:
                    score += weight
                    markers.append(marker)
            if markers:
                reasons.append("强化/成语化措辞：" + "、".join(markers))
            if score >= 2.5:
                items.append({
                    "score": round(score, 2),
                    "episode": episode,
                    "line": event["line"],
                    "start": event["start_raw"], "end": event["end_raw"],
                    "cn": cn_text, "jp": jp_text, "en": en_text,
                    "previous_cn": " / ".join(item["text"] for item in groups[index - 1]) if index else "",
                    "next_cn": " / ".join(item["text"] for item in groups[index + 1]) if index + 1 < len(groups) else "",
                    "reasons": reasons,
                })
        items.sort(key=lambda item: (-item["score"], seconds(item["start"])))
        report[f"{episode:02d}"] = items
        all_groups[f"{episode:02d}"] = episode_groups
    OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    ALL_GROUPS_OUTPUT.write_text(json.dumps(all_groups, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({ep: len(items) for ep, items in report.items()}, ensure_ascii=False, indent=2))
    print(f"total={sum(map(len, report.values()))}")
    print(OUTPUT)


if __name__ == "__main__":
    main()
