# 《宇宙战舰大和号2202》校对源素材

本目录保存最终中文精校所依据的三套原始字幕，均为逐集规范命名的只读参考副本：

- `english-from-video/EPxx.en.ass`：从目标 BD 视频字幕轨提取的英文字幕，共 26 集。
- `japanese-official-webrip/EPxx.ja.official-webrip.srt`：日文官方无障碍字幕，共 26 集；翻译含义以此为第一依据。
- `chinese-fansub-baseline/EPxx.zh-CN.fansub-baseline.ass`：原中文字幕组底稿，共 26 集；仅用于继承中文时间轴、样式和既有翻译。

目标视频本体未重复复制，以免无谓占用约 12 GB 空间。26 集视频保留于：

`C:\Users\Vki\Documents\Codex\2026-08-23\Season 2 - Star Blazers 2202 Warriors of Love`

`source_manifest.csv` 记录上述 78 份字幕副本的大小与 SHA-256，并列出 26 集目标视频的文件名、大小和原始位置。字幕源另有独立压缩备份：

`C:\Users\Vki\Documents\Codex\2026-08-24\hui-2\sources\宇宙战舰大和号2202_日英中原始字幕源.zip`

翻译取舍顺序：日文原意 > 画面与语境 > 英文辅助解释 > 原中文字幕。英文仅作时间轴、语气和歧义交叉核验，不能覆盖明确的日文原意。

完整修订数据、字体与可重建工具已归档至：

`C:\Users\Vki\Documents\Codex\2026-08-24\hui-2\build\yamato2202`

原 `C:\Users\Vki\Documents\Codex\2026-08-23\jiao-d` 项目内容完成迁移和哈希核验后删除，不再作为依赖路径。
