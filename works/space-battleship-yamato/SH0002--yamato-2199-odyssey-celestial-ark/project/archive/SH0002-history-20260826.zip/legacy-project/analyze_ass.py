from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter
from pathlib import Path


TIME_RE = re.compile(r"(?P<h>\d+):(?P<m>\d{2}):(?P<s>\d{2})\.(?P<cs>\d{2})$")
TAG_RE = re.compile(r"\{[^}]*\}")
CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
KANA_RE = re.compile(r"[\u3040-\u30ff]")
READABLE_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaffA-Za-z0-9]")


def ts(value: str) -> float:
    match = TIME_RE.fullmatch(value.strip())
    if not match:
        raise ValueError(value)
    parts = {key: int(item) for key, item in match.groupdict().items()}
    return parts["h"] * 3600 + parts["m"] * 60 + parts["s"] + parts["cs"] / 100


def visible(text: str) -> str:
    return TAG_RE.sub("", text).replace(r"\N", "\n").replace(r"\n", "\n").replace(r"\h", " ")


def read_ass(path: Path):
    raw = path.read_bytes()
    encoding = "utf-8-sig"
    try:
        content = raw.decode(encoding)
    except UnicodeDecodeError:
        encoding = "gb18030"
        content = raw.decode(encoding)

    section = None
    style_format = []
    event_format = []
    styles = []
    events = []
    info = {}
    malformed = []
    for line_no, line in enumerate(content.splitlines(), 1):
        if line.startswith("[") and line.endswith("]"):
            section = line
            continue
        if section == "[Script Info]" and ":" in line and not line.startswith(";"):
            key, value = line.split(":", 1)
            info[key.strip()] = value.strip()
        elif section == "[V4+ Styles]":
            if line.startswith("Format:"):
                style_format = [x.strip() for x in line.split(":", 1)[1].split(",")]
            elif line.startswith("Style:"):
                values = [x.strip() for x in line.split(":", 1)[1].split(",")]
                if len(values) == len(style_format):
                    styles.append(dict(zip(style_format, values)))
                else:
                    malformed.append((line_no, "style_field_count", line))
        elif section == "[Events]":
            if line.startswith("Format:"):
                event_format = [x.strip() for x in line.split(":", 1)[1].split(",")]
            elif line.startswith(("Dialogue:", "Comment:")):
                kind, payload = line.split(":", 1)
                values = [x.strip() for x in payload.split(",", len(event_format) - 1)]
                if len(values) != len(event_format):
                    malformed.append((line_no, "event_field_count", line))
                    continue
                event = dict(zip(event_format, values))
                event.update(kind=kind, line=line_no)
                try:
                    event["start_s"] = ts(event["Start"])
                    event["end_s"] = ts(event["End"])
                except ValueError:
                    malformed.append((line_no, "bad_time", line))
                    continue
                event["visible"] = visible(event["Text"])
                events.append(event)
    return encoding, info, styles, events, malformed, content


def main(root: Path):
    files = sorted(root.glob("*.ass"))
    overall = Counter()
    episodes = []
    top_cps = []
    top_long = []
    overlap_examples = []
    syntax_examples = []
    style_signatures = Counter()
    style_usage = Counter()
    font_usage = Counter()
    term_counts = Counter()
    punctuation = Counter()
    term_patterns = [
        "加密拉斯", "加米拉斯", "加特兰蒂斯", "波动炮", "波动引擎", "波动核心",
        "大和号", "大和", "特蕾莎", "泰瑞莎", "特蕾莎兹", "兹沃达", "佐达",
        "古代", "森雪", "真田", "岛大介", "土方", "斋藤", "德川", "山南",
        "空间骑兵", "宇宙骑兵", "时间断层", "时空断层", "反波动格子", "反波动晶格",
        "传导波", "心灵感应", "人工太阳", "都市帝国", "白色彗星", "彗星帝国",
        "跃迁", "曲速", "传送", "火焰直击炮", "火焰直击枪", "雷击旋回炮",
    ]

    for path in files:
        encoding, info, styles, events, malformed, content = read_ass(path)
        episode = re.search(r"\[(\d{2})\]\[CHS\]", path.name).group(1)
        dialogue = [e for e in events if e["kind"] == "Dialogue"]
        comments = [e for e in events if e["kind"] == "Comment"]
        default = [e for e in dialogue if e["Style"] == "DefaultCN-2202"]
        effects = [e for e in dialogue if e["Style"] != "DefaultCN-2202"]
        invalid_duration = [e for e in dialogue if e["end_s"] <= e["start_s"]]
        very_short = []
        very_short_default = []
        high_cps = []
        high_cps_effects = []
        long_lines = []
        kana = []
        ascii_punct = []
        bad_tags = []
        for event in dialogue:
            duration = event["end_s"] - event["start_s"]
            chars = len(READABLE_RE.findall(event["visible"]))
            cps = chars / duration if duration > 0 else 999
            event["duration"] = duration
            event["chars"] = chars
            event["cps"] = cps
            if duration < 0.5:
                very_short.append(event)
                if event in default:
                    very_short_default.append(event)
            if event in default and chars >= 8 and cps > 12:
                high_cps.append(event)
                top_cps.append((cps, episode, event["line"], event["Start"], event["End"], event["visible"]))
            if event in effects and chars >= 8 and cps > 12:
                high_cps_effects.append(event)
            max_line = max((len(READABLE_RE.findall(part)) for part in event["visible"].split("\n")), default=0)
            if event in default and max_line > 24:
                long_lines.append(event)
                top_long.append((max_line, episode, event["line"], event["Start"], event["visible"]))
            if KANA_RE.search(event["visible"]):
                kana.append(event)
            if re.search(r"(?<!\d)[,!?](?!\d)|(?<!\.)\.(?!\.)", event["visible"]):
                ascii_punct.append(event)
            if event["Text"].count("{") != event["Text"].count("}") or re.search(r"\\(?:[1234]?c)&H\([^)]*\)", event["Text"], re.I):
                bad_tags.append(event)
                syntax_examples.append((episode, event["line"], event["Text"]))

            for mark in "，。！？；：、…—“”‘’":
                punctuation[mark] += event["visible"].count(mark)

        ordered = sorted(default, key=lambda e: (e["start_s"], e["end_s"]))
        overlaps = []
        previous = None
        for event in ordered:
            if previous and event["start_s"] < previous["end_s"] - 0.05:
                overlaps.append((previous, event))
                if len(overlap_examples) < 30:
                    overlap_examples.append((episode, previous["line"], event["line"], previous["End"], event["Start"], previous["visible"], event["visible"]))
            if previous is None or event["end_s"] > previous["end_s"]:
                previous = event

        for style in styles:
            sig = tuple((key, style.get(key, "")) for key in ("Name", "Fontname", "Fontsize", "PrimaryColour", "OutlineColour", "Bold", "Outline", "Shadow", "Alignment", "MarginV"))
            style_signatures[sig] += 1
            font_usage[style.get("Fontname", "")] += 1
        for event in dialogue:
            style_usage[event["Style"]] += 1
        for term in term_patterns:
            term_counts[term] += content.count(term)

        overall.update(
            dialogue=len(dialogue), comments=len(comments), default=len(default), effects=len(effects),
            malformed=len(malformed), invalid_duration=len(invalid_duration), very_short=len(very_short),
            very_short_default=len(very_short_default),
            high_cps=len(high_cps), long_lines=len(long_lines), overlaps=len(overlaps), kana=len(kana),
            high_cps_effects=len(high_cps_effects),
            ascii_punct=len(ascii_punct), bad_tags=len(bad_tags),
        )
        episodes.append({
            "episode": episode,
            "encoding": encoding,
            "playres": [info.get("PlayResX"), info.get("PlayResY")],
            "matrix": info.get("YCbCr Matrix"),
            "styles": len(styles),
            "dialogue": len(dialogue),
            "default": len(default),
            "effects": len(effects),
            "comments": len(comments),
            "invalid_duration": len(invalid_duration),
            "very_short": len(very_short),
            "very_short_default": len(very_short_default),
            "high_cps": len(high_cps),
            "high_cps_effects": len(high_cps_effects),
            "long_lines": len(long_lines),
            "overlaps": len(overlaps),
            "kana": len(kana),
            "ascii_punct": len(ascii_punct),
            "bad_tags": len(bad_tags),
            "malformed": len(malformed),
        })

    result = {
        "files": len(files),
        "overall": overall,
        "episodes": episodes,
        "style_usage": style_usage,
        "font_usage": font_usage,
        "style_signatures": [{"count": count, "style": dict(sig)} for sig, count in style_signatures.most_common()],
        "term_counts": {key: value for key, value in term_counts.items() if value},
        "punctuation": punctuation,
        "top_cps": sorted(top_cps, reverse=True)[:40],
        "top_long": sorted(top_long, reverse=True)[:40],
        "overlap_examples": overlap_examples,
        "syntax_examples": syntax_examples[:40],
    }
    if "--brief" in sys.argv:
        brief = {
            "files": result["files"],
            "overall": result["overall"],
            "episodes": result["episodes"],
            "style_usage": result["style_usage"],
            "font_usage": result["font_usage"],
            "term_counts": result["term_counts"],
        }
        print(json.dumps(brief, ensure_ascii=False, indent=2, default=dict))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2, default=dict))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
