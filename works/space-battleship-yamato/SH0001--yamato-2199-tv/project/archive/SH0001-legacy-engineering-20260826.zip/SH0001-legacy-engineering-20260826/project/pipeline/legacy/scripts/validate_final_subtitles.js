const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(root, 'outputs', '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');
const tvFiles = fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort().map((name) => path.join(tvDir, name));
const files = [...tvFiles, movieFile];

const errors = [];
const summaries = [];
const oldTerms = [
  '次元潜航舰', '次元潜艇', '自动航行室', '自动航法室', '伽米佬', '加米拉斯佬',
  '航行长', '大麦哲伦星云', '大麦哲伦星系', '波动防壁', '奇姆雷', '杰力克',
  '佛姆特·巴伽', '佛姆特·巴格', '萨尔茨', '希尔达', '德斯拉',
];
const forbiddenText = [
  '[方位 4500]', '苟延残喘生存下去的希望也没有了', '为地球人的垂死挣扎祈愿吧',
  '地方宇宙舰艇', '办个婚礼吧', '希望的的勇气', '不同与制造出星际门的文明',
  '成功的复制了', '预测的的航路', '从那里就出来的', '出色的继承了他',
];
const requiredText = [
  '除了躲入其中求生 已别无他路', '诸位 让我们举杯 祝地球人奋战到底',
  '如果错误持续发生 就必须将你初始化', '我知道她被带到哪里了', '你爱他吗？',
  '救了我们的 正是使用波动能量的大炮', '敌方次元潜水艇从本舰左舷驶过！',
  '但我们这份精神还没有完全传给他', '这才是空间骑兵的精神', '居然还没沉？',
  '自动导航室', '加米佬', '次元潜水艇', '大麦哲伦云', '波动防御壁', '航海长',
];

function parseDialogue(line) {
  const match = line.match(/^Dialogue: ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    layer: match[1], start: match[2], end: match[3], style: match[4], name: match[5],
    marginL: match[6], marginR: match[7], marginV: match[8], effect: match[9], text: match[10],
  };
}

function countByAxis(events, styleTest) {
  const map = new Map();
  for (const event of events.filter((item) => styleTest(item.style))) {
    const key = `${event.start}|${event.end}`;
    map.set(key, (map.get(key) || 0) + 1);
  }
  return map;
}

function compareAxis(file, left, right, label) {
  const keys = new Set([...left.keys(), ...right.keys()]);
  for (const key of keys) {
    if ((left.get(key) || 0) !== (right.get(key) || 0)) {
      errors.push(`${path.basename(file)}: ${label} count mismatch at ${key}: CN=${left.get(key) || 0}, JP=${right.get(key) || 0}`);
    }
  }
}

if (tvFiles.length !== 26) errors.push(`TV file count is ${tvFiles.length}, expected 26`);

let corpus = '';
for (const file of files) {
  const raw = fs.readFileSync(file);
  if (!(raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf)) errors.push(`${path.basename(file)}: UTF-8 BOM missing`);
  const text = raw.toString('utf8').replace(/^\uFEFF/, '');
  corpus += `\n${text}`;
  for (const section of ['[Script Info]', '[V4+ Styles]', '[Events]']) {
    if (!text.includes(section)) errors.push(`${path.basename(file)}: missing ${section}`);
  }
  const dialogueLines = text.split(/\r?\n/).filter((line) => line.startsWith('Dialogue:'));
  const events = [];
  for (const line of dialogueLines) {
    const event = parseDialogue(line);
    if (!event) {
      errors.push(`${path.basename(file)}: malformed Dialogue line: ${line.slice(0, 160)}`);
      continue;
    }
    if (!event.text.trim()) errors.push(`${path.basename(file)}: empty Dialogue at ${event.start}`);
    if (['CN-Main', 'CN-Main-OS', 'CN-Top', 'CN-Alien', 'CN-Science-Note'].includes(event.style)) {
      const visible = event.text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ');
      if (/[，。；、]/.test(visible)) errors.push(`${path.basename(file)}: streaming-forbidden punctuation remains at ${event.start}: ${visible}`);
      if (/[!?]/.test(visible)) errors.push(`${path.basename(file)}: halfwidth question/exclamation remains at ${event.start}: ${visible}`);
      if (/[？！]{2,}/.test(visible)) errors.push(`${path.basename(file)}: repeated question/exclamation remains at ${event.start}: ${visible}`);
    }
    events.push(event);
  }
  const cnMain = countByAxis(events, (style) => style === 'CN-Main' || style === 'CN-Main-OS');
  const jpMain = countByAxis(events, (style) => style === 'JP-Main');
  const cnTop = countByAxis(events, (style) => style === 'CN-Top');
  const jpTop = countByAxis(events, (style) => style === 'JP-Top');
  compareAxis(file, cnMain, jpMain, 'main bilingual axis');
  compareAxis(file, cnTop, jpTop, 'top bilingual axis');
  summaries.push({
    file: path.basename(file), dialogue: events.length,
    cnMain: [...cnMain.values()].reduce((a, b) => a + b, 0),
    jpMain: [...jpMain.values()].reduce((a, b) => a + b, 0),
    cnTop: [...cnTop.values()].reduce((a, b) => a + b, 0),
    jpTop: [...jpTop.values()].reduce((a, b) => a + b, 0),
  });
}

for (const term of oldTerms) {
  if (corpus.includes(term)) errors.push(`Old terminology remains: ${term}`);
}
for (const text of forbiddenText) {
  if (corpus.includes(text)) errors.push(`Forbidden old text remains: ${text}`);
}
for (const text of requiredText) {
  if (!corpus.includes(text)) errors.push(`Required revised text missing: ${text}`);
}

const e10 = fs.readFileSync(tvFiles.find((file) => file.includes('S01E10')), 'utf8');
if (!e10.includes('[距离 7450]') || !e10.includes('距離7450')) errors.push('E10 valid distance 7450 bilingual event is missing');
if ((e10.match(/距離7450/g) || []).length !== 1) errors.push('E10 距離7450 should occur exactly once');

const hashes = Object.fromEntries(files.map((file) => [path.basename(file), crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex').toUpperCase()]));
const totals = summaries.reduce((acc, item) => {
  for (const key of ['dialogue', 'cnMain', 'jpMain', 'cnTop', 'jpTop']) acc[key] += item[key];
  return acc;
}, { dialogue: 0, cnMain: 0, jpMain: 0, cnTop: 0, jpTop: 0 });

console.log(JSON.stringify({ ok: errors.length === 0, errors, totals, files: summaries.length, hashes }, null, 2));
process.exitCode = errors.length ? 1 : 0;
