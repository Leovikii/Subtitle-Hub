const fs = require('fs');
const path = require('path');

const apply = process.argv.includes('--apply');
const root = path.resolve(__dirname, '..');
const sourceRootOption = process.argv.find((argument) => argument.startsWith('--source-root='));
const outputRoot = sourceRootOption ? path.resolve(sourceRootOption.slice('--source-root='.length)) : path.join(root, 'outputs');
const tvDir = path.join(outputRoot, '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(outputRoot, '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');
const reportFile = path.join(root, 'review_work', 'tables', 'streaming_punctuation_applied_changes.tsv');
const eligibleStyles = new Set(['CN-Main', 'CN-Main-OS', 'CN-Top', 'CN-Alien', 'CN-Science-Note']);

function parseEvent(line) {
  const match = line.match(/^(Dialogue|Comment): ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    kind: match[1], layer: match[2], start: match[3], end: match[4], style: match[5],
    name: match[6], marginL: match[7], marginR: match[8], marginV: match[9],
    effect: match[10], text: match[11],
  };
}

function serializeEvent(event) {
  return `${event.kind}: ${event.layer},${event.start},${event.end},${event.style},${event.name},${event.marginL},${event.marginR},${event.marginV},${event.effect},${event.text}`;
}

function readAss(file) {
  const raw = fs.readFileSync(file);
  const bom = raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  const text = raw.toString('utf8').replace(/^\uFEFF/, '');
  return { bom, newline: text.includes('\r\n') ? '\r\n' : '\n', lines: text.split(/\r?\n/) };
}

function writeAss(file, loaded) {
  fs.writeFileSync(file, `${loaded.bom ? '\uFEFF' : ''}${loaded.lines.join(loaded.newline)}`, 'utf8');
}

function protectAssSyntax(text) {
  const tokens = [];
  const protectedText = text.replace(/\{[^}]*\}|\\[Nn]/g, (token) => {
    const placeholder = `\uE000${tokens.length}\uE001`;
    tokens.push(token);
    return placeholder;
  });
  return { protectedText, tokens };
}

function restoreAssSyntax(text, tokens) {
  let result = text.replace(/\uE000(\d+)\uE001/g, (_, index) => tokens[Number(index)]);
  result = result.replace(/ *\\([Nn]) */g, '\\$1');
  return result;
}

function normalizeVisibleChinese(text) {
  const { protectedText, tokens } = protectAssSyntax(text);
  let result = protectedText;
  result = result.replace(/[，。；、]+/g, ' ');
  result = result.replace(/[!?]+/g, (marks) => marks.includes('?') ? '？' : '！');
  result = result.replace(/[？！]{2,}/g, (marks) => marks.includes('？') ? '？' : '！');
  result = result.replace(/[ \t]+/g, ' ');
  result = result.replace(/ +([？！：…—”’》】）])/g, '$1');
  result = result.replace(/([“‘《【（]) +/g, '$1');
  result = result.trim();
  return restoreAssSyntax(result, tokens);
}

function visibleText(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' / ').trim();
}

function workLabel(file) {
  if (file === movieFile) return '星巡的方舟';
  const match = path.basename(file).match(/S01E(\d{2})/);
  return `TV E${match[1]}`;
}

const files = fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort().map((name) => path.join(tvDir, name));
files.push(movieFile);

const changes = [];
let changedFiles = 0;
let bannedBefore = 0;
let bannedAfter = 0;

for (const file of files) {
  const loaded = readAss(file);
  const work = workLabel(file);
  let fileChanged = false;
  for (let index = 0; index < loaded.lines.length; index++) {
    const event = parseEvent(loaded.lines[index]);
    if (!event || event.kind !== 'Dialogue' || !eligibleStyles.has(event.style)) continue;
    if (visibleText(event.text).includes('♪')) continue;
    const before = event.text;
    const visibleBefore = visibleText(before);
    bannedBefore += (visibleBefore.match(/[，。；、]/g) || []).length;
    const after = normalizeVisibleChinese(before);
    const visibleAfter = visibleText(after);
    bannedAfter += (visibleAfter.match(/[，。；、]/g) || []).length;
    if (after === before) continue;
    changes.push([work, event.start, event.end, event.style, before, after]);
    event.text = after;
    loaded.lines[index] = serializeEvent(event);
    fileChanged = true;
  }
  if (fileChanged) {
    changedFiles++;
    if (apply) writeAss(file, loaded);
  }
}

fs.mkdirSync(path.dirname(reportFile), { recursive: true });
const rows = [
  ['作品', '开始', '结束', '样式', '修改前', '修改后'],
  ...changes,
];
if (changes.length || !fs.existsSync(reportFile)) {
  fs.writeFileSync(reportFile, rows.map((row) => row.map((cell) => String(cell ?? '').replace(/[\t\r\n]+/g, ' ').trim()).join('\t')).join('\n'), 'utf8');
}

console.log(JSON.stringify({
  apply, files: files.length, changedFiles, changes: changes.length,
  bannedBefore, bannedAfter, reportFile,
}, null, 2));
