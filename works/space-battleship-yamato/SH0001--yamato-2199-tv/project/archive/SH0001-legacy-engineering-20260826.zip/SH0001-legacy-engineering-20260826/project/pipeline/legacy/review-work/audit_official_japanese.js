const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const sourceRoot = path.join(root, 'sources', 'tv_japanese_webrip_official');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const outFile = path.join(__dirname, 'tables', 'official_jp_coverage.tsv');

function episodeNumber(file) {
  const match = file.match(/S01E(\d{2})/);
  if (!match) throw new Error(`No episode number in ${file}`);
  return Number(match[1]);
}

function stripAss(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ');
}

function normalizeJapanese(text) {
  return stripAss(text)
    .replace(/（[^）]*）/g, '')
    .replace(/\([^)]*[ぁ-ゖァ-ヺー][^)]*\)/g, '')
    .replace(/[０-９]/g, (char) => String(char.charCodeAt(0) - 0xff10))
    .replace(/[\s\u3000「」『』“”‘’\[\]【】〈〉《》！？!?…‥〜～・、。，．：:；;―—ｰー♪♬]/g, '')
    .toLowerCase();
}

function parseSrt(text) {
  return text.replace(/^\uFEFF/, '').split(/\r?\n\r?\n+/).flatMap((block) => {
    const lines = block.split(/\r?\n/);
    const timeIndex = lines.findIndex((line) => line.includes('-->'));
    if (timeIndex < 0) return [];
    const times = lines[timeIndex].match(/(\d\d:\d\d:\d\d)[,.](\d+)\s+-->\s+(\d\d:\d\d:\d\d)[,.](\d+)/);
    if (!times) return [];
    return [{ start: times[1], end: times[3], text: lines.slice(timeIndex + 1).join(' ') }];
  });
}

function parseAss(text) {
  return text.replace(/^\uFEFF/, '').split(/\r?\n/).flatMap((line) => {
    const match = line.match(/^Dialogue: ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
    if (!match) return [];
    return [{ start: match[2], end: match[3], style: match[4], text: match[10] }];
  });
}

const sourceFiles = fs.readdirSync(sourceRoot, { recursive: true })
  .filter((name) => name.endsWith('.srt'))
  .map((name) => path.join(sourceRoot, name));
const finalFiles = fs.readdirSync(tvDir)
  .filter((name) => name.endsWith('.ass'))
  .map((name) => path.join(tvDir, name));
if (sourceFiles.length !== 26 || finalFiles.length !== 26) {
  throw new Error(`Expected 26 source and 26 final files; got ${sourceFiles.length} and ${finalFiles.length}`);
}

const sourceByEpisode = new Map(sourceFiles.map((file) => [episodeNumber(file), file]));
const rows = [];
const summary = [];

for (const finalFile of finalFiles.sort((a, b) => episodeNumber(a) - episodeNumber(b))) {
  const episode = episodeNumber(finalFile);
  const sourceFile = sourceByEpisode.get(episode);
  const sourceEvents = parseSrt(fs.readFileSync(sourceFile, 'utf8'));
  const sourceCorpus = normalizeJapanese(sourceEvents.map((event) => event.text).join(''));
  const finalEvents = parseAss(fs.readFileSync(finalFile, 'utf8'));
  const chineseByAxis = new Map();
  for (const event of finalEvents.filter((item) => item.style.startsWith('CN-'))) {
    const key = `${event.start}|${event.end}`;
    if (!chineseByAxis.has(key)) chineseByAxis.set(key, []);
    chineseByAxis.get(key).push(stripAss(event.text));
  }
  let checked = 0;
  let covered = 0;
  for (const event of finalEvents.filter((item) => item.style.startsWith('JP-'))) {
    const normalized = normalizeJapanese(event.text);
    if (!normalized) continue;
    checked += 1;
    const exactInOfficial = sourceCorpus.includes(normalized);
    if (exactInOfficial) covered += 1;
    rows.push([
      `E${String(episode).padStart(2, '0')}`, event.start, event.end, event.style,
      exactInOfficial ? 'YES' : 'NO', stripAss(event.text),
      (chineseByAxis.get(`${event.start}|${event.end}`) || []).join(' / '),
    ]);
  }
  summary.push({ episode, sourceEvents: sourceEvents.length, checked, covered, rate: covered / checked });
}

fs.mkdirSync(path.dirname(outFile), { recursive: true });
fs.writeFileSync(outFile, '\uFEFF' + [
  ['集数', '开始', '结束', '日文样式', '官方原文全文命中', '成品日文', '同轴中文'].join('\t'),
  ...rows.map((row) => row.map((value) => String(value).replace(/[\t\r\n]+/g, ' ')).join('\t')),
].join('\r\n'), 'utf8');

console.log(JSON.stringify({
  output: outFile,
  total: summary.reduce((acc, item) => ({ checked: acc.checked + item.checked, covered: acc.covered + item.covered }), { checked: 0, covered: 0 }),
  episodes: summary,
  unmatched: rows.filter((row) => row[4] === 'NO').length,
}, null, 2));
