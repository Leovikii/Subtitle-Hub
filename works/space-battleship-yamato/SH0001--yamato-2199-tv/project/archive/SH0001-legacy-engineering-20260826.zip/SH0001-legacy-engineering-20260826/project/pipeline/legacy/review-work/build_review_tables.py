from __future__ import annotations

import csv
import re
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TV_FINAL = ROOT / "outputs" / "宇宙战舰大和号2199.TV.简日双语.精校"
MOVIE_FINAL = (
    ROOT
    / "outputs"
    / "宇宙战舰大和号2199 星巡的方舟.简日双语.精校"
    / "宇宙战舰大和号2199 星巡的方舟.ass"
)
TV_EN = ROOT / "review_work" / "english_tv"
MOVIE_EN = Path(r"C:\Users\Vki\Documents\Codex\2026-08-23\jiao-d\work\odyssey_en.ass")
OUT = ROOT / "review_work" / "tables"


@dataclass
class Event:
    kind: str
    layer: int
    start: float
    end: float
    style: str
    name: str
    effect: str
    text: str
    clean: str


def ts_seconds(value: str) -> float:
    h, m, s = value.split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)


def fmt_ts(value: float) -> str:
    h = int(value // 3600)
    m = int(value % 3600 // 60)
    s = value % 60
    return f"{h}:{m:02d}:{s:05.2f}"


TAG_RE = re.compile(r"\{[^{}]*\}")


def clean_ass_text(value: str) -> str:
    value = TAG_RE.sub("", value)
    value = value.replace(r"\N", " / ").replace(r"\n", " / ").replace(r"\h", " ")
    value = value.replace("　", " ")
    return re.sub(r"\s+", " ", value).strip()


def read_ass(path: Path) -> list[Event]:
    events: list[Event] = []
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for line in text.splitlines():
        if not (line.startswith("Dialogue:") or line.startswith("Comment:")):
            continue
        kind, rest = line.split(":", 1)
        fields = rest.lstrip().split(",", 9)
        if len(fields) != 10:
            continue
        try:
            events.append(
                Event(
                    kind=kind,
                    layer=int(fields[0]),
                    start=ts_seconds(fields[1]),
                    end=ts_seconds(fields[2]),
                    style=fields[3],
                    name=fields[4],
                    effect=fields[8],
                    text=fields[9],
                    clean=clean_ass_text(fields[9]),
                )
            )
        except ValueError:
            continue
    return events


def ep_number(path: Path) -> str:
    m = re.search(r"S01E(\d{2})", path.name)
    if not m:
        raise ValueError(path)
    return m.group(1)


def overlap(a: Event, b: Event) -> float:
    return max(0.0, min(a.end, b.end) - max(a.start, b.start))


def matching_japanese(cn: Event, events: list[Event]) -> list[Event]:
    style_map = {
        "CN-Main": {"JP-Main"},
        "CN-Main-OS": {"JP-Main"},
        "CN-Top": {"JP-Top"},
        "ED-CN": {"ED-JP"},
    }
    target = style_map.get(cn.style, set())
    if not target:
        return []
    exact = [
        e
        for e in events
        if e.kind == "Dialogue"
        and e.style in target
        and abs(e.start - cn.start) < 0.011
        and abs(e.end - cn.end) < 0.011
    ]
    return sorted(exact, key=lambda x: (x.start, x.layer))


def matching_english(cn: Event, events: list[Event], top: bool = False) -> list[Event]:
    candidates = []
    for e in events:
        if e.kind != "Dialogue" or not e.clean:
            continue
        ov = overlap(cn, e)
        if ov <= 0:
            continue
        shortest = max(0.01, min(cn.end - cn.start, e.end - e.start))
        if ov / shortest < 0.18 and ov < 0.30:
            continue
        candidates.append(e)
    if not candidates:
        # A small tolerance handles two subtitle tracks whose cuts differ by a few frames.
        candidates = [
            e
            for e in events
            if e.kind == "Dialogue"
            and e.clean
            and abs(e.start - cn.start) <= 0.35
        ]
    if not candidates:
        return []
    if top:
        preferred = [e for e in candidates if e.style.lower() not in {"default", "dialogue"}]
    else:
        preferred = [e for e in candidates if e.style.lower() in {"default", "dialogue", "main"}]
    chosen = preferred or candidates
    return sorted(chosen, key=lambda x: (x.start, x.end, x.style))


def unique_text(events: list[Event]) -> str:
    out: list[str] = []
    for e in events:
        if e.clean and e.clean not in out:
            out.append(e.clean)
    return " | ".join(out)


def digit_tokens(text: str) -> set[str]:
    return set(re.findall(r"\d+(?:\.\d+)?", text))


def candidate_reasons(cn: str, jp: str, en: str, style: str) -> list[str]:
    reasons: list[str] = []
    if style in {"CN-Main", "CN-Main-OS", "CN-Top", "ED-CN"} and not jp:
        reasons.append("缺少同轴日文")
    cn_digits = digit_tokens(cn)
    source_digits = digit_tokens(jp) | digit_tokens(en)
    if source_digits and cn_digits != source_digits:
        reasons.append(f"数字需核对（中={sorted(cn_digits)}，源={sorted(source_digits)}）")

    # High-value lexical checks; every hit still requires manual review.
    rules = [
        (r"長官", r"长官|司令|阁下", "称谓“長官”可能误译"),
        (r"艦長", r"舰长|船长", "称谓“艦長”可能漏译/误译"),
        (r"右舷|starboard", r"右舷|右侧|右方|右边", "左右舷方向需核对"),
        (r"左舷|port side", r"左舷|左侧|左方|左边", "左右舷方向需核对"),
        (r"撤退|retreat|withdraw", r"撤退|退却|撤离|后撤", "撤退语义可能漏译"),
        (r"降伏|surrender", r"投降|降服", "投降语义可能漏译"),
        (r"戦死|killed in action", r"战死|阵亡|牺牲", "战死语义可能漏译"),
        (r"死亡|dead|died|death", r"死|亡|牺牲", "死亡语义可能漏译"),
        (r"生き|alive|survive", r"活|生存|幸存", "生存语义可能漏译"),
        (r"命令|order", r"命令|下令|指示", "命令语气可能弱化"),
        (r"禁止|forbidden|prohibit", r"禁止|不得|不许", "禁止语义可能漏译"),
        (r"必ず|definitely|without fail", r"一定|必定|务必", "肯定程度可能漏译"),
        (r"絶対|absolutely|never", r"绝对|决不|绝不", "绝对程度可能漏译"),
    ]
    source = f"{jp} {en}".lower()
    for source_re, cn_re, message in rules:
        if re.search(source_re, source, re.I) and not re.search(cn_re, cn):
            reasons.append(message)

    # Negation mismatch is deliberately conservative.
    jp_neg = bool(re.search(r"ない|ぬ(?:[。！!？?]|$)|ず(?:[。！!？?]|$)|できん|ならん|いかん", jp))
    en_neg = bool(re.search(r"\b(no|not|never|cannot|can't|won't|without|nothing|nobody)\b", en, re.I))
    cn_neg = bool(re.search(r"不|没|无|未|别|莫|勿|休想|甭", cn))
    if jp_neg and en_neg and not cn_neg:
        reasons.append("日英均含否定，中文可能漏掉否定")
    if cn_neg and not jp_neg and en and not en_neg and len(cn) >= 6:
        reasons.append("中文含否定而日英未见，可能存在增译/反义")

    cn_core = len(re.sub(r"[\W_\s]", "", cn))
    jp_core = len(re.sub(r"[\W_\s]", "", jp))
    if jp_core >= 4 and cn_core >= max(18, int(jp_core * 1.75)):
        reasons.append("中文明显长于日文，检查解释性增译")

    if re.search(r"[!！]{2,}|[?？]{2,}|[!！][?？]|[?？][!！]", cn):
        reasons.append("标点或情绪可能过强")
    if "  " in cn:
        reasons.append("连续空格")
    return reasons


def rows_for_work(
    work: str,
    final_events: list[Event],
    en_dialogue: list[Event],
    en_signs: list[Event] | None = None,
) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    en_all = en_dialogue + (en_signs or [])
    cn_styles = {"CN-Main", "CN-Main-OS", "CN-Top", "CN-Alien", "ED-CN"}
    for index, cn in enumerate(final_events, 1):
        if cn.kind != "Dialogue" or cn.style not in cn_styles or not cn.clean:
            continue
        jp_matches = matching_japanese(cn, final_events)
        en_matches = matching_english(cn, en_all, top=cn.style == "CN-Top")
        jp = unique_text(jp_matches)
        en = unique_text(en_matches)
        reasons = candidate_reasons(cn.clean, jp, en, cn.style)
        rows.append(
            {
                "作品": work,
                "序号": str(index),
                "时间": fmt_ts(cn.start),
                "结束": fmt_ts(cn.end),
                "样式": cn.style,
                "中文": cn.clean,
                "日文": jp,
                "英文": en,
                "自动候选原因": "；".join(reasons),
            }
        )
    return rows


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["作品", "序号", "时间", "结束", "样式", "中文", "日文", "英文", "自动候选原因"]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    all_rows: list[dict[str, str]] = []
    for final_path in sorted(TV_FINAL.glob("*.ass")):
        ep = ep_number(final_path)
        final_events = read_ass(final_path)
        dialogue_events = read_ass(TV_EN / f"E{ep}.dialogue.ass")
        signs_events = read_ass(TV_EN / f"E{ep}.signs.ass")
        all_rows.extend(rows_for_work(f"TV E{ep}", final_events, dialogue_events, signs_events))

    all_rows.extend(
        rows_for_work(
            "星巡的方舟",
            read_ass(MOVIE_FINAL),
            read_ass(MOVIE_EN),
        )
    )
    candidates = [row for row in all_rows if row["自动候选原因"]]
    write_tsv(OUT / "all_dialogue_trilingual.tsv", all_rows)
    write_tsv(OUT / "automatic_candidates.tsv", candidates)

    print(f"all_rows={len(all_rows)}")
    print(f"automatic_candidates={len(candidates)}")
    no_jp = sum("缺少同轴日文" in r["自动候选原因"] for r in all_rows)
    no_en = sum(not r["英文"] for r in all_rows)
    print(f"no_same_axis_japanese={no_jp}")
    print(f"no_overlapping_english={no_en}")


if __name__ == "__main__":
    main()
