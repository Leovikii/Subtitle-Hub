const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(
  root,
  'outputs',
  '宇宙战舰大和号2199 星巡的方舟.简日双语.精校',
  '宇宙战舰大和号2199 星巡的方舟.ass',
);

function episodeFile(number) {
  const token = `S01E${String(number).padStart(2, '0')}`;
  const matches = fs.readdirSync(tvDir).filter((name) => name.includes(token) && name.endsWith('.ass'));
  if (matches.length !== 1) {
    throw new Error(`Expected exactly one ${token} ASS, found ${matches.length}`);
  }
  return path.join(tvDir, matches[0]);
}

function readAss(file) {
  const raw = fs.readFileSync(file);
  const hasBom = raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  return { text: raw.toString('utf8').replace(/^\uFEFF/, ''), hasBom };
}

function writeAss(file, text, hasBom) {
  fs.writeFileSync(file, `${hasBom ? '\uFEFF' : ''}${text}`, 'utf8');
}

function replaceOnce(text, oldText, newText, label) {
  const first = text.indexOf(oldText);
  if (first < 0) {
    if (newText === '' || text.includes(newText)) return text;
    throw new Error(`${label}: old text not found: ${oldText}`);
  }
  if (text.indexOf(oldText, first + oldText.length) >= 0) {
    throw new Error(`${label}: old text is not unique: ${oldText}`);
  }
  return text.slice(0, first) + newText + text.slice(first + oldText.length);
}

function replaceAllCount(text, oldText, newText) {
  const pieces = text.split(oldText);
  return { text: pieces.join(newText), count: pieces.length - 1 };
}

const episodeChanges = new Map([
  [1, [
    ['Dialogue: 10,0:02:02.50,0:02:02.86,CN-Main,,0,0,0,,舰长！', 'Dialogue: 10,0:02:02.50,0:02:02.86,CN-Main,,0,0,0,,长官！'],
    ['Dialogue: 10,0:04:23.05,0:04:25.42,CN-Main,,0,0,0,,「雾岛」 冲田舰长发来暗号', 'Dialogue: 10,0:04:23.05,0:04:25.42,CN-Main,,0,0,0,,“雾岛”收到冲田司令的密码电报'],
    ['Dialogue: 10,0:09:31.11,0:09:31.70,CN-Main,,0,0,0,,舰长', 'Dialogue: 10,0:09:31.11,0:09:31.70,CN-Main,,0,0,0,,长官'],
    ['Dialogue: 10,0:13:44.74,0:13:47.43,CN-Main,,0,0,0,,结果 人类连建立地下都市', 'Dialogue: 10,0:13:44.74,0:13:47.43,CN-Main,,0,0,0,,结果，人类不得不修建地下都市，'],
    ['Dialogue: 10,0:13:48.16,0:13:50.83,CN-Main,,0,0,0,,苟延残喘生存下去的希望也没有了', 'Dialogue: 10,0:13:48.16,0:13:50.83,CN-Main,,0,0,0,,除了躲入其中求生，已别无他路。'],
    ['Dialogue: 10,0:20:03.77,0:20:07.12,CN-Main,,0,0,0,,敌军的目标是九州簿之岬海域 北纬30度', 'Dialogue: 10,0:20:03.77,0:20:07.12,CN-Main,,0,0,0,,敌军目标推定为九州坊之岬海域，北纬30度40分……'],
  ]],
  [6, [
    ['Dialogue: 10,0:08:09.94,0:08:15.24,CN-Main,,0,0,0,,我说根本啊 那个叫山本的新人挺能干的嘛', 'Dialogue: 10,0:08:09.94,0:08:15.24,CN-Main,,0,0,0,,我说，根本，那个叫山本的新人挺亮眼的嘛。'],
    ['Dialogue: 10,0:09:11.88,0:09:14.11,CN-Main,,0,0,0,,恐怕是「大和号」的余孽吧', 'Dialogue: 10,0:09:11.88,0:09:14.11,CN-Main,,0,0,0,,恐怕是“大和号”的幸存者吧。'],
    ['Dialogue: 10,0:14:49.63,0:14:50.30,CN-Main,,0,0,0,,眼睛？！', 'Dialogue: 10,0:14:49.63,0:14:50.30,CN-Main,,0,0,0,,用眼睛？'],
  ]],
  [7, [
    ['Dialogue: 10,0:15:58.54,0:16:03.28,CN-Main,,0,0,0,,别看他那样 其实面对生死比普通人要敏感两倍呢', 'Dialogue: 10,0:15:58.54,0:16:03.28,CN-Main,,0,0,0,,别看他那样，其实他对人的生死比常人更敏感。'],
  ]],
  [8, [
    ['Dialogue: 10,0:10:48.89,0:10:53.57,CN-Main,,0,0,0,,那么诸位 让我们举起酒杯 为地球人的垂死挣扎祈愿吧', 'Dialogue: 10,0:10:48.89,0:10:53.57,CN-Main,,0,0,0,,诸位，让我们举杯，祝地球人奋战到底。'],
  ]],
  [9, [
    ['Dialogue: 10,0:11:15.05,0:11:18.34,CN-Main,,0,0,0,,如果错误继续发生', 'Dialogue: 10,0:11:15.05,0:11:18.34,CN-Main,,0,0,0,,如果错误继续发生，就必须把你初始化。'],
    ['Dialogue: 10,0:16:50.17,0:16:53.43,CN-Main,,0,0,0,,但也不能断言，我们的大脑就不是同样的', 'Dialogue: 10,0:16:50.17,0:16:53.43,CN-Main,,0,0,0,,但也无法断言，我们的大脑不是同样依靠'],
    ['Dialogue: 10,0:16:53.43,0:16:57.28,CN-Main,,0,0,0,,通过多分支、多重处理运作的自动机', 'Dialogue: 10,0:16:53.43,0:16:57.28,CN-Main,,0,0,0,,多重并行处理运作的自动机。'],
  ]],
  [10, [
    ['Dialogue: 10,0:07:29.77,0:07:31.26,CN-Top,,0,0,0,,[方位 4500]', ''],
    ['Dialogue: 11,0:07:29.77,0:07:31.26,JP-Top,,0,0,0,,距離7450', ''],
  ]],
  [15, [
    ['Dialogue: 10,0:10:24.08,0:10:25.86,CN-Main,,0,0,0,,最终应该会在这个五个点中的一个', 'Dialogue: 10,0:10:24.08,0:10:25.86,CN-Main,,0,0,0,,最终应该会在这五个点中的一个'],
  ]],
  [16, [
    ['Dialogue: 10,0:14:51.05,0:14:52.81,CN-Main,,0,0,0,,以及贯彻希望的的勇气', 'Dialogue: 10,0:14:51.05,0:14:52.81,CN-Main,,0,0,0,,以及将希望贯彻到底的勇气'],
  ]],
  [17, [
    ['Dialogue: 10,0:03:03.89,0:03:06.87,CN-Main,,0,0,0,,不同与制造出星际门的文明', 'Dialogue: 10,0:03:03.89,0:03:06.87,CN-Main,,0,0,0,,不同于制造出星际门的文明'],
  ]],
  [18, [
    ['Dialogue: 10,0:02:07.62,0:02:12.84,CN-Main,,0,0,0,,在她的帮助下 我们成功的复制了星际门的控制系统', 'Dialogue: 10,0:02:07.62,0:02:12.84,CN-Main,,0,0,0,,在她的帮助下，我们成功地复制了星际门的控制系统'],
  ]],
  [19, [
    ['Dialogue: 10,0:14:52.22,0:14:53.81,CN-Main,,0,0,0,,所预测的的航路', 'Dialogue: 10,0:14:52.22,0:14:53.81,CN-Main,,0,0,0,,所预测的航路'],
  ]],
  [21, [
    ['Dialogue: 10,0:21:44.22,0:21:46.26,CN-Main,,0,0,0,,我知道他们去哪了', 'Dialogue: 10,0:21:44.22,0:21:46.26,CN-Main,,0,0,0,,我知道她被带到哪里了。'],
  ]],
  [22, [
    ['Dialogue: 10,0:08:10.11,0:08:14.43,CN-Main,,0,0,0,,他的父亲在和蛮族的战舰作战时牺牲了', 'Dialogue: 10,0:08:10.11,0:08:14.43,CN-Main,,0,0,0,,那孩子的父亲在与蛮族战舰交战时牺牲了。'],
    ['Dialogue: 10,0:09:52.46,0:09:56.47,CN-Main,,0,0,0,,是他亲手把我从那里就出来的', 'Dialogue: 10,0:09:52.46,0:09:56.47,CN-Main,,0,0,0,,是他亲手把我从那里救出来的。'],
    ['Dialogue: 10,0:10:02.64,0:10:04.10,CN-Main,,0,0,0,,你爱她吗？', 'Dialogue: 10,0:10:02.64,0:10:04.10,CN-Main,,0,0,0,,你爱他吗？'],
  ]],
  [24, [
    ['Dialogue: 10,0:10:31.86,0:10:37.58,CN-Main,,0,0,0,,还有一点要向您说明的是', 'Dialogue: 10,0:10:31.86,0:10:37.58,CN-Main,,0,0,0,,还有一点，我必须补充说明：'],
    ['Dialogue: 10,0:10:37.74,0:10:39.41,CN-Main,,0,0,0,,一门使用波动能量的大炮', 'Dialogue: 10,0:10:37.74,0:10:39.41,CN-Main,,0,0,0,,救了我们的，正是使用波动能量的大炮。'],
  ]],
  [25, [
    ['Dialogue: 10,0:10:30.74,0:10:33.12,CN-Main,,0,0,0,,地方宇宙舰艇从本舰左舷方通过！', 'Dialogue: 10,0:10:30.74,0:10:33.12,CN-Main,,0,0,0,,敌方次元潜水艇从本舰左舷驶过！'],
  ]],
  [26, [
    ['Dialogue: 10,0:06:56.58,0:07:01.90,CN-Main,,0,0,0,,山崎虽然优秀 但我的真本事还没有传授给他', 'Dialogue: 10,0:06:56.58,0:07:01.90,CN-Main,,0,0,0,,山崎虽然优秀，但我们这份精神还没有完全传给他。'],
    ['Dialogue: 10,0:07:10.36,0:07:13.69,CN-Main,,0,0,0,,他的弟弟已经出色的继承了他', 'Dialogue: 10,0:07:10.36,0:07:13.69,CN-Main,,0,0,0,,他的弟弟已经出色地继承了他。'],
    ['Dialogue: 10,0:10:15.58,0:10:19.69,CN-Main,,0,0,0,,古代就说「办个婚礼吧 就该这么庆祝」', 'Dialogue: 10,0:10:15.58,0:10:19.69,CN-Main,,0,0,0,,古代还说：“办场庆祝会吧，就该这么庆祝！”'],
  ]],
]);

const movieChanges = [
  ['Dialogue: 10,0:01:14.59,0:01:16.63,CN-Main,,0,0,0,,这才是空间骑兵。', 'Dialogue: 10,0:01:14.59,0:01:16.63,CN-Main,,0,0,0,,这才是空间骑兵的精神。'],
  ['Dialogue: 10,0:12:22.09,0:12:23.80,CN-Main,,0,0,0,,你知道得还真详细啊，根本。', 'Dialogue: 10,0:12:22.09,0:12:23.80,CN-Main,,0,0,0,,根本，你知道得真详细啊。'],
  ['Dialogue: 10,0:31:45.05,0:31:46.41,CN-Main,,0,0,0,,居然没死？', 'Dialogue: 10,0:31:45.05,0:31:46.41,CN-Main,,0,0,0,,居然还没沉？'],
  ['Dialogue: 10,1:03:14.18,1:03:16.02,CN-Main,,0,0,0,,终于理解了“水”这个词。”', 'Dialogue: 10,1:03:14.18,1:03:16.02,CN-Main,,0,0,0,,终于理解了“水”这个词。'],
];

const globalTerminology = [
  ['次元潜航舰', '次元潜水艇'],
  ['次元潜艇', '次元潜水艇'],
  ['自动航行室', '自动导航室'],
  ['自动航法室', '自动导航室'],
  ['伽米佬', '加米佬'],
  ['加米拉斯佬', '加米佬'],
  ['航行长', '航海长'],
  ['大麦哲伦星云', '大麦哲伦云'],
  ['大麦哲伦星系', '大麦哲伦云'],
  ['波动防壁', '波动防御壁'],
  ['奇姆雷', '基姆雷'],
  ['杰力克', '泽里克'],
  ['佛姆特·巴伽', '弗姆特·伯格'],
  ['佛姆特·巴格', '弗姆特·伯格'],
  ['萨尔茨', '扎尔茨'],
  ['希尔达', '希尔德'],
  ['德斯拉', '迪斯拉'],
];

const punctuationAndFluency = [
  ['是 诶？！', '是……诶？'],
  ['什…什么？！', '什……什么？'],
  ['什…！？', '什……？'],
  ['到…到底怎么回事！？', '到……到底怎么回事？'],
  ['次…次元潜水艇！？', '次……次元潜水艇？'],
  ['怎么了！？', '怎么了？'],
  ['你以为我是谁！？', '你以为我是谁？'],
  ['雪！！', '雪——！'],
  ['不！！', '不——！'],
  ['什么！？', '什么？'],
  ['古代？！', '古代？'],
  ['你的所属哪里！？', '你隶属于哪里？'],
  ['[第七战斗团前进！！]', '[第七战斗团，前进！]'],
  ['[楔入敌阵！！！]', '[楔入敌阵！]'],
  ['你说什么？！', '你说什么？'],
  ['什么？！', '什么？'],
  ['说什么！？', '说什么？'],
];

const allFiles = fs.readdirSync(tvDir)
  .filter((name) => name.endsWith('.ass'))
  .map((name) => path.join(tvDir, name));
if (allFiles.length !== 26) throw new Error(`Expected 26 TV ASS files, found ${allFiles.length}`);

const directLog = [];
for (const [episode, changes] of episodeChanges) {
  const file = episodeFile(episode);
  const loaded = readAss(file);
  let text = loaded.text;
  for (const [oldText, newText] of changes) {
    text = replaceOnce(text, oldText, newText, `E${String(episode).padStart(2, '0')}`);
    directLog.push(`E${String(episode).padStart(2, '0')}: ${oldText.split(',,').at(-1)} -> ${newText.split(',,').at(-1)}`);
  }
  writeAss(file, text, loaded.hasBom);
}

{
  const loaded = readAss(movieFile);
  let text = loaded.text;
  for (const [oldText, newText] of movieChanges) {
    text = replaceOnce(text, oldText, newText, 'Movie');
    directLog.push(`Movie: ${oldText.split(',,').at(-1)} -> ${newText.split(',,').at(-1)}`);
  }
  writeAss(movieFile, text, loaded.hasBom);
}

const terminologyCounts = new Map();
const punctuationCounts = new Map();
for (const file of [...allFiles, movieFile]) {
  const loaded = readAss(file);
  let text = loaded.text;
  for (const [oldText, newText] of globalTerminology) {
    const result = replaceAllCount(text, oldText, newText);
    text = result.text;
    terminologyCounts.set(`${oldText} -> ${newText}`, (terminologyCounts.get(`${oldText} -> ${newText}`) || 0) + result.count);
  }
  for (const [oldText, newText] of punctuationAndFluency) {
    const result = replaceAllCount(text, oldText, newText);
    text = result.text;
    punctuationCounts.set(`${oldText} -> ${newText}`, (punctuationCounts.get(`${oldText} -> ${newText}`) || 0) + result.count);
  }
  writeAss(file, text, loaded.hasBom);
}

console.log(JSON.stringify({
  directChanges: directLog,
  terminology: Object.fromEntries([...terminologyCounts].filter(([, count]) => count > 0)),
  punctuation: Object.fromEntries([...punctuationCounts].filter(([, count]) => count > 0)),
}, null, 2));
