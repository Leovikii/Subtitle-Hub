const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const fallbackDir = path.join(root, 'sources', 'tv_old_kamigami_embedded_fallback');
const outFile = path.join(__dirname, 'tables', 'missing_japanese_kamigami_candidates.tsv');

function seconds(value) {
  const [h, m, s] = value.split(':');
  return Number(h) * 3600 + Number(m) * 60 + Number(s);
}

function episodeNumber(file) {
  return Number(file.match(/E(\d{2})|S01E(\d{2})/).slice(1).find(Boolean));
}

function stripAss(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ').replace(/\\h/g, ' ').replace(/\s+/g, ' ').trim();
}

function normalize(text) {
  return stripAss(text)
    .replace(/[０-９]/g, (char) => String(char.charCodeAt(0) - 0xff10))
    .replace(/[\s\u3000「」『』“”‘’\[\]【】〈〉《》！？!?…‥〜～・、。，．：:；;―—ｰー]/g, '')
    .toLowerCase();
}

function parseAss(text) {
  return text.replace(/^\uFEFF/, '').split(/\r?\n/).flatMap((line) => {
    const match = line.match(/^Dialogue: ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
    if (!match) return [];
    return [{ start: seconds(match[2]), end: seconds(match[3]), startRaw: match[2], endRaw: match[3], style: match[4], text: stripAss(match[10]), norm: normalize(match[10]) }];
  });
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)] || 0;
}

const rows = [];
for (const finalName of fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort()) {
  const episode = episodeNumber(finalName);
  const finalEvents = parseAss(fs.readFileSync(path.join(tvDir, finalName), 'utf8'));
  const fallbackFile = path.join(fallbackDir, `E${String(episode).padStart(2, '0')}.kamigami.jpn.ass`);
  const fallbackEvents = parseAss(fs.readFileSync(fallbackFile, 'utf8')).filter((event) => /jp/i.test(event.style) || event.style === 'JP');
  const byNorm = new Map();
  for (const event of fallbackEvents) {
    if (!event.norm) continue;
    if (!byNorm.has(event.norm)) byNorm.set(event.norm, []);
    byNorm.get(event.norm).push(event);
  }
  const offsets = [];
  for (const event of finalEvents.filter((item) => /^JP-(Main|Top)$/.test(item.style))) {
    const matches = byNorm.get(event.norm) || [];
    if (matches.length === 1) offsets.push(matches[0].start - event.start);
  }
  const offset = median(offsets.filter((value) => Math.abs(value) < 5));
  const jpAxis = new Set(finalEvents.filter((event) => /^JP-(Main|Top)$/.test(event.style)).map((event) => `${event.startRaw}|${event.endRaw}|${event.style === 'JP-Top' ? 'top' : 'main'}`));
  for (const cn of finalEvents.filter((event) => ['CN-Main', 'CN-Main-OS', 'CN-Top'].includes(event.style))) {
    const axisType = cn.style === 'CN-Top' ? 'top' : 'main';
    if (jpAxis.has(`${cn.startRaw}|${cn.endRaw}|${axisType}`)) continue;
    const mappedStart = cn.start + offset;
    const mappedEnd = cn.end + offset;
    const candidates = fallbackEvents.filter((event) => Math.min(event.end, mappedEnd + 0.22) - Math.max(event.start, mappedStart - 0.22) > 0 && event.text);
    rows.push([
      `E${String(episode).padStart(2, '0')}`, cn.startRaw, cn.endRaw, cn.style, cn.text,
      offset.toFixed(3), candidates.map((event) => event.text).join(' | '),
      candidates.map((event) => `${event.startRaw}-${event.endRaw}`).join(' | '),
    ]);
  }
}

fs.writeFileSync(outFile, '\uFEFF' + [
  ['集数', '目标开始', '目标结束', '中文样式', '中文', '旧轨相对偏移', '旧日文候选', '旧候选时间'].join('\t'),
  ...rows.map((row) => row.map((value) => String(value).replace(/[\t\r\n]+/g, ' ')).join('\t')),
].join('\r\n'), 'utf8');
console.log(JSON.stringify({ output: outFile, rows: rows.length }, null, 2));
