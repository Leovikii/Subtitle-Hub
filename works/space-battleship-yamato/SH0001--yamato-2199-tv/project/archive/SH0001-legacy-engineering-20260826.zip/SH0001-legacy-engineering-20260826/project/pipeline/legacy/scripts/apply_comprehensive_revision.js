const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(root, 'outputs', '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');

function episodeFile(number) {
  const token = `S01E${String(number).padStart(2, '0')}`;
  const names = fs.readdirSync(tvDir).filter((name) => name.includes(token) && name.endsWith('.ass'));
  if (names.length !== 1) throw new Error(`Expected one ${token} ASS, found ${names.length}`);
  return path.join(tvDir, names[0]);
}

function parseEvent(line) {
  const match = line.match(/^(Dialogue|Comment): ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    kind: match[1], layer: match[2], start: match[3], end: match[4], style: match[5],
    name: match[6], marginL: match[7], marginR: match[8], marginV: match[9],
    effect: match[10], text: match[11],
  };
}

function serializeEvent(event) {
  return `${event.kind}: ${event.layer},${event.start},${event.end},${event.style},${event.name},${event.marginL},${event.marginR},${event.marginV},${event.effect},${event.text}`;
}

function readAss(file) {
  const raw = fs.readFileSync(file);
  const bom = raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  const text = raw.toString('utf8').replace(/^\uFEFF/, '');
  return { bom, newline: text.includes('\r\n') ? '\r\n' : '\n', lines: text.split(/\r?\n/) };
}

function writeAss(file, loaded) {
  fs.writeFileSync(file, `${loaded.bom ? '\uFEFF' : ''}${loaded.lines.join(loaded.newline)}`, 'utf8');
}

function applyTarget(file, target) {
  const loaded = readAss(file);
  const matches = [];
  for (let index = 0; index < loaded.lines.length; index++) {
    const event = parseEvent(loaded.lines[index]);
    if (!event || event.kind !== 'Dialogue') continue;
    if (event.start === target.start && event.end === target.end && event.style === target.style) {
      if (target.oldText === undefined || event.text === target.oldText) matches.push({ index, event });
    }
  }
  if (matches.length !== 1) {
    const already = loaded.lines.map(parseEvent).filter(Boolean).find((event) =>
      event.kind === 'Dialogue' && event.start === target.start && event.end === target.end &&
      event.style === (target.newStyle || target.style) &&
      (target.newText === undefined || event.text === target.newText));
    if (already) return false;
    throw new Error(`${path.basename(file)} ${target.start}-${target.end} ${target.style}: expected one target, found ${matches.length}`);
  }

  const { index, event } = matches[0];
  if (target.remove) {
    loaded.lines.splice(index, 1);
    writeAss(file, loaded);
    return true;
  }
  if (target.newStyle) event.style = target.newStyle;
  if (target.newText !== undefined) event.text = target.newText;
  loaded.lines[index] = serializeEvent(event);

  if (target.jpText !== undefined) {
    const jpStyle = target.jpStyle || (event.style === 'CN-Top' ? 'JP-Top' : 'JP-Main');
    const acceptedJpStyles = new Set([jpStyle, target.jpFromStyle].filter(Boolean));
    const sameAxis = loaded.lines.map((line, lineIndex) => ({ lineIndex, event: parseEvent(line) }))
      .filter(({ event: candidate }) => candidate && candidate.kind === 'Dialogue' &&
        candidate.start === event.start && candidate.end === event.end && acceptedJpStyles.has(candidate.style));
    const jpEvent = {
      kind: 'Dialogue', layer: '11', start: event.start, end: event.end, style: jpStyle,
      name: '', marginL: '0', marginR: '0', marginV: '0', effect: '', text: target.jpText,
    };
    if (sameAxis.length === 0) loaded.lines.splice(index + 1, 0, serializeEvent(jpEvent));
    else {
      const preferred = sameAxis.find(({ event: candidate }) => candidate.style === jpStyle) || sameAxis[0];
      loaded.lines[preferred.lineIndex] = serializeEvent(jpEvent);
      for (const duplicate of sameAxis.filter((candidate) => candidate !== preferred).sort((a, b) => b.lineIndex - a.lineIndex)) {
        loaded.lines.splice(duplicate.lineIndex, 1);
      }
    }
  }
  writeAss(file, loaded);
  return true;
}

const targets = new Map();
function add(ep, start, end, style, jpText, extra = {}) {
  if (!targets.has(ep)) targets.set(ep, []);
  targets.get(ep).push({ start, end, style, jpText, ...extra });
}

// Missing ordinary dialogue, background speech and broadcast Japanese.  The Japanese
// always reuses the Chinese target axis so both lines enter and leave together.
add(1, '0:00:40.88', '0:00:42.92', 'CN-Top', '両舷前進原速 黒15');
add(1, '0:01:31.03', '0:01:33.15', 'CN-Top', '「測的開始 仰角調整」', { newText: '“开始测定，调整俯仰角”' });
add(1, '0:03:15.19', '0:03:16.57', 'CN-Main', 'ちくしょう！');
add(1, '0:09:27.84', '0:09:31.70', 'CN-Top', '俺たちゃ宇宙の');
add(1, '0:09:31.80', '0:09:37.65', 'CN-Top', '俺たちゃ宇宙の船乗りさ');
add(1, '0:12:03.93', '0:12:04.64', 'CN-Main', '駄目だ');
add(1, '0:15:00.27', '0:15:04.91', 'CN-Top', '本日16時30分 第六管区で暴動が発生しました', { newText: '今天16时30分，第六区发生骚乱。' });
add(1, '0:21:08.80', '0:21:09.85', 'CN-Main', 'くそっ');

add(3, '0:07:37.16', '0:07:37.70', 'CN-Main', '来た');
for (const [start, end, cn, jp] of [
  ['0:07:56.10','0:07:56.54','十','十'], ['0:07:57.05','0:07:57.76','九','九'],
  ['0:07:58.10','0:07:58.97','八','八'], ['0:07:58.97','0:07:59.60','七','七'],
  ['0:08:00.10','0:08:01.06','六','六'], ['0:08:01.06','0:08:01.54','五','五'],
  ['0:08:02.10','0:08:02.56','四','四'], ['0:08:03.10','0:08:03.63','三','三'],
  ['0:08:04.19','0:08:04.98','二','二'], ['0:08:05.31','0:08:06.10','一','一'],
  ['0:20:02.36','0:20:02.65','九','九'], ['0:20:03.11','0:20:03.64','八','八'],
  ['0:20:04.11','0:20:04.59','七','七'], ['0:20:05.12','0:20:05.62','六','六'],
  ['0:20:06.12','0:20:06.55','五','五'], ['0:20:07.08','0:20:07.52','四','四'],
  ['0:20:08.12','0:20:08.56','三','三'], ['0:20:09.24','0:20:09.60','二','二'],
  ['0:20:10.25','0:20:10.70','一','一'],
]) add(3, start, end, 'CN-Main', jp, { oldText: cn });

add(4, '0:16:01.71', '0:16:02.24', 'CN-Main', 'あれ？', { newText: '咦？' });
add(4, '0:19:01.22', '0:19:02.09', 'CN-Main', 'くそっ');
add(5, '0:05:21.50', '0:05:22.19', 'CN-Main', 'さあ');
add(6, '0:08:31.17', '0:08:39.22', 'CN-Main', '…五蘊皆空 度一切苦厄 舎利子 色不異空 空不異色…', {
  newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '……五蕴皆空，度一切苦厄。舍利子，色不异空，空不异色……',
});
add(6, '0:09:07.41', '0:09:08.46', 'CN-Top', '今 敵機数確認', { newText: '正在确认敌机数量。' });
add(6, '0:09:34.94', '0:09:35.69', 'CN-Main', 'きれい…', { newText: '好美……' });

add(7, '0:09:05.04', '0:09:06.88', 'CN-Main', 'ヤマトは これよりヘリオポーズを通過', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '大和号即将穿越日球层顶。' });
add(7, '0:09:07.30', '0:09:09.66', 'CN-Main', '衝撃で艦体が揺れることも予想されます', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '冲击可能导致舰体摇晃，' });
add(7, '0:09:10.38', '0:09:13.57', 'CN-Main', '赤道祭参加の乗組員は注意してください', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '参加祭典的船员请注意安全。' });
add(7, '0:09:43.33', '0:09:46.41', 'CN-Main', 'いざとなったら 何を話していいのか', { newText: '真到那时，我该说些什么呢？' });
add(7, '0:09:46.41', '0:09:48.33', 'CN-Main', '大丈夫 元気な顔を見せれば…', { newText: '没关系，让他们看看你精神的样子就好……' });
add(7, '0:13:50.16', '0:13:52.20', 'CN-Main', '南部君 終わったみたいだな', { newText: '看来南部也结束了。' });
add(7, '0:14:45.58', '0:14:48.85', 'CN-Main', '地球との交信は ヘリオポーズを出るとできなくなります', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '驶出日球层顶后，将无法再与地球通信。' });
add(7, '0:14:53.06', '0:14:54.61', 'CN-Main', '速やかに手続きを済ませてください', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '请尽快办完手续。' });
add(7, '0:16:56.89', '0:16:57.84', 'CN-Main', '嫌だ〜！ させるか！');
add(7, '0:17:09.19', '0:17:10.72', 'CN-Main', 'そっちも飲みなさいよ', { newText: '你也给我喝！' });
add(7, '0:17:10.72', '0:17:12.73', 'CN-Main', 'お前にメイド服を要求して…', { newText: '还不是你让我穿女仆装的……' });
add(7, '0:17:21.36', '0:17:23.94', 'CN-Main', '地球との交信は まもなく終了となります', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '与地球的通信即将结束。' });
add(7, '0:17:24.76', '0:17:27.21', 'CN-Main', '交信希望者は 直ちに通信室へお越しください', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '申请通信者请立即前往通信室。' });
add(7, '0:17:29.01', '0:17:32.85', 'CN-Main', '繰り返します 地球との交信は まもなく終了となります', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '重复一遍：与地球的通信即将结束。' });

for (const row of [
  ['0:05:10.85','0:05:12.35','これは猫なのだ'], ['0:07:23.90','0:07:24.94','まさかな'],
  ['0:07:28.86','0:07:30.82','お前は何者か'], ['0:07:31.61','0:07:33.32','私は…'],
  ['0:15:29.76','0:15:30.63','敵'], ['0:16:14.55','0:16:17.18','我々が敵だと思われたくない'],
  ['0:19:43.93','0:19:44.49','犬'], ['0:19:45.56','0:19:46.06','猫'], ['0:19:50.48','0:19:51.04','死'],
]) add(9, row[0], row[1], 'CN-Main', row[2]);

add(10, '0:01:32.58', '0:01:35.63', 'CN-Main', undefined, { newStyle: 'Title', newText: '巴伦星' });
add(10, '0:04:56.27', '0:05:00.14', 'CN-Top', '現段階で この不確定現象を特定することは 困難な状況にある', { newText: '现阶段仍难以判定这种不确定现象。' });
add(11, '0:10:48.83', '0:10:49.35', 'CN-Main', 'え？');
add(12, '0:22:10.53', '0:22:11.20', 'CN-Main', 'なんだ？', { newText: '怎么了？' });
add(13, '0:04:48.70', '0:04:49.47', 'CN-Main', '駄目だ');
add(13, '0:11:56.80', '0:11:57.43', 'CN-Main', '駄目だ！');
add(13, '0:13:13.44', '0:13:15.79', 'CN-Top', 'AU09 起動準備よくて？', { newText: 'AU09，启动准备好了吗？' });
add(14, '0:09:23.34', '0:09:23.93', 'CN-Main', undefined, { newStyle: 'CN-Alien' });
add(14, '0:12:49.79', '0:12:51.13', 'CN-Main', 'はじめまして', { newText: '初次见面，请多关照。' });
add(14, '0:14:45.59', '0:14:46.03', 'CN-Main', '進');
add(15, '0:05:01.51', '0:05:02.34', 'CN-Main', '痛っ');
add(15, '0:11:36.04', '0:11:37.79', 'CN-Main', undefined, { newStyle: 'Title' });
add(15, '0:21:00.46', '0:21:01.55', 'CN-Main', '撃て〜っ！');
add(16, '0:09:14.68', '0:09:18.72', 'CN-Top', '繰り返します 本日付けをもって 本艦の指揮権は', { newText: '重复一遍：自今日起，本舰指挥权' });
add(17, '0:05:39.30', '0:05:40.15', 'CN-Main', '早く行け');
add(17, '0:05:40.35', '0:05:40.98', 'CN-Main', 'グズグズするな');
add(17, '0:09:38.41', '0:09:38.87', 'CN-Main', '何？');
add(17, '0:17:44.74', '0:17:48.70', 'CN-Main', undefined, { newStyle: 'Title', newText: '10个月前　富士宇宙港地下船坞' });
add(18, '0:11:20.88', '0:11:21.92', 'CN-Main', 'すげえ…', { newText: '真壮观……' });
add(18, '0:13:59.13', '0:13:59.75', 'CN-Main', '何？');
add(18, '0:16:53.76', '0:16:55.76', 'CN-Main', 'メル106 ナル68');
add(19, '0:13:35.06', '0:13:35.58', 'CN-Main', 'やめろ！');
add(19, '0:13:39.27', '0:13:40.06', 'CN-Main', '親衛隊め！');
add(19, '0:19:19.57', '0:19:21.79', 'CN-Main', '作戦宙域まで あと70ゲック', { newText: '距离作战区域还有70格克。' });

add(20, '0:01:41.18', '0:01:42.78', 'CN-Main', '有視界でやるなんて', { newText: '居然全靠目视作战，' });
add(20, '0:01:42.90', '0:01:44.49', 'CN-Main', '大昔の空中戦かよ', { newText: '简直像远古时代的空战。' });
add(20, '0:01:49.98', '0:01:50.82', 'CN-Main', '隊長！');
add(20, '0:01:51.63', '0:01:54.39', 'CN-Main', 'お客さんを出迎える 命落とすな', { newText: '该去迎接客人了，别送了命。' });
add(20, '0:01:54.55', '0:01:55.29', 'CN-Main', '敵を落とせ！');
add(20, '0:01:55.41', '0:01:56.09', 'CN-Main', 'ラジャー！');
add(20, '0:07:17.26', '0:07:19.38', 'CN-Top', '第4デッキの気密隔壁 閉鎖', { newText: '第四甲板气密隔壁关闭。' });
add(20, '0:07:19.54', '0:07:20.81', 'CN-Top', '第4デッキに火災発生', { newText: '第四甲板发生火灾。' });
add(20, '0:07:25.19', '0:07:27.54', 'CN-Top', '第4デッキ 気密隔壁 閉鎖した', { newText: '第四甲板气密隔壁已关闭。' });
add(20, '0:09:45.33', '0:09:47.56', 'CN-Main', '敵弾頭 薬室に向け前進していきます', { newText: '敌方弹头正向药室推进！' });
add(20, '0:09:53.92', '0:09:54.43', 'CN-Main', '急げ！');
add(20, '0:09:54.43', '0:09:56.22', 'CN-Main', '退避！ 退避！', { newText: '撤离！快撤离！' });
add(20, '0:10:52.41', '0:10:53.04', 'CN-Top', '繰り返す');
add(20, '0:18:30.65', '0:18:31.77', 'CN-Main', '行ってください', { newText: '你先走吧。' });
add(20, '0:19:48.47', '0:19:49.10', 'CN-Main', 'くそっ');
add(21, '0:21:10.60', '0:21:11.54', 'CN-Main', '雪！');

add(22, '0:05:11.13', '0:05:12.97', 'CN-Main', '第二兵装 搭載作業に入れ', { newStyle: 'CN-Top', jpStyle: 'JP-Top', newText: '开始装载第二武装。' });
for (const [start, end] of [
  ['0:14:12.20','0:14:13.91'], ['0:14:14.33','0:14:16.08'], ['0:14:16.66','0:14:18.45'],
  ['0:14:19.16','0:14:21.12'], ['0:14:22.04','0:14:24.00'], ['0:14:25.00','0:14:26.96'],
  ['0:21:53.04','0:21:53.67'], ['0:21:54.09','0:21:54.75'], ['0:21:55.09','0:21:55.68'],
  ['0:21:56.04','0:21:56.64'], ['0:21:57.12','0:21:57.64'], ['0:21:58.05','0:21:58.64'],
  ['0:21:59.11','0:21:59.61'], ['0:22:00.08','0:22:00.64'], ['0:22:01.16','0:22:01.66'],
  ['0:22:02.13','0:22:02.58'], ['0:22:03.07','0:22:03.65'],
]) add(22, start, end, 'CN-Main', undefined, { newStyle: 'CN-Alien' });
add(22, '0:17:51.10', '0:17:51.63', 'CN-Main', 'ホント？', { newText: '真的吗？' });

for (const [start, end] of [['0:09:36.69','0:09:39.13'], ['0:09:39.66','0:09:42.07'], ['0:09:42.69','0:09:45.27']]) {
  add(23, start, end, 'CN-Main', undefined, { newStyle: 'CN-Alien' });
}
add(23, '0:16:44.13', '0:16:44.75', 'CN-Main', '急げ！');
add(23, '0:18:35.11', '0:18:38.95', 'CN-Top', 'デスラー砲へのエネルギー充填を開始しました', { newText: '开始为迪斯拉炮填充能量。' });
add(24, '0:07:47.70', '0:07:48.32', 'CN-Main', '多分', { newText: '大概吧。' });

// E25/E26 use BD-only recap dialogue absent from the official Web stream.  These
// lines are taken from the archived Kamigami BD track and checked against English.
add(25, '0:01:40.87', '0:01:43.69', 'CN-Main', '私たちがイスカンダルを後にしたのは', { newText: '我们离开伊斯坎达尔，' });
add(25, '0:01:44.28', '0:01:45.88', 'CN-Main', 'もう二か月前', { newText: '已经两个月了。' });
add(25, '0:01:47.16', '0:01:48.98', 'CN-Main', 'ヤマトが地球を旅立ってから', { newText: '大和号从地球启航，' });
add(25, '0:01:49.65', '0:01:51.13', 'CN-Main', '八か月が経ちました', { newText: '至今已过去八个月。' });
add(25, '0:01:54.30', '0:01:55.24', 'CN-Main', '旅の途中', { newText: '旅途中，' });
add(25, '0:01:55.76', '0:01:57.43', 'CN-Main', '大切な仲間を失い', { newText: '我们曾失去重要的伙伴，' });
add(25, '0:01:58.16', '0:02:00.55', 'CN-Main', '悲しみに暮れることもありました', { newText: '也曾沉浸在悲伤中。' });
add(25, '0:02:02.10', '0:02:06.41', 'CN-Main', 'でも 私たちは希望を見失ったりはしなかった', { newText: '但我们从未失去希望。' });
add(25, '0:02:07.66', '0:02:13.31', 'CN-Main', 'それは「ヤマト」を信じて待っている地球の人たちがいたからです', { newText: '因为地球上有人相信大和号，始终等候着我们。' });
add(25, '0:02:28.68', '0:02:30.27', 'CN-Main', '前にここを通った時', { newText: '上次经过这里时，' });
add(25, '0:02:31.21', '0:02:34.41', 'CN-Main', '私たちは まだ不安でいっぱいだったけれど', { newText: '我们还满心不安，' });
add(25, '0:02:35.70', '0:02:38.33', 'CN-Main', 'でも 今は違います', { newText: '但现在不一样了。' });
add(25, '0:02:39.43', '0:02:42.30', 'CN-Main', '「ヤマト」は今 希望を乗せて', { newText: '如今，大和号满载希望，' });
add(25, '0:02:42.97', '0:02:44.51', 'CN-Main', '地球へ向かっているんです', { newText: '正驶向地球。' });
add(25, '0:07:17.70', '0:07:18.29', 'CN-Main', 'ウソよ！');

add(26, '0:01:37.35', '0:01:40.55', 'CN-Top', '先の戦闘における艦の損害 軽微', { newText: '刚才的战斗中，舰体受损轻微。' });
add(26, '0:01:40.95', '0:01:42.37', 'CN-Main', '航行に支障はありません', { newText: '不影响继续航行。' });
add(26, '0:01:43.20', '0:01:46.33', 'CN-Main', '戦死17名 負傷34名', { newText: '战死17人，负伤34人。' });
add(26, '0:01:46.49', '0:01:46.94', 'CN-Main', 'くそっ');
add(26, '0:01:49.53', '0:01:53.06', 'CN-Main', '森船務長も撃たれて 意識不明の重体です', { newText: '森船务长也中枪，昏迷不醒，伤势危重。' });
add(26, '0:01:54.26', '0:01:56.78', 'CN-Main', '助かる見込みはないのかね', { newText: '她就没有获救的希望了吗？' });
add(26, '0:01:57.28', '0:02:01.62', 'CN-Main', '残念ですが 奇跡でも起こらんかぎり', { newText: '很遗憾，除非发生奇迹……' });
add(26, '0:02:03.31', '0:02:06.10', 'CN-Main', '奇跡は起こるものではありません', { newText: '奇迹不是等来的。' });
add(26, '0:02:07.43', '0:02:09.69', 'CN-Main', '奇跡は起こすものです', { newText: '奇迹要靠人去创造。' });
add(26, '0:22:12.27', '0:22:13.26', 'CN-Main', '守…', { newText: '守……' });

// Translation repairs caused by material differences between the official Japanese
// script and the old Kamigami transcription.  English and scene context were used as
// cross-checks; ordinary wording changes unrelated to a source mismatch are excluded.
add(1, '0:01:59.49', '0:02:02.50', 'CN-Main', 'ユウギリ 轟沈！ クラマ 戦列を離れる！');
add(1, '0:01:01.47', '0:01:02.82', 'CN-Main', '面舵！');
add(1, '0:02:57.82', '0:03:00.42', 'CN-Main', '右舷 第３デッキ 被弾！ 機関 推力低下！', { newText: '右舷第三甲板中弹！引擎推力下降！' });
add(1, '0:07:35.20', '0:07:37.99', 'CN-Main', 'これより撤退する われに続け', { newText: '现在开始撤退，跟上我们。' });
add(1, '0:09:33.07', '0:09:36.15', 'CN-Main', '山南君 針路そのままだ', { newText: '山南君，保持航向。' });
add(1, '0:18:52.84', '0:18:55.74', 'CN-Main', '彼女の言葉に ウソはありませんでした', { newText: '她没有说谎。' });
add(1, '0:20:18.59', '0:20:20.05', 'CN-Main', 'そいつから降りろ！', { newText: '从那上面下来！' });
add(1, '0:11:02.62', '0:11:04.25', 'CN-Main', 'キリシマ アマテラスを回収');
add(1, '0:11:04.83', '0:11:06.28', 'CN-Main', '地球への帰投コースにつきました', { newText: '已设定返航地球的航线。' });

add(2, '0:04:35.10', '0:04:35.66', 'CN-Main', '聞けば', { newText: '听说，' });
add(2, '0:04:36.07', '0:04:39.86', 'CN-Main', '先の空爆で 主要メンバーの大半が戦死したとか', { newText: '刚才的空袭中，主要成员大多战死了？' });
add(2, '0:04:39.86', '0:04:42.63', 'CN-Main', 'その件について 支障は出ておりません', { newText: '此事并未造成影响。' });
add(2, '0:10:01.14', '0:10:03.35', 'CN-Main', '行って 必ず帰ってくる', { newText: '我会去，也一定会活着回来。' });
add(2, '0:15:39.22', '0:15:41.84', 'CN-Main', 'お前の席に座るはずだった男も', { newText: '本该坐在你这个位置上的人，' });
add(2, '0:15:42.51', '0:15:44.10', 'CN-Main', 'わしは死なせてしまった', { newText: '也被我害死了。' });

add(3, '0:07:31.70', '0:07:34.16', 'CN-Main', '船は出てゆく 煙は残る', { newText: '船已远去，烟雾犹存，' });
add(3, '0:07:34.16', '0:07:37.16', 'CN-Main', '残る煙が しゃくの種', { newText: '残烟缭绕，真叫人窝火。' });
add(3, '0:07:38.61', '0:07:39.70', 'CN-Main', 'がっ！ ぐらっときたよ〜', { newText: '晃……晃起来了！' });
add(3, '0:07:46.86', '0:07:50.85', 'CN-Main', '…舎利子 色不異空 空不異色…', {
  newStyle: 'CN-Top', jpStyle: 'JP-Top', jpFromStyle: 'JP-Main', newText: '……舍利子，色不异空，空不异色……',
});
add(3, '0:09:39.49', '0:09:42.08', 'CN-Main', 'ダメだ！ どんどん引き寄せられていく', { newText: '不行，正不断被吸过去！' });
add(3, '0:14:10.05', '0:14:13.18', 'CN-Main', '大気成分 メタン67パーセント', { newText: '大气成分：甲烷67%，' });
add(3, '0:14:13.18', '0:14:17.31', 'CN-Main', '窒素６パーセント 二酸化炭素21パーセント', { newText: '氮气6%，二氧化碳21%。' });
add(3, '0:14:38.00', '0:14:42.77', 'CN-Main', '地球ニ繁殖シテイル 未知ノ異星植物トノ ＤＮＡ適合率', { newText: '与地球繁殖的未知外星植物DNA适配率' });
add(3, '0:14:42.88', '0:14:45.22', 'CN-Main', '99,98パーセントデス', { newText: '达到99.98%。' });

add(4, '0:09:39.70', '0:09:40.85', 'CN-Main', '両舷前進微速', { newText: '双舷前进微速。' });
add(4, '0:09:41.28', '0:09:42.03', 'CN-Main', '赤15', { newText: '红15。' });
add(4, '0:10:42.22', '0:10:44.17', 'CN-Main', '作業を急がせてくれ 掌帆長', { newText: '快点作业，水手长。' });
add(4, '0:11:34.44', '0:11:37.38', 'CN-Main', '不審ナ行動ハ 確認サレマセン', { newText: '未发现可疑行为。' });
add(4, '0:12:53.56', '0:12:55.51', 'CN-Main', 'このシルエットから見て 恐らく…', { newText: '从这个轮廓来看，恐怕……' });
add(4, '0:12:56.56', '0:12:59.23', 'CN-Main', '磯風型突撃宇宙駆逐艦', { newText: '矶风型突击宇宙驱逐舰' });
add(4, '0:14:41.13', '0:14:44.54', 'CN-Main', 'この… ううっ！', { newText: '给我打开！' });
add(4, '0:15:03.06', '0:15:04.56', 'CN-Main', '右舷に被弾 損害軽微！', { newText: '右舷中弹，损伤轻微！' });
add(4, '0:07:03.08', '0:07:03.85', 'CN-Main', 'かまわないよ', { newText: '没关系，坐吧。' });
add(4, '0:10:25.41', '0:10:27.59', 'CN-Main', '護衛任務ノコトト 思ワレマス', { newText: '应该是指护卫任务。' });

add(5, '0:10:35.76', '0:10:37.26', 'CN-Main', '主計科の山本です', { newText: '我是主计科的山本。' });
add(5, '0:10:37.81', '0:10:39.13', 'CN-Main', 'お手間は取らせません', { newText: '不会耽误您太久。' });
add(5, '0:10:45.67', '0:10:48.77', 'CN-Main', 'ガサツな男だよ あの加藤ってヤツは', { newText: '那个加藤就是个粗鲁的家伙。' });
add(5, '0:12:50.22', '0:12:52.22', 'CN-Main', '玲… お前！', { newText: '玲……你！' });
add(5, '0:12:52.22', '0:12:53.18', 'CN-Main', 'アキラ？', { newText: '玲？' });
add(5, '0:12:59.15', '0:13:01.88', 'CN-Main', 'これで“アキラ”と読むんです', { newText: '这个“玲”字念作Akira。' });
add(5, '0:13:02.36', '0:13:05.03', 'CN-Main', 'そうか 俺は てっきり…', { newText: '这样啊，我还以为念Rei呢……' });
add(5, '0:13:05.03', '0:13:05.91', 'CN-Main', 'レイで かまいません', { newText: '叫我Rei也可以。' });

add(6, '0:05:50.55', '0:05:52.55', 'CN-Main', 'バラコン ベント弁操作 どうなってる！', { newText: '平衡控制，排气阀怎么样了？' });
add(6, '0:05:55.73', '0:05:57.39', 'CN-Main', '宇宙船で溺れ死んだりしてみろ', { newText: '要是在宇宙飞船里淹死，' });
add(6, '0:05:57.75', '0:05:59.19', 'CN-Main', 'シャレにならんぞ！', { newText: '那可就太荒唐了！' });

add(7, '0:07:29.74', '0:07:31.72', 'CN-Main', 'あけみちゃ〜ん！', { newText: '明美——！' });
add(7, '0:07:31.72', '0:07:33.22', 'CN-Main', '私語がダダ漏れだぞ！', { newText: '你的心里话全漏出来了！' });
add(7, '0:07:36.20', '0:07:39.08', 'CN-Main', 'す… すんません！', { newText: '对……对不起！' });
add(7, '0:07:45.33', '0:07:47.00', 'CN-Main', 'じゃない！ 用でありますか？', { newText: '不对！请问有何吩咐？' });

add(8, '0:07:48.65', '0:07:50.24', 'CN-Top', 'きっと無事に帰ってきてね');
add(8, '0:08:29.92', '0:08:31.01', 'CN-Main', 'あっ…', { newText: '啊……是。' });
add(8, '0:08:31.01', '0:08:35.13', 'CN-Main', 'デスラー魚雷は 既に 前線配備を 完了いたしております！');
add(8, '0:09:14.76', '0:09:15.56', 'CN-Main', 'かまわんよ', { newText: '可以。' });
add(8, '0:09:16.80', '0:09:17.84', 'CN-Main', 'なんだね？', { newText: '什么事？' });
add(8, '0:12:17.84', '0:12:18.49', 'CN-Top', '魚雷戦 迎撃準備よし', { newText: '鱼雷战，拦截准备完毕。' });
add(8, '0:12:18.57', '0:12:20.21', 'CN-Main', '迎撃不可能域まで あと', { newText: '距进入无法拦截区域还有——' });
add(8, '0:12:20.83', '0:12:23.87', 'CN-Top', '10 ９ ８ ７');
add(8, '0:12:24.54', '0:12:29.37', 'CN-Top', '６ ５ ４ ３ ２ １');
add(8, '0:14:14.85', '0:14:15.89', 'CN-Main', 'なんとかいけます', { newText: '应该能行。' });
add(8, '0:15:05.28', '0:15:07.67', 'CN-Main', '最大戦速 よ〜そろ〜！', { newText: '最大战速，保持航向！' });
add(8, '0:21:54.98', '0:21:56.49', 'CN-Main', '夢追う人がするように', { newText: '像追梦的人那样，' });
add(8, '0:21:57.12', '0:21:59.26', 'CN-Main', '星に思いを託しましょう', { newText: '把心愿寄托给群星吧。' });
add(8, '0:22:00.82', '0:22:02.96', 'CN-Main', 'あなたが心を込めて願えば', { newText: '只要你诚心许愿，' });
add(8, '0:22:03.48', '0:22:06.02', 'CN-Main', '夢は必ず かなうはずです', { newText: '梦想一定会实现。' });

add(9, '0:04:08.95', '0:04:11.28', 'CN-Main', '私ハ タイプＡＵ-０９ コノ艦ノ サブフレーム', { newText: '我是AU09型，也是本舰的辅助运算单元。' });
add(9, '0:04:11.80', '0:04:16.29', 'CN-Main', '“アナライザー”ト呼ンデホシイ', { newText: '请叫我“分析士”。' });
add(9, '0:07:26.02', '0:07:28.21', 'CN-Main', 'アナタハ 答エラレマスカ？');
add(9, '0:07:28.86', '0:07:30.82', 'CN-Main', 'オ前ハ 何者カ');
add(9, '0:14:29.28', '0:14:32.95', 'CN-Main', '女神ニ会エバ ソノ答エガ分カルト 思ッテイルノデショウ');
add(9, '0:14:33.45', '0:14:34.58', 'CN-Main', '女神だって？');
add(9, '0:14:35.45', '0:14:38.99', 'CN-Main', 'オルタハ コノ艦ノ女神ダト 言ッテイマシタ', { newText: '奥尔塔说她是这艘舰的女神。' });
add(9, '0:14:39.75', '0:14:45.59', 'CN-Main', 'ソレト モウヒトツ ガミロイド兵ニツイテ 重要ナコトガ分カリマシタ');
add(9, '0:11:22.39', '0:11:24.91', 'CN-Main', '適切ナ判断ダト 思ワレマス', { newText: '我认为这是正确的判断。' });
add(9, '0:17:27.75', '0:17:29.31', 'CN-Main', 'ドアガ 開キマス', { newText: '门要开了。' });
add(9, '0:20:53.92', '0:20:55.12', 'CN-Main', 'ソレデハ…', { newText: '那么……' });
add(9, '0:16:58.35', '0:17:01.84', 'CN-Main', '彼らの処理系に 我々と同種の意識は芽生えない', { newText: '它们的处理系统中不会萌生与我们相同的意识——' });
add(9, '0:17:02.33', '0:17:04.08', 'CN-Main', 'そう 君は思いたいようだ', { newText: '你似乎愿意这样相信。' });
add(9, '0:24:16.62', '0:24:18.91', 'CN-Main', '生くる者とてない無常の空間', { newText: '在这无一生灵的无常空间里，' });

add(10, '0:04:52.24', '0:04:53.35', 'CN-Main', '副長より達する', {
  newStyle: 'CN-Top', jpStyle: 'JP-Top', jpFromStyle: 'JP-Main', newText: '副舰长通知全舰。',
});
add(10, '0:04:53.83', '0:04:56.01', 'CN-Top', '本艦は現在ワープ中であるが', { newText: '本舰当前仍处于跃迁中，' });
add(10, '0:20:05.74', '0:20:06.77', 'CN-Main', 'ゲール少将！', { newText: '盖尔少将！' });
add(10, '0:20:07.07', '0:20:10.91', 'CN-Main', 'あの艦には ディッツ提督のご令嬢が 乗っておられるのです！');

add(11, '0:21:42.01', '0:21:44.80', 'CN-Top', '誘導員は ガミラス機の発艦準備に備えよ', { newText: '引导员做好加米拉斯战机起飞准备。' });
add(11, '0:21:44.80', '0:21:48.59', 'CN-Top', '誘導員は ガミラス機の発艦準備に備えよ', { newText: '重复一遍：引导员做好加米拉斯战机起飞准备。' });

add(12, '0:03:16.11', '0:03:18.44', 'CN-Main', 'フフ… かなわんな 先生には', { newText: '真是什么都瞒不过医生啊。' });
add(12, '0:14:58.10', '0:15:00.81', 'CN-Main', 'ええ〜！ 林さんまで？', { newText: '诶，连林先生也？' });

// E13/E14 have a different BD/Web timing offset, so their official sentences are
// split explicitly rather than inferred from the old track.  Only official text is
// written; the old track supplies boundary hints.
add(13, '0:04:33.89', '0:04:37.00', 'CN-Main', 'この原始恒星系の星間物質に紛れ', { newText: '只要我们混入这个原恒星系的星际物质中，' });
add(13, '0:04:37.22', '0:04:38.98', 'CN-Main', '息を潜めているかぎり', { newText: '隐匿踪迹，' });
add(13, '0:05:19.58', '0:05:21.32', 'CN-Main', '深度22から30');
add(13, '0:05:21.32', '0:05:22.36', 'CN-Main', '次元圧 正常');
add(13, '0:11:24.72', '0:11:27.40', 'CN-Main', 'はい あれも原理は同じですから');
add(13, '0:11:27.85', '0:11:30.48', 'CN-Main', '異次元の敵艦を索敵できるはずです');
add(13, '0:13:29.43', '0:13:30.39', 'CN-Main', 'そうだ');
add(13, '0:13:30.64', '0:13:32.08', 'CN-Main', '搭載したら すぐに出る');
add(13, '0:16:17.10', '0:16:18.03', 'CN-Main', 'シーガル 応答せよ！');
add(13, '0:16:18.12', '0:16:19.50', 'CN-Main', '乗っているのは誰か？ シーガル！');
add(13, '0:17:20.87', '0:17:21.49', 'CN-Main', 'こちらシーガル');
add(13, '0:17:21.94', '0:17:23.08', 'CN-Main', 'シーガルより ヤマト！');
add(13, '0:18:04.45', '0:18:05.53', 'CN-Main', 'ヤマト 聞こえるか？');
add(13, '0:18:06.18', '0:18:06.92', 'CN-Main', 'こちらシーガル');
add(13, '0:18:14.67', '0:18:15.27', 'CN-Main', '了解');
add(13, '0:18:15.67', '0:18:17.09', 'CN-Main', '対空戦闘用意！');
add(13, '0:25:02.54', '0:25:04.80', 'CN-Main', '虚空に雪は降りしきり', { newText: '白雪纷纷飘落虚空，' });
add(13, '0:25:05.23', '0:25:07.54', 'CN-Main', '魔性の影が闊歩する', { newText: '魔性之影昂然阔步。' });

add(14, '0:02:44.51', '0:02:46.22', 'CN-Main', '俺たちゃ便利屋じゃねえ');
add(14, '0:02:46.30', '0:02:48.00', 'CN-Main', '戦争屋だっつうの！');
add(14, '0:05:06.97', '0:05:07.90', 'CN-Main', 'どうした？ 相原');
add(14, '0:05:08.22', '0:05:09.51', 'CN-Main', 'ヤマト 応答せよ！');
add(14, '0:07:35.37', '0:07:37.65', 'CN-Main', 'でも 艦が動いているということは');
add(14, '0:07:38.02', '0:07:39.99', 'CN-Main', '航法管制システムは無事な証拠', { newText: '就说明导航控制系统正常。' });
add(14, '0:09:05.21', '0:09:07.26', 'CN-Main', '中央電算室と自動航法室', { newText: '中央计算机室和自动导航室？' });
add(14, '0:09:07.79', '0:09:08.74', 'CN-Main', '二手に分かれる？');
add(14, '0:09:22.44', '0:09:23.11', 'CN-Main', 'ガル');
add(14, '0:09:24.27', '0:09:24.84', 'CN-Main', 'ネル');
add(14, '0:09:25.19', '0:09:25.74', 'CN-Main', 'ベオ');
add(14, '0:09:26.27', '0:09:26.70', 'CN-Main', 'アル…');
add(14, '0:10:33.55', '0:10:35.05', 'CN-Main', '父さん 母さん…');
add(14, '0:10:36.03', '0:10:37.31', 'CN-Main', 'それに 叔父さんたちまで');
add(14, '0:13:19.17', '0:13:20.79', 'CN-Main', '頭を強く打ったから');
add(14, '0:13:21.17', '0:13:23.06', 'CN-Main', '多分 記憶障害を起こしているのよ');
add(14, '0:18:37.24', '0:18:39.13', 'CN-Main', '宇宙港へ兄さんを迎えに行って');
add(14, '0:18:39.71', '0:18:40.78', 'CN-Main', 'そうしたら…');
add(14, '0:21:00.38', '0:21:01.55', 'CN-Main', '魔女のすることだ', { newText: '这是魔女所为。' });
add(14, '0:21:01.96', '0:21:03.58', 'CN-Main', '凡人には分かるまいな', { newText: '凡人恐怕无法理解。' });

add(16, '0:14:06.97', '0:14:09.39', 'CN-Main', '生命反応ハ 認メラレマセン', { newText: '未发现生命反应。' });
add(16, '0:14:09.85', '0:14:14.56', 'CN-Main', '着陸カラ オヨソ400年ガ 経過シテイルト推定サレマス', { newText: '推测距其着陆已过去约400年。' });
add(16, '0:15:15.24', '0:15:15.76', 'CN-Main', '岬君', { newText: '岬？' });
add(16, '0:15:16.54', '0:15:17.17', 'CN-Main', '大丈夫か？', { newText: '你没事吧？' });

add(17, '0:19:35.59', '0:19:37.36', 'CN-Main', '“汚れちまった悲しみは', { newText: '沾染尘垢的悲伤，' });
add(17, '0:19:37.93', '0:19:40.03', 'CN-Main', 'なに のぞむなく ねがいなく”', { newText: '已无所求，亦无所愿；' });
add(17, '0:19:40.61', '0:19:42.32', 'CN-Main', '“汚れちまった悲しみに', { newText: '沾染尘垢的悲伤，' });
add(17, '0:19:42.78', '0:19:45.41', 'CN-Main', 'なすところもなく 日は暮れる”', { newText: '无所作为，日暮西沉。' });

add(18, '0:15:21.71', '0:15:22.61', 'CN-Main', '友軍が邪魔で テロン艦が狙えません！', { newText: '友军挡住了射线，无法瞄准地球舰！' });
add(18, '0:13:48.99', '0:13:51.67', 'CN-Main', 'バレラスへ侵攻し', { newText: '进攻巴列拉斯！' });
add(18, '0:13:52.08', '0:13:54.46', 'CN-Main', '総統府に巣くう奸賊どもを 殲滅するのだ！', { newText: '歼灭盘踞总统府的奸贼！' });
add(19, '0:07:59.98', '0:08:03.12', 'CN-Main', '兵は戦場で 一人前になると', { newText: '士兵只有到了战场上才能独当一面。' });
add(19, '0:08:03.21', '0:08:04.65', 'CN-Main', '言われたのは閣下でしたな', { newText: '这不是阁下说的吗？' });
add(15, '0:20:18.25', '0:20:21.17', 'CN-Main', '機関室 どうした？ 推力 上げ！', { newText: '轮机舱，怎么回事？提高推力！' });
add(20, '0:22:46.40', '0:22:51.46', 'CN-Main', '沖田艦長 あなたの見事な采配に 心から敬意を表する', { newText: '冲田舰长，我由衷敬佩您出色的指挥。' });
add(20, '0:11:44.70', '0:11:45.80', 'CN-Main', '意外デスネ', { newText: '真是出乎意料。' });
add(20, '0:11:46.02', '0:11:48.54', 'CN-Main', '簡単ニ 中ヘ入レルナンテ', { newText: '竟然这么轻易就进来了。' });
add(23, '0:17:55.91', '0:17:57.41', 'CN-Top', '発射態勢に入った？', { newText: '进入发射状态了吗？' });
add(23, '0:25:42.12', '0:25:44.35', 'CN-Main', 'だが そこに人影はなく', { newText: '但那里空无一人，' });
add(23, '0:25:44.71', '0:25:47.26', 'CN-Main', '佇むは孤高の女王 ただ一人', { newText: '只有孤高的女王独自伫立。' });
add(25, '0:15:11.99', '0:15:15.12', 'CN-Main', '副長 侵入シテキタ敵兵ニハ', { newText: '副舰长，入侵的敌兵' });
add(25, '0:15:15.24', '0:15:17.99', 'CN-Main', '生体反応ガ 認メラレマセン', { newText: '未检测到生命反应。' });
add(26, '0:05:03.67', '0:05:08.72', 'CN-Main', '昏睡状態だったユリーシャの 生命機能を維持した', { newText: '曾维持昏睡中尤丽莎生命机能的' });
add(26, '0:05:09.24', '0:05:10.15', 'CN-Main', 'あのカプセルなら可能だ', { newText: '那座维生舱就能做到。' });
add(26, '0:14:25.30', '0:14:28.49', 'CN-Main', 'お前は これまで立派にやってきた', { newText: '但是，一直以来你都出色地完成了任务。' });

// Translation and segmentation corrections found by comparing the official
// Japanese directly against the current Chinese, with English used only for
// disambiguation. Japanese is split onto the exact Chinese axes.
add(2, '0:18:31.63', '0:18:32.13', 'CN-Main', 'いけます！', { newText: '可以启动了！' });

add(3, '0:11:28.43', '0:11:29.72', 'CN-Main', '錨 打ち込め！', { newText: '打入船锚！' });
add(3, '0:11:29.85', '0:11:30.52', 'CN-Main', 'てえっ！', { newText: '发射！' });
add(3, '0:14:38.00', '0:14:42.77', 'CN-Main', '地球ニ繁殖シテイル 未知ノ異星植物トノ ＤＮＡ適合率', { newText: '与繁殖在地球上的未知外星植物的DNA适配率' });

add(4, '0:15:04.57', '0:15:07.28', 'CN-Main', '機関停止中のため 主砲 副砲とも使用不能！', { newText: '引擎停转，主炮、副炮均无法使用！' });
add(4, '0:04:16.21', '0:04:18.56', 'CN-Main', 'それは さっき お前が言ってたことじゃないか！', { newText: '这不就是你刚才说的吗！' });

add(5, '0:04:12.08', '0:04:14.12', 'CN-Main', 'いやあ 潤うねえ', { newText: '哎呀，真养眼啊。' });
add(5, '0:10:56.36', '0:10:59.10', 'CN-Top', '第５分隊は 直ちに 第１格納庫に集合', { newText: '第五分队立即到第一机库集合。' });
add(5, '0:10:59.10', '0:11:02.86', 'CN-Top', '繰り返す 第５分隊は 直ちに第１格納庫に集合', { newText: '重复一遍：第五分队立即到第一机库集合。' });
add(5, '0:13:59.94', '0:14:03.25', 'CN-Top', '繰り返す カタパルト要員は 発艦準備に備えよ', { newText: '重复一遍：弹射器人员做好起飞准备。' });
add(5, '0:15:09.43', '0:15:10.82', 'CN-Main', 'ハヤブサを降ろせ！', { newText: '放下隼式战机！' });

add(7, '0:02:30.56', '0:02:32.88', 'CN-Main', 'ヘリオポーズの影響のようです', { newText: '看来是日球层顶的影响。' });
add(7, '0:03:04.05', '0:03:04.63', 'CN-Main', 'そういえば', { newText: '说起来，' });
add(7, '0:03:04.63', '0:03:07.20', 'CN-Main', '乗員のカウンセリングも 始めたそうじゃないですか', { newText: '听说你也开始为船员做心理辅导了？' });
add(7, '0:08:50.86', '0:08:54.40', 'CN-Main', 'いや… 忙しそうだな すまなかった', { newText: '不……看来你在忙，打扰了。' });
add(7, '0:12:56.27', '0:13:00.23', 'CN-Main', 'たった１人残った兄も ガミラスとの戦闘で亡くなりました', { newText: '唯一在世的哥哥，也在与加米拉斯的战斗中牺牲了。' });

add(8, '0:04:25.14', '0:04:28.03', 'CN-Main', '彼なら 期待に応えてくれることだろう', { newText: '他应该不会辜负我们的期待。' });
add(8, '0:17:11.07', '0:17:14.32', 'CN-Main', 'わしは あんたの親友から くれぐれもと頼まれとる', { newText: '你那位挚友可是千叮万嘱，让我照顾好你。' });

add(9, '0:02:35.73', '0:02:36.66', 'CN-Main', 'ウマクイッタ', { newText: '成功了。' });
add(9, '0:18:02.96', '0:18:04.00', 'CN-Main', '追え！ ヤツを食い止めろ！', { newText: '追！阻止它！' });

add(10, '0:09:13.26', '0:09:17.09', 'CN-Main', '与圧上昇 格納庫内 酸素分圧 まもなく正常値', {
  newStyle: 'CN-Top', jpStyle: 'JP-Top', jpFromStyle: 'JP-Main', newText: '增压正常，机库内氧分压即将恢复正常。',
});
add(10, '0:19:43.32', '0:19:44.37', 'CN-Top', '全艦戦闘配置', { newText: '全舰进入战斗部署！' });

add(11, '0:21:44.80', '0:21:48.59', 'CN-Top', '繰り返す 誘導員は ガミラス機の発艦準備に備えよ', { newText: '重复一遍：引导员做好加米拉斯战机起飞准备。' });
add(11, '0:10:34.09', '0:10:38.11', 'CN-Main', 'また副長に 君は論理的じゃないと 言われそうだけどね', { newText: '副舰长大概又要说我不合逻辑了。' });

add(13, '0:02:53.71', '0:02:56.05', 'CN-Main', '第７戦隊は 第５ドックに入港せよ', { newText: '第七战队进入五号船坞。' });
add(13, '0:02:57.16', '0:03:00.05', 'CN-Main', '第６および第13駆逐隊は 第９ドックに入港せよ', { newText: '第六、第十三驱逐队进入九号船坞。' });

add(16, '0:14:18.77', '0:14:20.99', 'CN-Main', 'はるか… はるか昔', { newText: '很久很久以前，' });
add(16, '0:14:22.20', '0:14:24.15', 'CN-Main', 'イスカンダルは やって来た', { newText: '伊斯坎达尔人来到了这里。' });
add(16, '0:17:31.09', '0:17:35.76', 'CN-Main', '取得シタ情報ノ中ニ 可視化デキル映像情報ガアリマス', { newText: '获取的信息中包含可视化的影像资料。' });
add(16, '0:21:35.54', '0:21:36.62', 'CN-Main', 'ヤマトに乗り込んだ', { newText: '潜入大和号的' });
add(16, '0:21:36.88', '0:21:39.56', 'CN-Main', 'イズモ計画派の動向を 内偵していました', { newText: '“出云计划”派，我一直在暗中调查其动向。' });
add(16, '0:21:41.46', '0:21:44.25', 'CN-Main', '彼らの反乱を 未然に防ぐことは できませんでしたが', { newText: '虽然没能及时防止叛乱发生，' });

add(17, '0:15:52.24', '0:15:54.65', 'CN-Main', '古代… さっき', { newText: '古代，刚才……' });
add(17, '0:15:55.21', '0:15:58.87', 'CN-Main', '中原中也の詩を 口ずさんでいた友達がいると 言ったろ？', { newText: '我不是说有个常吟诵中原中也诗句的朋友吗？' });

// The official CC truncates the shouted withdrawal after the first reaction;
// the old BD track and the embedded English independently preserve it.
add(18, '0:20:25.89', '0:20:29.27', 'CN-Main', 'そっ そんなあ！ て…撤退！', { newText: '怎么会……撤、撤退！' });

// Background announcements omitted or truncated by the official CC. These
// additions are admitted only where the archived BD track and English agree.
add(21, '0:17:08.46', '0:17:10.79', 'CN-Top', '緊急事態！ 所内で暴動が…', { newText: '紧急情况！营区内发生暴动……' });
add(22, '0:05:05.93', '0:05:08.25', 'CN-Main', '第５分隊 左舷の機体整備状況を知らせ', { newText: '第五分队，报告左舷机体整备情况。' });
add(22, '0:20:21.88', '0:20:23.65', 'CN-Main', '繰り返す 総員 第一種戦闘配置', { newText: '重复一遍：全员进入第一级战斗部署。' });

add(23, '0:13:18.43', '0:13:21.81', 'CN-Main', '今 この瞬間より この軌道都市要塞こそが', { newText: '从此刻起，这座轨道都市要塞' });
add(23, '0:13:22.18', '0:13:25.31', 'CN-Main', 'ガミラスの新たなる帝都 新たなる中心', { newText: '将成为加米拉斯的新帝都、新中心，' });
add(24, '0:08:50.44', '0:08:52.97', 'CN-Main', 'し〜のさ〜ん', { newText: '篠原——！' });
add(24, '0:13:11.08', '0:13:15.44', 'CN-Main', '星の想いを宿した物質 星のエレメント', { newText: '承载着星球记忆的物质——星之元素。' });
add(24, '0:13:16.07', '0:13:17.55', 'CN-Main', 'コスモリバースはね', { newText: '至于宇宙复原系统，' });

const directChineseFixes = new Map([
  [2, [
    ['0:13:15.25','0:13:17.80','这家伙貌似是自动播报的呢','看来这家伙要被送去自动导航室了。'],
    ['0:06:16.45','0:06:21.08','但是 这并不是以脱离地球为目的的出云计划','但这不是旨在逃离地球的出云计划。'],
  ]],
  [3, [
    ['0:02:53.38','0:02:55.07','到达火星宇域后','抵达火星空域后，'],
  ]],
  [4, [
    ['0:15:09.31','0:15:10.47','等死吧 伽米公！','等着瞧吧，加米佬！'],
    ['0:18:28.31','0:18:29.44','吃我一炮 伽米公！','吃我一炮，加米佬！'],
  ]],
  [10, [
    ['0:07:27.78','0:07:28.65','它不是废弃舰只！','它还在运作！'],
  ]],
  [15, [
    ['0:16:25.06','0:16:26.65','缺少补给的现在','如今连补给都难以维持，'],
    ['0:16:34.57','0:16:37.12','进行修正计算后立刻进行跃迁','修正计算后立即跃迁。'],
  ]],
  [16, [
    ['0:14:02.59','0:14:06.22','那是当然的 这就是伊斯坎达尔的船舰','当然，因为这是伊斯坎达尔的飞船。'],
  ]],
  [17, [
    ['0:13:05.46','0:13:08.91','数据不是已经录入了自动巡航室吗？','数据不是已经录入自动导航室了吗？'],
    ['0:22:00.02','0:22:03.86','她在自动巡航室内沉睡着','她沉睡在自动导航室里。'],
    ['0:06:45.78','0:06:48.15','管理船舰的运行也属医生的职责吗？','管理舰船运行也是医生的职责吗？'],
  ]],
  [18, [
    ['0:06:49.99','0:06:53.16','航海长 像我提交迂回线路的定案','航海长，向我提交迂回航线方案。'],
  ]],
  [21, [
    ['0:06:48.09','0:06:49.16','船舰固定完毕','UX-01已靠岸，系泊完毕。'],
  ]],
  [22, [
    ['0:17:19.08','0:17:20.74','还成吧','嗯……还行吧。'],
  ]],
  [23, [
    ['0:12:47.97','0:12:48.93','我是塔朗','塔朗长官求见。'],
  ]],
  [24, [
    ['0:13:18.43','0:13:21.87','正是需要把这元素带到这里来才能完成的','只有把这一要素带到这里，才能完成。'],
  ]],
]);

const movieMissingJapanese = [
  ['1:03:37.97', '1:03:39.17', 'CN-Top', '退避 急げ！'],
  ['1:26:52.14', '1:26:53.40', 'CN-Top', 'どこから来た!?'],
  ['1:44:46.09', '1:44:48.09', 'CN-Top', '強制退避命令を発動！'],
];

const movieDirectFixes = [
  ['1:15:49.11', '1:15:50.64', 'CN-Main', '留在影像中的话。', '哥哥留下的话。'],
  ['1:03:34.41', '1:03:35.37', 'CN-Top', '敌袭引发连锁爆炸，', '敌袭导致'],
  ['1:03:35.58', '1:03:37.32', 'CN-Top', '第五区能源舱起火！', '第五区能源罐发生连锁爆炸！'],
  ['1:15:47.65', '1:15:48.43', 'CN-Main', '这是我哥哥临终前，', '这是我……'],
];

let changed = 0;
for (const [episode, episodeTargets] of targets) {
  const file = episodeFile(episode);
  for (const target of episodeTargets) if (applyTarget(file, target)) changed++;
}

for (const [episode, fixes] of directChineseFixes) {
  const file = episodeFile(episode);
  for (const [start, end, oldText, newText] of fixes) {
    if (applyTarget(file, { start, end, style: 'CN-Main', oldText, newText })) changed++;
  }
}

for (const [start, end, style, jpText] of movieMissingJapanese) {
  if (applyTarget(movieFile, { start, end, style, jpText, jpStyle: 'JP-Top' })) changed++;
}

for (const [start, end, style, oldText, newText] of movieDirectFixes) {
  if (applyTarget(movieFile, { start, end, style, oldText, newText })) changed++;
}

const globalChineseReplacements = [
  ['自动巡航室', '自动导航室'],
  ['伽米公', '加米佬'],
  ['次元潜航舰', '次元潜水艇'],
  ['次元潜航艇', '次元潜水艇'],
  ['潜航舰', '潜水艇'],
  ['自动航法室', '自动导航室'],
  ['分析师', '分析士'],
  ['掌帆长', '水手长'],
  ['掌帆長', '水手长'],
];
const globalChineseRegexReplacements = [
  [/大麦哲伦银河/g, '大麦哲伦云'],
  [/大麦哲伦(?!云)/g, '大麦哲伦云'],
];
for (const file of [...Array.from({ length: 26 }, (_, index) => episodeFile(index + 1)), movieFile]) {
  const loaded = readAss(file);
  let fileChanged = false;
  loaded.lines = loaded.lines.map((line) => {
    const event = parseEvent(line);
    if (!event || event.kind !== 'Dialogue' || !/^CN-|^Title$/.test(event.style)) return line;
    const before = event.text;
    for (const [from, to] of globalChineseReplacements) event.text = event.text.split(from).join(to);
    for (const [expression, replacement] of globalChineseRegexReplacements) event.text = event.text.replace(expression, replacement);
    if (event.text !== before) {
      changed++;
      fileChanged = true;
      return serializeEvent(event);
    }
    return line;
  });
  if (fileChanged) writeAss(file, loaded);
}

console.log(JSON.stringify({ changed, structuralTargets: [...targets.values()].reduce((sum, rows) => sum + rows.length, 0) }, null, 2));
