const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const outputRoot = path.join(root, 'outputs');
const backupRoot = path.join(root, 'review_work', 'backups', 'pre_streaming_typography_20260825');
const tvName = '宇宙战舰大和号2199.TV.简日双语.精校';
const movieName = '宇宙战舰大和号2199 星巡的方舟.简日双语.精校';
const eligibleStyles = new Set(['CN-Main', 'CN-Main-OS', 'CN-Top', 'CN-Alien', 'CN-Science-Note']);

function parseEvent(line) {
  const match = line.match(/^(Dialogue|Comment): ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    kind: match[1], layer: match[2], start: match[3], end: match[4], style: match[5],
    name: match[6], marginL: match[7], marginR: match[8], marginV: match[9],
    effect: match[10], text: match[11],
  };
}

function assTags(text) {
  return text.match(/\{[^}]*\}/g) || [];
}

function lineBreaks(text) {
  return text.match(/\\[Nn]/g) || [];
}

function tokens(text) {
  return text.match(/[A-Za-zΑ-Ωα-ω0-9]+(?:[.-][A-Za-zΑ-Ωα-ω0-9]+)*/gu) || [];
}

const pairs = [];
for (const directory of [tvName, movieName]) {
  const outputDir = path.join(outputRoot, directory);
  const backupDir = path.join(backupRoot, directory);
  for (const name of fs.readdirSync(outputDir).filter((item) => item.endsWith('.ass')).sort()) {
    pairs.push({ name, before: path.join(backupDir, name), after: path.join(outputDir, name) });
  }
}

const errors = [];
const changedByStyle = {};
let changedEvents = 0;
let dialogueEvents = 0;

for (const pair of pairs) {
  if (!fs.existsSync(pair.before)) {
    errors.push(`${pair.name}: backup file missing`);
    continue;
  }
  const beforeLines = fs.readFileSync(pair.before, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);
  const afterLines = fs.readFileSync(pair.after, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);
  if (beforeLines.length !== afterLines.length) {
    errors.push(`${pair.name}: line count changed ${beforeLines.length} -> ${afterLines.length}`);
    continue;
  }
  let openDoubleQuotes = 0;
  let closeDoubleQuotes = 0;
  let openSingleQuotes = 0;
  let closeSingleQuotes = 0;
  for (let index = 0; index < beforeLines.length; index++) {
    const before = parseEvent(beforeLines[index]);
    const after = parseEvent(afterLines[index]);
    if (!before && !after) {
      if (beforeLines[index] !== afterLines[index]) errors.push(`${pair.name}:${index + 1}: non-event content changed`);
      continue;
    }
    if (!before || !after) {
      errors.push(`${pair.name}:${index + 1}: event structure changed`);
      continue;
    }
    if (before.kind === 'Dialogue') dialogueEvents++;
    if (after.kind === 'Dialogue' && eligibleStyles.has(after.style) && !after.text.includes('♪')) {
      const visible = after.text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ');
      if (/[「」『』]/.test(visible)) errors.push(`${pair.name}:${index + 1}: corner quote remains`);
      if (/(?<=\p{Script=Han})(?=[A-Za-z0-9Α-Ωα-ω])|(?<=[A-Za-z0-9Α-Ωα-ω%％°])(?=\p{Script=Han})/u.test(visible)) {
        errors.push(`${pair.name}:${index + 1}: Chinese/Latin/Greek/numeric boundary lacks a space`);
      }
      if (/ {2,}/.test(visible)) errors.push(`${pair.name}:${index + 1}: repeated spaces remain`);
      openDoubleQuotes += (visible.match(/“/g) || []).length;
      closeDoubleQuotes += (visible.match(/”/g) || []).length;
      openSingleQuotes += (visible.match(/‘/g) || []).length;
      closeSingleQuotes += (visible.match(/’/g) || []).length;
    }
    for (const field of ['kind', 'layer', 'start', 'end', 'style', 'name', 'marginL', 'marginR', 'marginV', 'effect']) {
      if (before[field] !== after[field]) errors.push(`${pair.name}:${index + 1}: frozen field ${field} changed`);
    }
    if (before.text === after.text) continue;
    changedEvents++;
    changedByStyle[before.style] = (changedByStyle[before.style] || 0) + 1;
    if (before.kind !== 'Dialogue' || !eligibleStyles.has(before.style)) {
      errors.push(`${pair.name}:${index + 1}: out-of-scope text changed in ${before.style}`);
    }
    if (before.text.includes('♪') || after.text.includes('♪')) errors.push(`${pair.name}:${index + 1}: song text changed`);
    if (JSON.stringify(assTags(before.text)) !== JSON.stringify(assTags(after.text))) errors.push(`${pair.name}:${index + 1}: ASS tags changed`);
    if (JSON.stringify(lineBreaks(before.text)) !== JSON.stringify(lineBreaks(after.text))) errors.push(`${pair.name}:${index + 1}: line breaks changed`);
    if (JSON.stringify(tokens(before.text)) !== JSON.stringify(tokens(after.text))) errors.push(`${pair.name}:${index + 1}: Latin/Greek/numeric token changed`);
  }
  if (openDoubleQuotes !== closeDoubleQuotes) errors.push(`${pair.name}: double quote imbalance ${openDoubleQuotes}/${closeDoubleQuotes}`);
  if (openSingleQuotes !== closeSingleQuotes) errors.push(`${pair.name}: single quote imbalance ${openSingleQuotes}/${closeSingleQuotes}`);
}

const reportFile = path.join(root, 'review_work', 'tables', 'streaming_typography_applied_changes.tsv');
const reportRows = fs.readFileSync(reportFile, 'utf8').trim().split(/\r?\n/).slice(1).length;
if (reportRows !== changedEvents) errors.push(`change report count ${reportRows} differs from actual ${changedEvents}`);

console.log(JSON.stringify({
  ok: errors.length === 0,
  files: pairs.length,
  dialogueEvents,
  changedEvents,
  changedByStyle,
  reportRows,
  errors,
}, null, 2));
process.exitCode = errors.length ? 1 : 0;
