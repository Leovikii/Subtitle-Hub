const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const oldDir = path.join(root, 'sources', 'tv_old_kamigami_embedded_fallback');
const reportFile = path.join(root, 'review_work', 'tables', 'official_japanese_split_proposals.tsv');
const apply = process.argv.includes('--apply');

function seconds(value) {
  const [h, m, s] = value.split(':');
  return Number(h) * 3600 + Number(m) * 60 + Number(s);
}

function clean(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ').replace(/\\h/g, ' ').replace(/\s+/g, ' ').trim();
}

function normalize(text) {
  return clean(text)
    .replace(/（[^）]*）/g, '')
    .replace(/\([^)]*\)/g, '')
    .replace(/[０-９]/g, (char) => String(char.charCodeAt(0) - 0xff10))
    .replace(/[\s\u3000「」『』“”‘’\[\]【】〈〉《》！？!?…‥〜～・、。，．：:；;―—ｰー()（）]/g, '')
    .toLowerCase();
}

function levenshtein(a, b) {
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let previous = Array.from({ length: b.length + 1 }, (_, index) => index);
  for (let i = 1; i <= a.length; i++) {
    const current = [i];
    for (let j = 1; j <= b.length; j++) {
      current[j] = Math.min(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    previous = current;
  }
  return previous[b.length];
}

function similarity(a, b) {
  if (!a || !b) return 0;
  return 1 - levenshtein(a, b) / Math.max(a.length, b.length);
}

function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)];
}

function parseEvent(line, lineIndex) {
  const match = line.match(/^(Dialogue|Comment): ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    lineIndex, kind: match[1], layer: match[2], startRaw: match[3], endRaw: match[4],
    start: seconds(match[3]), end: seconds(match[4]), style: match[5], name: match[6],
    marginL: match[7], marginR: match[8], marginV: match[9], effect: match[10],
    text: clean(match[11]), norm: normalize(match[11]),
  };
}

function serializeEvent(event) {
  return `${event.kind}: ${event.layer},${event.startRaw},${event.endRaw},${event.style},${event.name},${event.marginL},${event.marginR},${event.marginV},${event.effect},${event.text}`;
}

function related(a, b) {
  if (!a || !b || Math.max(a.length, b.length) < 8) return false;
  if (a === b) return true;
  const shorter = a.length <= b.length ? a : b;
  const longer = a.length > b.length ? a : b;
  return longer.includes(shorter) && shorter.length / longer.length >= 0.42;
}

function bestOldForAxis(event, oldEvents, offset) {
  const start = event.start + offset;
  const end = event.end + offset;
  const candidates = oldEvents.map((old) => {
    const overlap = Math.min(old.end, end + 0.2) - Math.max(old.start, start - 0.2);
    const startDistance = Math.abs(old.start - start);
    return { old, overlap, startDistance };
  }).filter(({ overlap, startDistance }) => overlap > 0 || startDistance < 0.65)
    .sort((a, b) => b.overlap - a.overlap || a.startDistance - b.startDistance);
  return candidates[0]?.old || null;
}

function bestPartition(tokens, oldSegments) {
  const count = oldSegments.length;
  if (tokens.length < count || oldSegments.some((segment) => !segment.norm)) return null;
  const memo = new Map();
  function solve(axis, tokenIndex) {
    const key = `${axis}|${tokenIndex}`;
    if (memo.has(key)) return memo.get(key);
    if (axis === count) return tokenIndex === tokens.length ? { score: 0, pieces: [], scores: [] } : null;
    const remainingAxes = count - axis - 1;
    let best = null;
    for (let end = tokenIndex + 1; end <= tokens.length - remainingAxes; end++) {
      const text = tokens.slice(tokenIndex, end).join(' ');
      const score = similarity(normalize(text), oldSegments[axis].norm);
      const tail = solve(axis + 1, end);
      if (!tail) continue;
      const candidate = { score: score + tail.score, pieces: [text, ...tail.pieces], scores: [score, ...tail.scores] };
      if (!best || candidate.score > best.score) best = candidate;
    }
    memo.set(key, best);
    return best;
  }
  return solve(0, 0);
}

const reportRows = [];
let appliedRuns = 0;
let appliedEvents = 0;

for (let episode = 1; episode <= 26; episode++) {
  const token = `S01E${String(episode).padStart(2, '0')}`;
  const fileName = fs.readdirSync(tvDir).find((name) => name.includes(token) && name.endsWith('.ass'));
  if (!fileName) throw new Error(`Missing ${token}`);
  const file = path.join(tvDir, fileName);
  const raw = fs.readFileSync(file);
  const bom = raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  const source = raw.toString('utf8').replace(/^\uFEFF/, '');
  const newline = source.includes('\r\n') ? '\r\n' : '\n';
  const lines = source.split(/\r?\n/);
  const events = lines.map(parseEvent).filter(Boolean);
  const jpEvents = events.filter((event) => event.kind === 'Dialogue' && /^JP-(Main|Top)$/.test(event.style));
  const oldText = fs.readFileSync(path.join(oldDir, `E${String(episode).padStart(2, '0')}.kamigami.jpn.ass`), 'utf8');
  const oldEvents = oldText.replace(/^\uFEFF/, '').split(/\r?\n/).map(parseEvent).filter(Boolean)
    .filter((event) => event.kind === 'Dialogue' && event.style.toLowerCase().startsWith('jp') && !/op|ed/.test(event.style.toLowerCase()));

  const oldByNorm = new Map();
  for (const event of oldEvents) {
    if (!oldByNorm.has(event.norm)) oldByNorm.set(event.norm, []);
    oldByNorm.get(event.norm).push(event);
  }
  const offsets = [];
  for (const event of jpEvents) {
    const matches = oldByNorm.get(event.norm) || [];
    if (matches.length === 1 && Math.abs(matches[0].start - event.start) < 5) offsets.push(matches[0].start - event.start);
  }
  const offset = median(offsets);

  const runs = [];
  for (const style of ['JP-Main', 'JP-Top']) {
    const styled = jpEvents.filter((event) => event.style === style).sort((a, b) => a.start - b.start || a.lineIndex - b.lineIndex);
    for (let index = 0; index < styled.length - 1;) {
      let end = index + 1;
      let canonical = styled[index];
      while (end < styled.length && styled[end].start - styled[end - 1].end <= 1.2 && related(canonical.norm, styled[end].norm)) {
        if (styled[end].norm.length > canonical.norm.length) canonical = styled[end];
        end++;
      }
      if (end - index >= 2) runs.push({ events: styled.slice(index, end), canonical });
      index = Math.max(end, index + 1);
    }
  }

  let fileChanged = false;
  for (const run of runs) {
    const oldSegments = run.events.map((event) => bestOldForAxis(event, oldEvents, offset));
    const tokens = run.canonical.text.split(/\s+/).filter(Boolean);
    const partition = bestPartition(tokens, oldSegments.map((event) => event || { norm: '', text: '' }));
    const average = partition ? partition.score / run.events.length : 0;
    const minimum = partition ? Math.min(...partition.scores) : 0;
    const accepted = Boolean(partition && average >= 0.65 && minimum >= 0.30 && partition.pieces.every((piece) => normalize(piece).length >= 1));
    reportRows.push({
      episode: token, start: run.events[0].startRaw, end: run.events.at(-1).endRaw,
      official: run.canonical.text, old: oldSegments.map((event) => event?.text || '').join(' | '),
      proposed: partition?.pieces.join(' | ') || '', average: average.toFixed(3), minimum: minimum.toFixed(3), accepted,
    });
    if (!apply || !accepted) continue;
    for (let index = 0; index < run.events.length; index++) {
      const event = run.events[index];
      event.text = partition.pieces[index];
      lines[event.lineIndex] = serializeEvent(event);
      appliedEvents++;
    }
    appliedRuns++;
    fileChanged = true;
  }
  if (fileChanged) fs.writeFileSync(file, `${bom ? '\uFEFF' : ''}${lines.join(newline)}`, 'utf8');
}

const headers = ['集数', '开始', '结束', '官方完整日文', '诸神旧分句', '建议官方分句', '平均相似度', '最低相似度', '自动采用'];
const outputLines = [headers.join('\t'), ...reportRows.map((row) => [
  row.episode, row.start, row.end, row.official, row.old, row.proposed, row.average, row.minimum, row.accepted ? '是' : '否',
].map((value) => String(value).replace(/[\t\r\n]+/g, ' ')).join('\t'))];
fs.writeFileSync(reportFile, `\uFEFF${outputLines.join('\r\n')}\r\n`, 'utf8');
console.log(JSON.stringify({ apply, proposals: reportRows.length, accepted: reportRows.filter((row) => row.accepted).length, appliedRuns, appliedEvents, reportFile }, null, 2));
