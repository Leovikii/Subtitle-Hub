const fs = require('fs');
const path = require('path');

const apply = process.argv.includes('--apply');
const root = path.resolve(__dirname, '..');
const sourceRootOption = process.argv.find((argument) => argument.startsWith('--source-root='));
const outputRoot = sourceRootOption ? path.resolve(sourceRootOption.slice('--source-root='.length)) : path.join(root, 'outputs');
const tvDir = path.join(outputRoot, '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(outputRoot, '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');
const reportFile = path.join(root, 'review_work', 'tables', 'streaming_typography_applied_changes.tsv');
const eligibleStyles = new Set(['CN-Main', 'CN-Main-OS', 'CN-Top', 'CN-Alien', 'CN-Science-Note']);

const unquotedProperNames = new Set([
  '大和号', '海鸥号', '雪风', 'EX178', '村雨号', '猎鹰', '天照', '雾岛', '大和',
  '大和号计划', '大和计划', '矶风', '䲟鱼号', '阿武隈', '鞍马', '出云', '出云计划',
  '岛风', '钿女', '海鸥', '雪风号', '宇宙零式', '夕雾', '巴伦',
]);

function parseEvent(line) {
  const match = line.match(/^(Dialogue|Comment): ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    kind: match[1], layer: match[2], start: match[3], end: match[4], style: match[5],
    name: match[6], marginL: match[7], marginR: match[8], marginV: match[9],
    effect: match[10], text: match[11],
  };
}

function serializeEvent(event) {
  return `${event.kind}: ${event.layer},${event.start},${event.end},${event.style},${event.name},${event.marginL},${event.marginR},${event.marginV},${event.effect},${event.text}`;
}

function readAss(file) {
  const raw = fs.readFileSync(file);
  const bom = raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  const text = raw.toString('utf8').replace(/^\uFEFF/, '');
  return { bom, newline: text.includes('\r\n') ? '\r\n' : '\n', lines: text.split(/\r?\n/) };
}

function writeAss(file, loaded) {
  fs.writeFileSync(file, `${loaded.bom ? '\uFEFF' : ''}${loaded.lines.join(loaded.newline)}`, 'utf8');
}

function protectAssSyntax(text) {
  const tokens = [];
  const protectedText = text.replace(/\{[^}]*\}|\\[Nn]/g, (token) => {
    const placeholder = `\uE000${tokens.length}\uE001`;
    tokens.push(token);
    return placeholder;
  });
  return { protectedText, tokens };
}

function restoreAssSyntax(text, tokens) {
  return text.replace(/\uE000(\d+)\uE001/g, (_, index) => tokens[Number(index)]);
}

function visibleText(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' / ').trim();
}

function classifyAndNormalize(text) {
  const reasons = new Set();
  const { protectedText, tokens } = protectAssSyntax(text);
  let result = protectedText;

  // “下集/下回”已经明确说明其后是标题，无需再用装饰性引号。
  result = result.replace(/(^| )(?:下集|下回) +[「『]([^」』]+)[」』]/g, (full, prefix, title) => {
    reasons.add('删除下集标题装饰引号');
    const lead = full.slice(prefix.length).match(/^(下集|下回)/)[1];
    return `${prefix}${lead} ${title}`;
  });

  // 作品名使用书名号；这是当前语料中唯一明确的嵌套作品名。
  result = result.replace(/『9号观测员的心』/g, () => {
    reasons.add('作品名改用书名号');
    return '《9号观测员的心》';
  });

  // 舰船、战机、计划和地点等专名不依赖引号即可识别，删除装饰性引号。
  result = result.replace(/[「『]([^」』]+)[」』]/g, (full, content) => {
    if (!unquotedProperNames.has(content)) return full;
    reasons.add('删除专名装饰引号');
    return content;
  });

  // 其余均属于直接引语、引用语或确有必要的强调，转为简体弯引号。
  result = result.replace(/「([^」]+)」/g, (_, content) => {
    reasons.add('直角引号改为简体弯引号');
    return `“${content}”`;
  });
  result = result.replace(/『([^』]+)』/g, (_, content) => {
    reasons.add('嵌套直角引号改为简体单引号');
    return `‘${content}’`;
  });

  // 中文与完整的拉丁/希腊字母或数字标识之间补半角空格，不拆标识内部。
  const beforeMixed = result;
  result = result.replace(/(?<=\p{Script=Han})(?=[A-Za-z0-9Α-Ωα-ω])/gu, ' ');
  result = result.replace(/(?<=[A-Za-z0-9Α-Ωα-ω%％°])(?=\p{Script=Han})/gu, ' ');
  if (result !== beforeMixed) reasons.add('中西文或数字混排补空格');

  result = result.replace(/[ \t]+/g, ' ');
  result = result.replace(/ +([？！：…—”’》】）])/g, '$1');
  result = result.replace(/([“‘《【（]) +/g, '$1');
  result = result.trim();
  result = restoreAssSyntax(result, tokens).replace(/ *\\([Nn]) */g, '\\$1');
  return { text: result, reasons: [...reasons].join('；') };
}

function workLabel(file) {
  if (file === movieFile) return '星巡的方舟';
  const match = path.basename(file).match(/S01E(\d{2})/);
  return `TV E${match[1]}`;
}

const manualOverrides = new Map([
  ['TV E09|0:01:40.64|0:01:45.17', '欣赏 21 世纪末的名作《9 号观测员的心》'],
  // 引文跨越相邻事件时保留首条开引号、末条闭引号，不改断句或时间轴。
  ['TV E17|0:07:03.46|0:07:05.77', '“就算是上级命令'],
  ['TV E17|0:07:06.54|0:07:10.32', '如果认为那是错误的就应该勇敢地去纠正它”'],
  ['TV E17|0:09:19.10|0:09:20.63', '“泥泞不堪的悲伤上'],
  ['TV E17|0:09:21.17|0:09:23.41', '今日小雪仍降”吗'],
  ['TV E17|0:17:21.58|0:17:23.55', '“泥泞不堪的悲哀上'],
  ['TV E17|0:17:24.91|0:17:27.46', '今日小雪仍降”'],
  // 修复原句缺少闭引号且问号错置的问题。
  ['TV E19|0:07:28.94|0:07:31.22', '这还说是“精锐部队”呢？'],
  // E25 将“大结局”和集名拆成相邻两条；集名无需再加装饰性引号。
  ['TV E25|0:27:46.97|0:27:49.05', '湛蓝色星球的回忆'],
  // 电影中的海伦·凯勒引文跨越三条，第三条补齐外层闭引号并规范内层引号。
  ['星巡的方舟|1:03:14.18|1:03:16.02', '终于理解了‘水’这个词”'],
]);

const manualReasons = new Map([
  ['TV E09|0:01:40.64|0:01:45.17', '作品名改用书名号；中西文或数字混排补空格；人工修正“世纪”错字'],
  ['TV E17|0:07:03.46|0:07:05.77', '跨事件引文改用简体弯引号'],
  ['TV E17|0:07:06.54|0:07:10.32', '跨事件引文改用简体弯引号'],
  ['TV E17|0:09:19.10|0:09:20.63', '跨事件引文改用简体弯引号'],
  ['TV E17|0:09:21.17|0:09:23.41', '跨事件引文改用简体弯引号'],
  ['TV E17|0:17:21.58|0:17:23.55', '跨事件引文改用简体弯引号'],
  ['TV E17|0:17:24.91|0:17:27.46', '跨事件引文改用简体弯引号'],
  ['TV E19|0:07:28.94|0:07:31.22', '修复缺失闭引号及问号错置'],
  ['TV E25|0:27:46.97|0:27:49.05', '删除大结局标题装饰引号'],
  ['星巡的方舟|1:03:14.18|1:03:16.02', '补齐跨事件引文闭引号并规范嵌套引号'],
]);

const files = fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort().map((name) => path.join(tvDir, name));
files.push(movieFile);
const changes = [];
let changedFiles = 0;

for (const file of files) {
  const loaded = readAss(file);
  const work = workLabel(file);
  let fileChanged = false;
  for (let index = 0; index < loaded.lines.length; index++) {
    const event = parseEvent(loaded.lines[index]);
    if (!event || event.kind !== 'Dialogue' || !eligibleStyles.has(event.style)) continue;
    if (visibleText(event.text).includes('♪')) continue;
    const key = `${work}|${event.start}|${event.end}`;
    const normalized = classifyAndNormalize(event.text);
    const after = manualOverrides.get(key) ?? normalized.text;
    if (after === event.text) continue;
    const reason = manualReasons.get(key) ?? normalized.reasons;
    changes.push([work, event.start, event.end, event.style, event.text, after, reason]);
    event.text = after;
    loaded.lines[index] = serializeEvent(event);
    fileChanged = true;
  }
  if (fileChanged) {
    changedFiles++;
    if (apply) writeAss(file, loaded);
  }
}

fs.mkdirSync(path.dirname(reportFile), { recursive: true });
const rows = [['作品', '开始', '结束', '样式', '修改前', '修改后', '修改类型'], ...changes];
if (changes.length || !fs.existsSync(reportFile)) {
  fs.writeFileSync(reportFile, rows.map((row) => row.map((cell) => String(cell ?? '').replace(/[\t\r\n]+/g, ' ').trim()).join('\t')).join('\n'), 'utf8');
}

console.log(JSON.stringify({ apply, files: files.length, changedFiles, changes: changes.length, reportFile }, null, 2));
