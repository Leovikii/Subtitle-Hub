const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const TV_FINAL = path.join(ROOT, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const MOVIE_FINAL = path.join(ROOT, 'outputs', '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');
const TV_EN = path.join(ROOT, 'sources', 'tv_english_embedded');
const MOVIE_EN = path.join(ROOT, 'sources', 'movie', 'english', 'movie.dialogue.ass');
const OUT = path.join(ROOT, 'review_work', 'tables');

function tsSeconds(value) {
  const [h, m, s] = value.split(':');
  return Number(h) * 3600 + Number(m) * 60 + Number(s);
}

function fmtTs(value) {
  const h = Math.floor(value / 3600);
  const m = Math.floor((value % 3600) / 60);
  const s = (value % 60).toFixed(2).padStart(5, '0');
  return `${h}:${String(m).padStart(2, '0')}:${s}`;
}

function cleanAssText(value) {
  return value
    .replace(/\{[^{}]*\}/g, '')
    .replace(/\\[Nn]/g, ' / ')
    .replace(/\\h/g, ' ')
    .replace(/　/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function readAss(file) {
  let text = fs.readFileSync(file, 'utf8');
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
  const events = [];
  for (const line of text.split(/\r?\n/)) {
    if (!line.startsWith('Dialogue:') && !line.startsWith('Comment:')) continue;
    const colon = line.indexOf(':');
    const kind = line.slice(0, colon);
    const fields = line.slice(colon + 1).trimStart().split(/,(?=(?:[^,]*,){0,8}[^,]*$)/);
    // The lookahead split above is not reliable for all JS engines; use nine explicit cuts.
    let rest = line.slice(colon + 1).trimStart();
    const parts = [];
    for (let i = 0; i < 9; i++) {
      const comma = rest.indexOf(',');
      if (comma < 0) break;
      parts.push(rest.slice(0, comma));
      rest = rest.slice(comma + 1);
    }
    parts.push(rest);
    if (parts.length !== 10) continue;
    const start = tsSeconds(parts[1]);
    const end = tsSeconds(parts[2]);
    if (!Number.isFinite(start) || !Number.isFinite(end)) continue;
    events.push({
      kind,
      layer: Number(parts[0]),
      start,
      end,
      style: parts[3],
      name: parts[4],
      effect: parts[8],
      text: parts[9],
      clean: cleanAssText(parts[9]),
    });
  }
  return events;
}

function overlap(a, b) {
  return Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start));
}

function matchingJapanese(cn, events) {
  const styleMap = {
    'CN-Main': new Set(['JP-Main']),
    'CN-Main-OS': new Set(['JP-Main']),
    'CN-Top': new Set(['JP-Top']),
    'ED-CN': new Set(['ED-JP']),
  };
  const target = styleMap[cn.style] || new Set();
  return events
    .filter(e => e.kind === 'Dialogue' && target.has(e.style) && Math.abs(e.start - cn.start) < 0.011 && Math.abs(e.end - cn.end) < 0.011)
    .sort((a, b) => a.start - b.start || a.layer - b.layer);
}

function matchingEnglish(cn, events, top = false) {
  let candidates = events.filter(e => {
    if (e.kind !== 'Dialogue' || !e.clean) return false;
    const ov = overlap(cn, e);
    if (ov <= 0) return false;
    const shortest = Math.max(0.01, Math.min(cn.end - cn.start, e.end - e.start));
    return !(ov / shortest < 0.18 && ov < 0.30);
  });
  if (!candidates.length) {
    candidates = events.filter(e => e.kind === 'Dialogue' && e.clean && Math.abs(e.start - cn.start) <= 0.35);
  }
  if (!candidates.length) return [];
  let preferred;
  if (top) preferred = candidates.filter(e => !['default', 'dialogue'].includes(e.style.toLowerCase()));
  else preferred = candidates.filter(e => ['default', 'dialogue', 'main'].includes(e.style.toLowerCase()));
  const chosen = preferred.length ? preferred : candidates;
  return chosen.sort((a, b) => a.start - b.start || a.end - b.end || a.style.localeCompare(b.style));
}

function uniqueText(events) {
  return [...new Set(events.map(e => e.clean).filter(Boolean))].join(' | ');
}

function digitTokens(text) {
  return new Set(text.match(/\d+(?:\.\d+)?/g) || []);
}

function setsEqual(a, b) {
  return a.size === b.size && [...a].every(x => b.has(x));
}

function candidateReasons(cn, jp, en, style) {
  const reasons = [];
  if (['CN-Main', 'CN-Main-OS', 'CN-Top', 'ED-CN'].includes(style) && !jp) reasons.push('缺少同轴日文');
  const cnDigits = digitTokens(cn);
  const sourceDigits = new Set([...digitTokens(jp), ...digitTokens(en)]);
  if (sourceDigits.size && !setsEqual(cnDigits, sourceDigits)) {
    reasons.push(`数字需核对（中=${[...cnDigits].sort().join('/')}，源=${[...sourceDigits].sort().join('/')}）`);
  }

  const source = `${jp} ${en}`.toLowerCase();
  const rules = [
    [/長官/i, /长官|司令|阁下/, '称谓“長官”可能误译'],
    [/艦長/i, /舰长|船长/, '称谓“艦長”可能漏译/误译'],
    [/右舷|starboard/i, /右舷|右侧|右方|右边/, '左右舷方向需核对'],
    [/左舷|port side/i, /左舷|左侧|左方|左边/, '左右舷方向需核对'],
    [/撤退|retreat|withdraw/i, /撤退|退却|撤离|后撤/, '撤退语义可能漏译'],
    [/降伏|surrender/i, /投降|降服/, '投降语义可能漏译'],
    [/戦死|killed in action/i, /战死|阵亡|牺牲/, '战死语义可能漏译'],
    [/死亡|\bdead\b|\bdied\b|\bdeath\b/i, /死|亡|牺牲/, '死亡语义可能漏译'],
    [/生き|\balive\b|\bsurvive/i, /活|生存|幸存/, '生存语义可能漏译'],
    [/命令|\border\b/i, /命令|下令|指示/, '命令语气可能弱化'],
    [/禁止|forbidden|prohibit/i, /禁止|不得|不许/, '禁止语义可能漏译'],
    [/必ず|definitely|without fail/i, /一定|必定|务必/, '肯定程度可能漏译'],
    [/絶対|absolutely|\bnever\b/i, /绝对|决不|绝不/, '绝对程度可能漏译'],
  ];
  for (const [sourceRe, cnRe, message] of rules) {
    if (sourceRe.test(source) && !cnRe.test(cn)) reasons.push(message);
  }

  const jpNeg = /ない|ぬ(?:[。！!？?]|$)|ず(?:[。！!？?]|$)|できん|ならん|いかん/.test(jp);
  const enNeg = /\b(no|not|never|cannot|can't|won't|without|nothing|nobody)\b/i.test(en);
  const cnNeg = /不|没|无|未|别|莫|勿|休想|甭/.test(cn);
  if (jpNeg && enNeg && !cnNeg) reasons.push('日英均含否定，中文可能漏掉否定');
  if (cnNeg && !jpNeg && en && !enNeg && cn.length >= 6) reasons.push('中文含否定而日英未见，可能存在增译/反义');

  const cnCore = [...cn].filter(c => /[\p{L}\p{N}]/u.test(c)).length;
  const jpCore = [...jp].filter(c => /[\p{L}\p{N}]/u.test(c)).length;
  if (jpCore >= 4 && cnCore >= Math.max(18, Math.floor(jpCore * 1.75))) reasons.push('中文明显长于日文，检查解释性增译');
  if (/[!！]{2,}|[?？]{2,}|[!！][?？]|[?？][!！]/.test(cn)) reasons.push('标点或情绪可能过强');
  if (cn.includes('  ')) reasons.push('连续空格');
  return reasons;
}

function rowsForWork(work, finalEvents, enDialogue, enSigns = []) {
  const rows = [];
  const enAll = [...enDialogue, ...enSigns];
  const cnStyles = new Set(['CN-Main', 'CN-Main-OS', 'CN-Top', 'CN-Alien', 'ED-CN']);
  finalEvents.forEach((cn, index) => {
    if (cn.kind !== 'Dialogue' || !cnStyles.has(cn.style) || !cn.clean) return;
    const jp = uniqueText(matchingJapanese(cn, finalEvents));
    const en = uniqueText(matchingEnglish(cn, enAll, cn.style === 'CN-Top'));
    const reasons = candidateReasons(cn.clean, jp, en, cn.style);
    rows.push({
      '作品': work,
      '序号': String(index + 1),
      '时间': fmtTs(cn.start),
      '结束': fmtTs(cn.end),
      '样式': cn.style,
      '中文': cn.clean,
      '日文': jp,
      '英文': en,
      '自动候选原因': reasons.join('；'),
    });
  });
  return rows;
}

function tsvCell(value) {
  return String(value ?? '').replace(/[\t\r\n]/g, ' ');
}

function writeTsv(file, rows) {
  const fields = ['作品', '序号', '时间', '结束', '样式', '中文', '日文', '英文', '自动候选原因'];
  const lines = [fields.join('\t'), ...rows.map(row => fields.map(f => tsvCell(row[f])).join('\t'))];
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, '\ufeff' + lines.join('\r\n') + '\r\n', 'utf8');
}

function parseFmtTs(value) {
  const [h, m, s] = value.split(':').map(Number);
  return h * 3600 + m * 60 + s;
}

function groupRows(rows) {
  const groups = [];
  for (const row of rows) {
    const start = parseFmtTs(row['时间']);
    const end = parseFmtTs(row['结束']);
    const last = groups[groups.length - 1];
    const sameWork = last && last['作品'] === row['作品'];
    const close = last && start <= last._end + 0.55;
    const sameJp = last && row['日文'] && last._jpSet.has(row['日文']);
    const sameEn = last && row['英文'] && last._enSet.has(row['英文']);
    const compatibleStyle = last && (
      last['样式'] === row['样式'] ||
      (last['样式'].startsWith('CN-Main') && row['样式'].startsWith('CN-Main'))
    );
    if (sameWork && close && compatibleStyle && (sameJp || sameEn)) {
      last['结束'] = row['结束'];
      last._end = Math.max(last._end, end);
      if (!last._cnSet.has(row['中文'])) {
        last._cnSet.add(row['中文']);
        last['中文'] += ` / ${row['中文']}`;
      }
      if (row['日文'] && !last._jpSet.has(row['日文'])) {
        last._jpSet.add(row['日文']);
        last['日文'] += ` | ${row['日文']}`;
      }
      if (row['英文'] && !last._enSet.has(row['英文'])) {
        last._enSet.add(row['英文']);
        last['英文'] += ` | ${row['英文']}`;
      }
      continue;
    }
    groups.push({
      ...row,
      _end: end,
      _cnSet: new Set([row['中文']]),
      _jpSet: new Set(row['日文'] ? [row['日文']] : []),
      _enSet: new Set(row['英文'] ? [row['英文']] : []),
    });
  }
  return groups.map(group => {
    const clean = { ...group };
    delete clean._end;
    delete clean._cnSet;
    delete clean._jpSet;
    delete clean._enSet;
    clean['自动候选原因'] = candidateReasons(clean['中文'], clean['日文'], clean['英文'], clean['样式']).join('；');
    return clean;
  });
}

function main() {
  let allRows = [];
  const finals = fs.readdirSync(TV_FINAL).filter(x => x.toLowerCase().endsWith('.ass')).sort();
  for (const name of finals) {
    const match = name.match(/S01E(\d{2})/);
    if (!match) continue;
    const ep = match[1];
    allRows = allRows.concat(rowsForWork(
      `TV E${ep}`,
      readAss(path.join(TV_FINAL, name)),
      readAss(path.join(TV_EN, `E${ep}.dialogue.ass`)),
      readAss(path.join(TV_EN, `E${ep}.signs.ass`)),
    ));
  }
  allRows = allRows.concat(rowsForWork('星巡的方舟', readAss(MOVIE_FINAL), readAss(MOVIE_EN)));
  const candidates = allRows.filter(row => row['自动候选原因']);
  const groupedRows = groupRows(allRows);
  const groupedCandidates = groupedRows.filter(row => row['自动候选原因']);
  writeTsv(path.join(OUT, 'all_dialogue_trilingual.tsv'), allRows);
  writeTsv(path.join(OUT, 'automatic_candidates.tsv'), candidates);
  writeTsv(path.join(OUT, 'grouped_dialogue_trilingual.tsv'), groupedRows);
  writeTsv(path.join(OUT, 'grouped_automatic_candidates.tsv'), groupedCandidates);
  console.log(`all_rows=${allRows.length}`);
  console.log(`automatic_candidates=${candidates.length}`);
  console.log(`no_same_axis_japanese=${allRows.filter(r => r['自动候选原因'].includes('缺少同轴日文')).length}`);
  console.log(`no_overlapping_english=${allRows.filter(r => !r['英文']).length}`);
  console.log(`grouped_rows=${groupedRows.length}`);
  console.log(`grouped_automatic_candidates=${groupedCandidates.length}`);
}

main();
