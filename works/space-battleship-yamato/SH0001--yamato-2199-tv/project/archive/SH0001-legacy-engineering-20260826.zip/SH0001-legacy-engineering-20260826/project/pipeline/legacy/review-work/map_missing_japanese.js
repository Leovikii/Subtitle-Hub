const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const sourceRoot = path.join(root, 'sources', 'tv_japanese_webrip_official');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const outFile = path.join(__dirname, 'tables', 'missing_japanese_official_candidates.tsv');

function seconds(value) {
  const parts = value.replace(',', '.').split(':').map(Number);
  return parts[0] * 3600 + parts[1] * 60 + parts[2];
}

function episodeNumber(file) {
  return Number(file.match(/S01E(\d{2})/)[1]);
}

function stripAss(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ').replace(/\\h/g, ' ');
}

function cleanOfficial(text) {
  return text
    .replace(/（[^）]*）/g, '')
    .replace(/\([^)]*[ぁ-ゖァ-ヺー][^)]*\)/g, '')
    .replace(/[♬♪]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalize(text) {
  return cleanOfficial(stripAss(text))
    .replace(/[０-９]/g, (char) => String(char.charCodeAt(0) - 0xff10))
    .replace(/[\s\u3000「」『』“”‘’\[\]【】〈〉《》！？!?…‥〜～・、。，．：:；;―—ｰー]/g, '')
    .toLowerCase();
}

function parseSrt(text) {
  return text.replace(/^\uFEFF/, '').split(/\r?\n\r?\n+/).flatMap((block) => {
    const lines = block.split(/\r?\n/);
    const timeIndex = lines.findIndex((line) => line.includes('-->'));
    if (timeIndex < 0) return [];
    const match = lines[timeIndex].match(/(\d\d:\d\d:\d\d[,.]\d+)\s+-->\s+(\d\d:\d\d:\d\d[,.]\d+)/);
    if (!match) return [];
    const raw = lines.slice(timeIndex + 1).join(' ');
    return [{ start: seconds(match[1]), end: seconds(match[2]), raw, clean: cleanOfficial(raw), norm: normalize(raw) }];
  });
}

function parseAss(text) {
  return text.replace(/^\uFEFF/, '').split(/\r?\n/).flatMap((line) => {
    const match = line.match(/^Dialogue: ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
    if (!match) return [];
    return [{ start: seconds(match[2]), end: seconds(match[3]), startRaw: match[2], endRaw: match[3], style: match[4], text: stripAss(match[10]) }];
  });
}

function interpolateSourceTime(target, anchors) {
  let before = null;
  let after = null;
  for (const anchor of anchors) {
    if (anchor.target <= target) before = anchor;
    if (anchor.target >= target) { after = anchor; break; }
  }
  if (before && after && after.target > before.target) {
    const ratio = (target - before.target) / (after.target - before.target);
    return before.source + ratio * (after.source - before.source);
  }
  const anchor = before || after;
  return anchor ? anchor.source + (target - anchor.target) : target;
}

const sourceFiles = fs.readdirSync(sourceRoot, { recursive: true }).filter((name) => name.endsWith('.srt')).map((name) => path.join(sourceRoot, name));
const sourceByEpisode = new Map(sourceFiles.map((file) => [episodeNumber(file), file]));
const rows = [];

for (const finalName of fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort()) {
  const episode = episodeNumber(finalName);
  const finalEvents = parseAss(fs.readFileSync(path.join(tvDir, finalName), 'utf8'));
  const official = parseSrt(fs.readFileSync(sourceByEpisode.get(episode), 'utf8'));
  let corpus = '';
  const charToEvent = [];
  official.forEach((event, index) => {
    for (let i = 0; i < event.norm.length; i++) charToEvent[corpus.length + i] = index;
    corpus += event.norm;
  });
  const anchors = [];
  let cursor = 0;
  for (const event of finalEvents.filter((item) => /^JP-(Main|Top)$/.test(item.style)).sort((a, b) => a.start - b.start || a.end - b.end)) {
    const norm = normalize(event.text);
    if (norm.length < 2) continue;
    let found = corpus.indexOf(norm, cursor);
    if (found < 0) {
      const candidates = [];
      let at = corpus.indexOf(norm);
      while (at >= 0) {
        const sourceIndex = charToEvent[at];
        if (sourceIndex !== undefined) candidates.push({ at, distance: Math.abs(official[sourceIndex].start - event.start) });
        at = corpus.indexOf(norm, at + 1);
      }
      if (candidates.length) found = candidates.sort((a, b) => a.distance - b.distance)[0].at;
    }
    if (found < 0) continue;
    const sourceIndex = charToEvent[found];
    if (sourceIndex === undefined) continue;
    anchors.push({ target: event.start, source: official[sourceIndex].start });
    if (found >= cursor) cursor = found + norm.length;
  }
  anchors.sort((a, b) => a.target - b.target);

  const jpAxis = new Set(finalEvents.filter((event) => /^JP-(Main|Top)$/.test(event.style)).map((event) => `${event.startRaw}|${event.endRaw}|${event.style === 'JP-Top' ? 'top' : 'main'}`));
  for (const cn of finalEvents.filter((event) => ['CN-Main', 'CN-Main-OS', 'CN-Top'].includes(event.style))) {
    const axisType = cn.style === 'CN-Top' ? 'top' : 'main';
    if (jpAxis.has(`${cn.startRaw}|${cn.endRaw}|${axisType}`)) continue;
    const sourceStart = interpolateSourceTime(cn.start, anchors);
    const sourceEnd = interpolateSourceTime(cn.end, anchors);
    let candidates = official.filter((event) => Math.min(event.end, sourceEnd + 0.35) - Math.max(event.start, sourceStart - 0.35) > 0 && event.clean);
    if (!candidates.length) {
      candidates = official
        .map((event) => ({ ...event, distance: Math.abs((event.start + event.end) / 2 - (sourceStart + sourceEnd) / 2) }))
        .filter((event) => event.clean && event.distance < 1.6)
        .sort((a, b) => a.distance - b.distance)
        .slice(0, 2);
    }
    rows.push([
      `E${String(episode).padStart(2, '0')}`, cn.startRaw, cn.endRaw, cn.style, cn.text,
      sourceStart.toFixed(3), sourceEnd.toFixed(3),
      candidates.map((event) => event.clean).join(' | '),
      candidates.map((event) => `${event.start.toFixed(3)}-${event.end.toFixed(3)}`).join(' | '),
    ]);
  }
}

fs.writeFileSync(outFile, '\uFEFF' + [
  ['集数', '目标开始', '目标结束', '中文样式', '中文', '推定官方开始', '推定官方结束', '官方日文候选', '官方候选时间'].join('\t'),
  ...rows.map((row) => row.map((value) => String(value).replace(/[\t\r\n]+/g, ' ')).join('\t')),
].join('\r\n'), 'utf8');
console.log(JSON.stringify({ output: outFile, rows: rows.length, anchors: 'piecewise from official-matched final JP events' }, null, 2));
