const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const finalDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const oldDir = path.join(root, 'sources', 'tv_old_kamigami_embedded_fallback');
const output = path.join(__dirname, 'tables', 'kamigami_mishear_impact_candidates.tsv');

function seconds(value) {
  const [h, m, s] = value.split(':');
  return Number(h) * 3600 + Number(m) * 60 + Number(s);
}

function parseAss(text) {
  return text.replace(/^\uFEFF/, '').split(/\r?\n/).flatMap((line) => {
    const match = line.match(/^Dialogue: ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
    if (!match) return [];
    return [{ start: seconds(match[2]), end: seconds(match[3]), startRaw: match[2], endRaw: match[3], style: match[4], text: clean(match[10]), norm: normalize(match[10]) }];
  });
}

function clean(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ').replace(/\\h/g, ' ').replace(/\s+/g, ' ').trim();
}

function normalize(text) {
  return clean(text)
    .replace(/（[^）]*）/g, '')
    .replace(/\([^)]*\)/g, '')
    .replace(/[０-９]/g, (char) => String(char.charCodeAt(0) - 0xff10))
    .replace(/[\s\u3000「」『』“”‘’\[\]【】〈〉《》！？!?…‥〜～・、。，．：:；;―—ｰー()（）]/g, '')
    .toLowerCase();
}

function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)];
}

function levenshtein(a, b) {
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let previous = Array.from({ length: b.length + 1 }, (_, index) => index);
  for (let i = 1; i <= a.length; i++) {
    const current = [i];
    for (let j = 1; j <= b.length; j++) {
      current[j] = Math.min(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    previous = current;
  }
  return previous[b.length];
}

function similarity(a, b) {
  if (!a || !b) return 0;
  if (a.includes(b) || b.includes(a)) return Math.min(a.length, b.length) / Math.max(a.length, b.length) + 0.25;
  return 1 - levenshtein(a, b) / Math.max(a.length, b.length);
}

const rows = [];
for (let episode = 1; episode <= 26; episode++) {
  const token = `S01E${String(episode).padStart(2, '0')}`;
  const finalName = fs.readdirSync(finalDir).find((name) => name.includes(token) && name.endsWith('.ass'));
  const finalEvents = parseAss(fs.readFileSync(path.join(finalDir, finalName), 'utf8'));
  const oldEvents = parseAss(fs.readFileSync(path.join(oldDir, `E${String(episode).padStart(2, '0')}.kamigami.jpn.ass`), 'utf8'))
    .filter((event) => event.style.toLowerCase().startsWith('jp') && !/ed|op/.test(event.style.toLowerCase()));

  const oldByNorm = new Map();
  for (const event of oldEvents) {
    if (!oldByNorm.has(event.norm)) oldByNorm.set(event.norm, []);
    oldByNorm.get(event.norm).push(event);
  }
  const offsets = [];
  for (const event of finalEvents.filter((item) => /^JP-(Main|Top)$/.test(item.style))) {
    const matches = oldByNorm.get(event.norm) || [];
    if (matches.length === 1 && Math.abs(matches[0].start - event.start) < 5) offsets.push(matches[0].start - event.start);
  }
  const offset = median(offsets);

  const cnByAxis = new Map(finalEvents.filter((event) => /^CN-(Main|Main-OS|Top)$/.test(event.style)).map((event) => [`${event.startRaw}|${event.endRaw}|${event.style === 'CN-Top' ? 'top' : 'main'}`, event.text]));
  for (const event of finalEvents.filter((item) => /^JP-(Main|Top)$/.test(item.style))) {
    if (event.norm.length < 3) continue;
    const mappedStart = event.start + offset;
    const mappedEnd = event.end + offset;
    let candidates = oldEvents.filter((old) => Math.min(old.end, mappedEnd + 0.32) - Math.max(old.start, mappedStart - 0.32) > 0);
    if (!candidates.length) candidates = oldEvents.filter((old) => Math.abs(old.start - mappedStart) < 0.75);
    if (!candidates.length) continue;
    candidates = candidates.sort((a, b) => a.start - b.start || a.end - b.end);
    const variants = [...candidates.map((old) => ({ text: old.text, norm: old.norm }))];
    for (let begin = 0; begin < candidates.length; begin++) {
      for (let end = begin + 1; end < Math.min(candidates.length, begin + 3); end++) {
        variants.push({
          text: candidates.slice(begin, end + 1).map((old) => old.text).join(' '),
          norm: candidates.slice(begin, end + 1).map((old) => old.norm).join(''),
        });
      }
    }
    const best = variants.map((variant) => ({ ...variant, score: similarity(event.norm, variant.norm) })).sort((a, b) => b.score - a.score)[0];
    if (best.score >= 0.79) continue;
    const axisType = event.style === 'JP-Top' ? 'top' : 'main';
    rows.push({
      episode: `E${String(episode).padStart(2, '0')}`,
      start: event.startRaw,
      end: event.endRaw,
      style: event.style,
      cn: cnByAxis.get(`${event.startRaw}|${event.endRaw}|${axisType}`) || '',
      official: event.text,
      old: best.text,
      similarity: best.score.toFixed(3),
      offset: offset.toFixed(3),
    });
  }
}

const headers = ['集数', '开始', '结束', '样式', '当前中文', '官方日文', '诸神旧日文', '相似度', '旧轨偏移'];
const lines = [headers.join('\t'), ...rows.map((row) => [row.episode, row.start, row.end, row.style, row.cn, row.official, row.old, row.similarity, row.offset].map((value) => String(value).replace(/[\t\r\n]+/g, ' ')).join('\t'))];
fs.writeFileSync(output, '\uFEFF' + lines.join('\r\n') + '\r\n', 'utf8');
console.log(JSON.stringify({ candidates: rows.length, output }, null, 2));
