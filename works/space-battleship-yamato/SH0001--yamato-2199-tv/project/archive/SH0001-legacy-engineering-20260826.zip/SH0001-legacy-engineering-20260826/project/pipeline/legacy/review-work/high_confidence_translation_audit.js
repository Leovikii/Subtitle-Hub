const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const input = path.join(__dirname, 'tables', 'all_dialogue_trilingual.tsv');
const output = path.join(__dirname, 'tables', 'high_confidence_translation_candidates.tsv');

function parseTsv(text) {
  const lines = text.replace(/^\uFEFF/, '').trimEnd().split(/\r?\n/);
  const headers = lines.shift().split('\t');
  return lines.map((line) => Object.fromEntries(line.split('\t').map((value, index) => [headers[index], value])));
}

function fullwidthToAscii(text) {
  return text.replace(/[０-９]/g, (char) => String(char.charCodeAt(0) - 0xff10));
}

function digits(text) {
  return new Set(fullwidthToAscii(text).match(/\d+(?:\.\d+)?/g) || []);
}

function hasAll(text, expressions) {
  return expressions.every((expression) => expression.test(text));
}

function reasons(row) {
  const cn = row['中文'];
  const jp = row['日文'];
  const en = row['英文'];
  const found = [];
  if (!jp || !en) return found;

  const jpDigits = digits(jp);
  const enDigits = digits(en);
  const cnDigits = digits(cn);
  const commonSourceDigits = [...jpDigits].filter((value) => enDigits.has(value));
  const missing = commonSourceDigits.filter((value) => !cnDigits.has(value));
  if (missing.length) found.push(`日英共同数字未译：${missing.join('/')}`);

  const semanticRules = [
    [/右舷|面舵/, /starboard|right side/i, /右舷|右舵|右侧|右方|右边/, '右舷/右舵'],
    [/左舷|取舵/, /port side|to port|left side/i, /左舷|左舵|左侧|左方|左边/, '左舷/左舵'],
    [/撤退|退避|離脱/, /retreat|withdraw|evacuat|pull out/i, /撤退|撤离|退避|脱离|后撤|撤出/, '撤退/撤离'],
    [/降伏|投降/, /surrender/i, /投降|归顺|降服/, '投降'],
    [/戦死/, /killed in action|died in battle/i, /战死|阵亡|牺牲/, '战死/阵亡'],
    [/必ず/, /definitely|without fail|will return|must/i, /一定|必定|务必|定会|必然|绝对|无论如何/, '必然程度'],
    [/禁止|禁断/, /forbidden|prohibit/i, /禁止|不得|不许|禁忌|禁断/, '禁止/禁忌'],
  ];
  for (const [jpRule, enRule, cnRule, label] of semanticRules) {
    if (jpRule.test(jp) && enRule.test(en) && !cnRule.test(cn)) found.push(`日英共同语义未见：${label}`);
  }

  const jpNeg = /ない|なかった|ません|できん|ならん|いかん|ぬ(?:\s|$)|ず(?:\s|$)/.test(jp);
  const enNeg = /\b(no|not|never|cannot|can't|won't|without|nothing|nobody|neither)\b/i.test(en);
  const cnNeg = /不|没|无|未|别|莫|勿|休想|甭|难以/.test(cn);
  if (jpNeg && enNeg && !cnNeg) found.push('日英共同否定未见');

  const suspiciousChinese = [
    [/的的|地地|得得|成功的[\u4e00-\u9fff]|出色的[\u4e00-\u9fff]/, '疑似“的/地/得”错误'],
    [/参假|簿之岬|地方宇宙舰艇|自动播报|自动巡航室|潜航舰|航法室/, '已知旧听写/术语残留'],
    [/[!！]{2,}|[?？]{2,}|[!！][?？]|[?？][!！]/, '重复或混合问叹号'],
    [/^[\[【].{18,}[\]】]$/, '疑似字幕组长注解'],
  ];
  for (const [expression, label] of suspiciousChinese) if (expression.test(cn)) found.push(label);

  if (hasAll(`${jp} ${en}`, [/死|death|died|dead/i, /兄|brother/i]) && !/死|亡|临终/.test(cn)) {
    found.push('死亡信息可能漏译');
  }
  return found;
}

const rows = parseTsv(fs.readFileSync(input, 'utf8'));
const candidates = rows.flatMap((row) => {
  const found = reasons(row);
  return found.length ? [{ ...row, '高置信候选原因': found.join('；') }] : [];
});
const headers = ['作品', '时间', '结束', '样式', '中文', '日文', '英文', '高置信候选原因'];
const lines = [headers.join('\t'), ...candidates.map((row) => headers.map((header) => String(row[header] || '').replace(/[\t\r\n]/g, ' ')).join('\t'))];
fs.writeFileSync(output, '\uFEFF' + lines.join('\r\n') + '\r\n', 'utf8');
console.log(JSON.stringify({ checked: rows.length, candidates: candidates.length, output }, null, 2));
