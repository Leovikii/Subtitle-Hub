const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(root, 'outputs', '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');
const tableDir = path.join(__dirname, 'tables');
const dialogueStyles = new Set(['CN-Main', 'CN-Main-OS', 'CN-Top', 'CN-Alien', 'CN-Science-Note']);

function parseTime(value) {
  const match = value.match(/^(\d+):(\d{2}):(\d{2})\.(\d{2})$/);
  if (!match) return NaN;
  return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) + Number(match[4]) / 100;
}

function parseEvent(line) {
  const match = line.match(/^Dialogue: ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    start: match[2], end: match[3], style: match[4], text: match[10],
    startSec: parseTime(match[2]), endSec: parseTime(match[3]),
  };
}

function visibleText(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' / ').trim();
}

function visualWidth(text) {
  let width = 0;
  for (const char of visibleText(text)) {
    if (/\p{Script=Han}|[\u3040-\u30ff\uff00-\uffef]/u.test(char)) width += 1;
    else if (!/\s/.test(char)) width += 0.5;
  }
  return Math.round(width * 10) / 10;
}

function characterCount(text) {
  return [...visibleText(text).replace(/ \/ /g, '')].filter((char) => !/\s/.test(char)).length;
}

function proposedMinimalText(text) {
  return text
    .replace(/[，。；、]+/g, ' ')
    .replace(/\s+([？！…—”’》】）])/g, '$1')
    .replace(/([“‘《【（])\s+/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
}

function tsvCell(value) {
  return String(value ?? '').replace(/[\t\r\n]+/g, ' ').trim();
}

function workLabel(file) {
  if (file === movieFile) return '星巡的方舟';
  const match = path.basename(file).match(/S01E(\d{2})/);
  return `TV E${match[1]}`;
}

const files = fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort().map((name) => path.join(tvDir, name));
files.push(movieFile);

const punctuationRows = [];
const typographyRows = [];
const layoutRows = [];
const gapRows = [];
const summary = {
  files: files.length, checkedEvents: 0, punctuationEvents: 0, bannedMarks: 0,
  comma: 0, period: 0, enumerationComma: 0, semicolon: 0,
  cornerQuoteEvents: 0, mixedQuestionExclamation: 0, halfwidthQuestionExclamation: 0,
  over16: 0, over18: 0, cpsOver16: 0, shorterThanFiveSixths: 0, longerThanSeven: 0,
  sameStyleGapUnderTwoFrames: 0,
};

for (const file of files) {
  const work = workLabel(file);
  const events = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/).map(parseEvent).filter(Boolean);
  const scoped = events.filter((event) => dialogueStyles.has(event.style));
  summary.checkedEvents += scoped.length;

  for (const event of scoped) {
    const text = visibleText(event.text);
    const counts = {
      comma: (text.match(/，/g) || []).length,
      period: (text.match(/。/g) || []).length,
      enumerationComma: (text.match(/、/g) || []).length,
      semicolon: (text.match(/；/g) || []).length,
    };
    const banned = counts.comma + counts.period + counts.enumerationComma + counts.semicolon;
    if (banned) {
      summary.punctuationEvents++;
      summary.bannedMarks += banned;
      for (const key of Object.keys(counts)) summary[key] += counts[key];
      punctuationRows.push([
        work, event.start, event.end, event.style, text, proposedMinimalText(text),
        counts.comma, counts.period, counts.enumerationComma, counts.semicolon,
      ]);
    }

    const typographyReasons = [];
    if (/[「」『』]/.test(text)) typographyReasons.push('简体字幕使用直角引号');
    if (/[？！]{2,}|[!?]{2,}|[？!！?][？!！?]/.test(text)) typographyReasons.push('问叹号连用或混用');
    if (/[!?]/.test(text)) typographyReasons.push('半角问号或感叹号');
    if (/[\p{Script=Han}][A-Za-z0-9]|[A-Za-z0-9][\p{Script=Han}]/u.test(text)) typographyReasons.push('中西文或数字混排缺少空格候选');
    if (typographyReasons.length) typographyRows.push([work, event.start, event.end, event.style, text, typographyReasons.join('；')]);
    if (/[「」『』]/.test(text)) summary.cornerQuoteEvents++;
    if (/[？！]{2,}|[!?]{2,}|[？!！?][？!！?]/.test(text)) summary.mixedQuestionExclamation++;
    if (/[!?]/.test(text)) summary.halfwidthQuestionExclamation++;

    const duration = event.endSec - event.startSec;
    const chars = characterCount(text);
    const width = visualWidth(text);
    const cps = duration > 0 ? Math.round(chars / duration * 10) / 10 : Infinity;
    const reasons = [];
    if (width > 16) { reasons.push('视觉宽度超过16'); summary.over16++; }
    if (width > 18) { reasons.push('视觉宽度超过18'); summary.over18++; }
    if (cps > 16) { reasons.push('阅读速度超过16 CPS'); summary.cpsOver16++; }
    if (duration < 5 / 6) { reasons.push('时长短于5/6秒'); summary.shorterThanFiveSixths++; }
    if (duration > 7) { reasons.push('时长超过7秒'); summary.longerThanSeven++; }
    if (reasons.length) layoutRows.push([work, event.start, event.end, event.style, duration.toFixed(2), width, chars, cps, text, reasons.join('；')]);
  }

  const byStyle = new Map();
  for (const event of scoped) {
    if (!byStyle.has(event.style)) byStyle.set(event.style, []);
    byStyle.get(event.style).push(event);
  }
  for (const [style, styleEvents] of byStyle) {
    styleEvents.sort((a, b) => a.startSec - b.startSec || a.endSec - b.endSec);
    for (let index = 1; index < styleEvents.length; index++) {
      const previous = styleEvents[index - 1];
      const current = styleEvents[index];
      const gap = current.startSec - previous.endSec;
      if (gap >= 0 && gap < 2 / 24) {
        summary.sameStyleGapUnderTwoFrames++;
        gapRows.push([work, style, previous.start, previous.end, visibleText(previous.text), current.start, current.end, visibleText(current.text), gap.toFixed(3)]);
      }
    }
  }
}

fs.mkdirSync(tableDir, { recursive: true });
const outputs = {
  punctuation: path.join(tableDir, 'streaming_punctuation_candidates.tsv'),
  typography: path.join(tableDir, 'streaming_typography_candidates.tsv'),
  layout: path.join(tableDir, 'streaming_layout_timing_candidates.tsv'),
  gaps: path.join(tableDir, 'streaming_gap_candidates.tsv'),
};

function writeTsv(file, header, rows) {
  fs.writeFileSync(file, [header, ...rows].map((row) => row.map(tsvCell).join('\t')).join('\n'), 'utf8');
}

writeTsv(outputs.punctuation, ['作品', '开始', '结束', '样式', '当前中文', '极简标点预览', '逗号', '句号', '顿号', '分号'], punctuationRows);
writeTsv(outputs.typography, ['作品', '开始', '结束', '样式', '当前中文', '候选原因'], typographyRows);
writeTsv(outputs.layout, ['作品', '开始', '结束', '样式', '时长秒', '视觉宽度', '字符数', 'CPS', '当前中文', '候选原因'], layoutRows);
writeTsv(outputs.gaps, ['作品', '样式', '前条开始', '前条结束', '前条中文', '后条开始', '后条结束', '后条中文', '间隔秒'], gapRows);

console.log(JSON.stringify({ summary, outputs }, null, 2));
