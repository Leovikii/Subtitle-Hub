const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const tvDir = path.join(root, 'outputs', '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(root, 'outputs', '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');
const tableDir = path.join(__dirname, 'tables');

function parseTime(value) {
  const match = value.match(/^(\d+):(\d{2}):(\d{2})\.(\d{2})$/);
  if (!match) return NaN;
  return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) + Number(match[4]) / 100;
}

function parseEvent(line) {
  const match = line.match(/^(Dialogue|Comment): ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    kind: match[1], start: match[3], end: match[4], style: match[5], text: match[11],
    startSec: parseTime(match[3]), endSec: parseTime(match[4]),
  };
}

function readEvents(file) {
  return fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)
    .map(parseEvent).filter((event) => event && event.kind === 'Dialogue');
}

function visibleText(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' / ').trim();
}

function visualWidth(text) {
  const clean = visibleText(text);
  let width = 0;
  for (const char of clean) {
    if (/\p{Script=Han}|[\u3040-\u30ff\uff00-\uffef]/u.test(char)) width += 1;
    else if (!/\s/.test(char)) width += 0.55;
  }
  return Math.round(width * 10) / 10;
}

function tsvCell(value) {
  return String(value ?? '').replace(/[\t\r\n]+/g, ' ').trim();
}

function episodeNumber(name) {
  const match = name.match(/S01E(\d{2})/);
  return match ? Number(match[1]) : null;
}

const works = fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort().map((name) => {
  const ep = episodeNumber(name);
  return {
    work: `TV E${String(ep).padStart(2, '0')}`,
    file: path.join(tvDir, name),
    english: path.join(__dirname, 'english_tv', `E${String(ep).padStart(2, '0')}.dialogue.ass`),
  };
});
works.push({ work: '星巡的方舟', file: movieFile, english: path.join(__dirname, 'english_movie', 'movie.dialogue.ass') });

const punctuationRows = [];
const splitRows = [];
let checked = 0;

for (const work of works) {
  const events = readEvents(work.file);
  const englishEvents = fs.existsSync(work.english) ? readEvents(work.english) : [];
  const japaneseByAxis = new Map(events.filter((event) => /^JP-(Main|Top)$/.test(event.style))
    .map((event) => [`${event.start}|${event.end}|${event.style}`, event]));

  for (const cn of events.filter((event) => /^CN-(Main|Top)$/.test(event.style))) {
    checked++;
    const jpStyle = cn.style === 'CN-Top' ? 'JP-Top' : 'JP-Main';
    const jp = japaneseByAxis.get(`${cn.start}|${cn.end}|${jpStyle}`);
    const cnText = visibleText(cn.text);
    const jpText = jp ? visibleText(jp.text) : '';
    const song = cnText.includes('♪') || jpText.includes('♪');
    const reasons = [];
    if (!song && /[，。；、]/u.test(cnText)) reasons.push('含流媒体规范禁用标点');
    if (!song && /\s{2,}/.test(cnText)) reasons.push('连续空格');
    if (!song && /[!?]/.test(cnText)) reasons.push('含半角问号或感叹号');
    if (!song && /\.\.\./.test(cnText)) reasons.push('含三个半角句点');
    const chineseQuestionEnding = /[?？][!！]?$/u.test(cnText);
    const rhetoricalExclamation = /(?:啊|呀|难道|岂|不是|可是)[!！]$/u.test(cnText);
    if (!song && /[?？]$/.test(jpText) && !chineseQuestionEnding && !rhetoricalExclamation) reasons.push('日文问句而中文无问号');
    if (!song && /[!！]$/.test(jpText) && !/[!！?？…—~～]$/.test(cnText)) reasons.push('日文感叹而中文无语气标点');
    if (reasons.length) punctuationRows.push([work.work, cn.start, cn.end, cn.style, cnText, jpText, reasons.join('；')]);

    const width = visualWidth(cnText);
    if (song || width < 27) continue;
    const overlaps = englishEvents.filter((en) => Math.min(cn.endSec, en.endSec) - Math.max(cn.startSec, en.startSec) > 0.18);
    const internalBoundaries = [...new Set(overlaps.flatMap((en) => [en.startSec, en.endSec])
      .filter((time) => time > cn.startSec + 0.65 && time < cn.endSec - 0.65).map((time) => time.toFixed(2)))];
    splitRows.push([
      work.work, cn.start, cn.end, cn.style, width, cnText, jpText,
      overlaps.map((en) => `${en.start}-${en.end} ${visibleText(en.text)}`).join(' | '),
      internalBoundaries.join(' / '),
      internalBoundaries.length ? '有英文内部时间点，需按日文语义人工判断' : '无可用英文内部时间点，不拆分',
    ]);
  }
}

fs.mkdirSync(tableDir, { recursive: true });
const punctuationFile = path.join(tableDir, 'chinese_punctuation_candidates.tsv');
const splitFile = path.join(tableDir, 'long_line_split_candidates.tsv');
fs.writeFileSync(punctuationFile, [
  ['作品', '开始', '结束', '样式', '中文', '同轴日文', '候选原因'],
  ...punctuationRows,
].map((row) => row.map(tsvCell).join('\t')).join('\n'), 'utf8');
fs.writeFileSync(splitFile, [
  ['作品', '开始', '结束', '样式', '视觉宽度', '中文', '同轴日文', '重叠英文事件', '英文内部时间点', '处理建议'],
  ...splitRows,
].map((row) => row.map(tsvCell).join('\t')).join('\n'), 'utf8');

console.log(JSON.stringify({
  checked,
  punctuationCandidates: punctuationRows.length,
  longLines: splitRows.length,
  longLinesWithEnglishBoundary: splitRows.filter((row) => row[8]).length,
  punctuationFile,
  splitFile,
}, null, 2));
