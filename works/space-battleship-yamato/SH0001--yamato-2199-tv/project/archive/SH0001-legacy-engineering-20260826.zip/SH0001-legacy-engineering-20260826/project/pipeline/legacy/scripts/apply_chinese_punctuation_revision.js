const fs = require('fs');
const path = require('path');

const apply = process.argv.includes('--apply');
if (apply && !process.argv.includes('--allow-legacy-punctuation')) {
  throw new Error('此脚本采用已废止的逗号式中文标点方案。若确需重建旧版，必须显式加入 --allow-legacy-punctuation；当前精校版应改用 apply_streaming_punctuation_standard.js。');
}
const root = path.resolve(__dirname, '..');
const sourceRootOption = process.argv.find((argument) => argument.startsWith('--source-root='));
const outputRoot = sourceRootOption ? path.resolve(sourceRootOption.slice('--source-root='.length)) : path.join(root, 'outputs');
const tvDir = path.join(outputRoot, '宇宙战舰大和号2199.TV.简日双语.精校');
const movieFile = path.join(outputRoot, '宇宙战舰大和号2199 星巡的方舟.简日双语.精校', '宇宙战舰大和号2199 星巡的方舟.ass');
const reportFile = path.join(root, 'review_work', 'tables', 'punctuation_revision_changes.tsv');

function parseEvent(line) {
  const match = line.match(/^(Dialogue|Comment): ([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),(.*)$/);
  if (!match) return null;
  return {
    kind: match[1], layer: match[2], start: match[3], end: match[4], style: match[5],
    name: match[6], marginL: match[7], marginR: match[8], marginV: match[9],
    effect: match[10], text: match[11],
  };
}

function serializeEvent(event) {
  return `${event.kind}: ${event.layer},${event.start},${event.end},${event.style},${event.name},${event.marginL},${event.marginR},${event.marginV},${event.effect},${event.text}`;
}

function readAss(file) {
  const raw = fs.readFileSync(file);
  const bom = raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  const text = raw.toString('utf8').replace(/^\uFEFF/, '');
  return { bom, newline: text.includes('\r\n') ? '\r\n' : '\n', lines: text.split(/\r?\n/) };
}

function writeAss(file, loaded) {
  fs.writeFileSync(file, `${loaded.bom ? '\uFEFF' : ''}${loaded.lines.join(loaded.newline)}`, 'utf8');
}

function visibleText(text) {
  return text.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, ' ').trim();
}

function internalJapaneseMarks(japanese) {
  const text = visibleText(japanese);
  const marks = [];
  for (let index = 0; index < text.length; index++) {
    if (!/[!?！？]/.test(text[index])) continue;
    if (index === text.length - 1) continue;
    marks.push(/[?？]/.test(text[index]) ? '？' : '！');
  }
  return marks;
}

function safeComma(left, right, gapCount) {
  const leftPart = left.split(/[，！？]/).pop().trim();
  const rightPart = right.split(/[，！？]/)[0].trim();
  if (!leftPart || !rightPart) return false;
  if (/^(?:啊|哎|哎呀|哦|噢|嗯|唔|喂|不|是|对|没错|当然|那么|但是|不过|可是|所以|首先|此外|况且|总之|毕竟|抱歉|对不起|拜托了|真是的|话说回来|重复一遍|怎么可能|怎么会|可恶|什么|慢着|等等)$/.test(leftPart)) return true;
  if (leftPart.length <= 8 && /(?:长官|舰长|副舰长|司令|司令官|先生|老师|博士|医生|总统|阁下|古代|真田|岛|雪|分析士|各位|大家|诸位|哥哥|姐姐|父亲|母亲|君)$/.test(leftPart)) return true;
  if (/^(?:我|你|他|她|它|我们|你们|他们|她们|这|那|敌军|敌舰|本舰|大和号|全员|各位|诸位)/.test(rightPart) && leftPart.length >= 2) return true;
  if (/(?:了|吧|吗|呢|啊|呀|哦|啦|着|中|完毕|成功|失败|发现|接近|撤退|待命|开火|发射|命中|击沉|损伤|中弹|报告|确认|准备|开始|停止|下降|上升|不变|无效|不能|不行|快|艘|号|队|舰|炮|分钟|秒|公里|度|阶段|甲板|舱|区|班)$/.test(leftPart)) return true;
  return false;
}

function isLeadIn(text) {
  const part = text.split(/[，！？]/).pop().trim();
  return /^(?:啊|哎|哎呀|哦|噢|嗯|唔|喂|嘿|听好|听好了|听着|我说|你看|瞧|拜托|拜托了|请|好了|行了|够了|那么|不过|但是|可是|所以|首先|此外|总之|话说回来)$/.test(part);
}

function safeJoin(left, right) {
  const leftPart = left.split(/[，！？]/).pop().trim();
  const rightPart = right.split(/[，！？]/)[0].trim();
  if (!leftPart || !rightPart) return false;
  if (/^(?:不|是|对|没错|当然|那么|但是|不过|可是|所以|首先|此外|况且|总之|毕竟|话说回来)$/u.test(leftPart)) return false;
  // 高置信度的词法/语法连接；这里只处理明显不应加逗号的位置。
  if (/^(?:我|你|他|她|它|谁|这|那|哪|本|该|其|每|各|某|任何|所有|这些|那些|我们|你们|他们|她们|自己)$/u.test(leftPart)) return true;
  if (/(?:的|之|第)$/u.test(leftPart) && !/^(?:是的|好的|对的)$/u.test(leftPart)) return true;
  if (leftPart.length <= 2 && /(?:不|没|未|无|非|别|请|可|能|会|要|将|应|须|被|把|向|从|对|与|和|或|为|在|由|以)$/u.test(leftPart)) return true;
  if (/^(?:的|地|得|着|了|过|起来|下去|出来|进去|上来|下来|一样|一般|似的|和|与|或)$/u.test(rightPart)) return true;
  if (/^(?:一|二|三|四|五|六|七|八|九|十|百|千|万|两|几|数|多|半)[个艘架门发枚台名位条颗座支次组队份种级型式号年月日时分秒公里米度]/u.test(rightPart)) return true;
  if (/^(?:已|已经|依然|仍然|正在|正|即将|开始|继续|停止|结束|完成|返回|接近|突破|消失|上升|下降|受损|健在|出现|到达|达到|掉头|输出|室压|压力|就这样|就在|互为|准备完毕)/u.test(rightPart)) return true;
  if (/(?:完毕|结束|中)$/u.test(rightPart) && /(?:号|舰|舰队|航空队|引擎|机器人|系统|屏蔽区|波动炮)$/u.test(leftPart)) return true;
  if (/^(?:能否|是否|能不能)/u.test(rightPart) && !/(?:长|司令|总统|先生|老师|博士|阁下)$/u.test(leftPart)) return true;
  if (/^(?:大和号|本舰|敌舰|敌机|舰队|航空队|波动引擎|引擎|发动机|波动炮|系统|屏蔽区|力场|机器人)$/u.test(leftPart) && /^(?:能|不能|无法|发射|准备|全员|定期|动力|功率|状态|情况)/u.test(rightPart)) return true;
  if (/^可恶的[「『“].+[」』”]$/u.test(leftPart)) return true;
  return false;
}

function looksInterrogative(text) {
  const visible = text.replace(/[！!？?]+$/u, '');
  return /(?:吗|么|呢|吧|为何|为什么|怎么|怎样|如何|什么|哪(?:个|里|儿|一)|谁|几(?:个|点|时|艘|人|次)?|多少|是否|能否|可否|难道|岂不是|听得到|明白了吗|知道吗|对吗|行吗|可以吗)(?:[，,、]?[^，,。！？!?]{0,8})?$/u.test(visible);
}

function normalizeChinese(text, japanese) {
  if (/\{[^}]*\}|\\[Nn]/.test(text)) return text;
  if (/^♪|♪/.test(japanese) || /^♪|♪/.test(text)) return text;

  let result = text.trim();
  result = result.replace(/\.\.\.+/g, '……');
  result = result.replace(/\?+/g, '？').replace(/!+/g, '！');
  result = result.replace(/…+/g, '……');
  result = result.replace(/\s+([，。！？、：；…—])/g, '$1').replace(/([，。！？、：；…—])\s+/g, '$1');

  const gapExpression = /(?<=[\p{Script=Han}”」』）]) +(?=[“「『（\p{Script=Han}])/u;
  const parts = result.split(gapExpression);
  if (parts.length > 1) {
    const marks = internalJapaneseMarks(japanese);
    // 中文正文不保留用来代替标点的半角空格。日文标点只在数量与中文
    // 分隔点完全对应时采用；其余按中文语法判断逗号或直接连写。
    const separators = Array(parts.length - 1).fill('，');
    for (let index = 0; index < separators.length; index++) {
      if (marks.length === separators.length && marks[index] === '？' && isLeadIn(parts[index])) separators[index] = '，';
      else if (marks.length === separators.length) separators[index] = marks[index];
      else if (safeJoin(parts[index], parts[index + 1])) separators[index] = '';
      else if (safeComma(parts[index], parts[index + 1], separators.length)) separators[index] = '，';
    }
    result = parts[0];
    for (let index = 0; index < separators.length; index++) result += separators[index] + parts[index + 1];
  }

  result = result.replace(/，([！？])/g, '$1').replace(/，{2,}/g, '，');
  result = result.replace(/([一二三四五六七八九十百千0-9]+号)，(?=[一二三四五六七八九十百千0-9]+号)/g, '$1、');
  result = result.replace(/[？！]{2,}$/u, (marks) => marks.includes('？') ? '？' : '！');
  result = result.replace(/。$/u, '');

  const jp = visibleText(japanese);
  if (/[?？]$/.test(jp) && /[!！]$/.test(result) && looksInterrogative(result)) result = result.replace(/[!！]+$/u, '？');
  else if (/[?？]$/.test(jp) && !/[?？！!]$/.test(result)) result += '？';
  else if (/[!！]$/.test(jp) && !/[?？!！…—~～]$/.test(result)) result += '！';
  if (/[!！]$/.test(jp) && /(?:吗|么|呢|为何|为什么|怎么|怎样|如何|什么|哪(?:个|里|儿)|谁|多少|是否|能否|可否|听得到)[!！]$/u.test(result)) {
    result = result.replace(/[!！]+$/u, '？');
  }

  return result;
}

const overrides = new Map([
  ['TV E01|0:02:35.69|0:02:37.19', '「阿武隈」和「岛风」沉没！'],
  ['TV E01|0:03:00.43|0:03:02.60', '进行损管，关闭隔壁，快！'],
  ['TV E01|0:03:16.57|0:03:18.57', '我们已失去操舵能力！正在脱离舰队'],
  ['TV E01|0:04:33.64|0:04:37.41', '两名回收人员正在火星阿卡迪亚港待命'],
  ['TV E01|0:06:45.86|0:06:49.90', '第一舰队即刻终止作战，开始撤退'],
  ['TV E01|0:07:03.42|0:07:04.22', '对准目标！'],
  ['TV E01|0:07:05.42|0:07:06.83', '二号、一号，射击！'],
  ['TV E01|0:08:05.52|0:08:09.38', '古代，我们已付出太多牺牲，但作战已经成功'],
  ['TV E01|0:15:54.99|0:15:58.18', '喂！你们到底是谁？'],
  ['TV E01|0:24:17.16|0:24:19.44', '那艘船名为“大和号”'],
  ['TV E02|0:04:14.29|0:04:20.30', '此外，还有饥荒、暴乱，以及不明有毒植物释放的毒性孢子……'],
  ['TV E02|0:09:13.05|0:09:16.38', '接下来是战术科——古代进'],
  ['TV E02|0:21:45.47|0:21:46.76', '是……是的'],
  ['TV E03|0:09:20.98|0:09:22.64', '这……这里是……？'],
  ['TV E04|0:02:26.09|0:02:26.47', '啊？'],
  ['TV E04|0:04:36.44|0:04:38.44', '轮机舱，报告情况！'],
  ['TV E04|0:11:12.54|0:11:15.29', '我很优秀，交给我，请放心'],
  ['TV E04|0:11:24.26|0:11:25.02', '好，好'],
  ['TV E04|0:11:29.02|0:11:29.46', '好，好'],
  ['TV E04|0:21:30.16|0:21:31.87', '古代去上报情况了'],
  ['TV E05|0:01:33.51|0:01:35.00', '大和号，听得到吗？'],
  ['TV E05|0:10:13.07|0:10:16.86', '是！战术长古代，接任航空队指挥'],
  ['TV E06|0:03:37.75|0:03:40.09', '好了，让他说吧，希斯'],
  ['TV E06|0:04:39.65|0:04:42.15', '你也是吧，副总统？'],
  ['TV E06|0:12:01.05|0:12:04.43', '屏蔽区怎么回事！'],
  ['TV E07|0:03:51.73|0:03:57.94', '我说，在土卫二时，你问过我一个奇怪的问题吧？'],
  ['TV E07|0:20:29.51|0:20:32.59', '我是陪伴大家的岬百合亚～'],
  ['TV E07|0:24:18.16|0:24:23.04', '其口含万千烈焰，其臂持红莲业火'],
  ['TV E09|0:03:04.01|0:03:06.93', '由此可知，加米拉斯使用着与我们相同的数学，'],
  ['TV E09|0:03:06.93|0:03:09.23', '也理解相同的物理学'],
  ['TV E09|0:04:47.32|0:04:47.99', '好——！'],
  ['TV E09|0:07:43.46|0:07:47.05', '篠原、山本二人结束巡逻任务，正在返舰'],
  ['TV E09|0:11:15.05|0:11:18.34', '如果错误持续发生，就必须将你初始化'],
  ['TV E10|0:04:54.33|0:04:58.46', '听好了，正因为你们心存迷惑，眼前万象才会变得纷乱'],
  ['TV E11|0:08:53.99|0:08:57.95', '而且，对于我和失去哥哥的古代来说'],
  ['TV E11|0:13:45.20|0:13:50.20', '然后，是我们拉开了那场战争的序幕'],
  ['TV E14|0:04:08.91|0:04:12.87', '古代一尉，船务长命令你马上交出操纵权'],
  ['TV E15|0:14:37.58|0:14:41.73', '你说总统不在，到底是怎么回事！'],
  ['TV E15|0:22:38.81|0:22:40.82', '两舷鱼雷在干什么！快张开弹幕！'],
  ['TV E16|0:05:40.67|0:05:45.47', '但毕美拉星有望成为人类的第二个地球'],
  ['TV E16|0:05:50.76|0:05:54.52', '请老师指挥我们，一起把这份情报带回地球'],
  ['TV E19|0:11:59.59|0:12:02.88', '被你……被你们'],
  ['TV E21|0:21:48.93|0:21:51.36', '告诉我，你在哪儿……到底在哪儿！'],
  ['TV E22|0:06:09.74|0:06:13.94', '为何一直瞒着我们，伊斯坎达尔和加米拉斯在同一处？'],
  ['TV E23|0:10:13.03|0:10:17.21', '怎么会……竟然把我丢下……这不是真的！'],
  ['TV E23|0:06:35.77|0:06:37.77', '前卫舰队的航母受损！'],
  ['TV E25|0:18:20.65|0:18:23.60', '她明明那么仰慕你，为什么……？'],
  ['TV E26|0:11:44.97|0:11:48.02', '呃……请不要突然这么大声！'],
  ['TV E26|0:16:49.94|0:16:55.29', '相处期间，你向我说起过失忆的事吧'],
  ['TV E26|0:20:07.68|0:20:10.70', '古代……不，是「大和号」'],
  ['星巡的方舟|1:26:53.40|1:26:54.56', '“尼尔瓦雷斯”号沉没了？'],
  ['星巡的方舟|1:34:08.87|1:34:10.08', '敌机就在正上方！嗯？'],
]);

function workLabel(file) {
  if (file === movieFile) return '星巡的方舟';
  const match = path.basename(file).match(/S01E(\d{2})/);
  return `TV E${match[1]}`;
}

function splitBilingualPair(loaded, work, changes, spec) {
  if (work !== spec.work) return false;
  const jpStyle = spec.cnStyle === 'CN-Top' ? 'JP-Top' : 'JP-Main';
  const pairs = loaded.lines.map((line, index) => ({ index, event: parseEvent(line) }))
    .filter(({ event }) => event && event.kind === 'Dialogue' && event.start === spec.start && event.end === spec.end && [spec.cnStyle, jpStyle].includes(event.style));
  if (!pairs.length) {
    const events = loaded.lines.map(parseEvent).filter(Boolean);
    const completed = spec.segments.every((segment) => [spec.cnStyle, jpStyle].every((style) =>
      events.some((event) => event.kind === 'Dialogue' && event.style === style && event.start === segment.start && event.end === segment.end)));
    if (completed) return false;
    throw new Error(`${spec.label}: expected original pair or completed split`);
  }
  if (pairs.length !== 2) throw new Error(`${spec.label}: expected 2 events, found ${pairs.length}`);
  const firstIndex = Math.min(...pairs.map(({ index }) => index));
  const cnSource = pairs.find(({ event }) => event.style === spec.cnStyle).event;
  const jpSource = pairs.find(({ event }) => event.style === jpStyle).event;
  const replacement = spec.segments.flatMap((segment) => [
    { ...cnSource, start: segment.start, end: segment.end, text: segment.cn },
    { ...jpSource, start: segment.start, end: segment.end, text: segment.jp },
  ]);
  for (const { index } of [...pairs].sort((a, b) => b.index - a.index)) loaded.lines.splice(index, 1);
  loaded.lines.splice(firstIndex, 0, ...replacement.map(serializeEvent));
  changes.push([work, spec.start, spec.end, `${spec.cnStyle}/${jpStyle}`, cnSource.text, replacement.map((event) => event.text).join(' | '), jpSource.text, spec.label]);
  return true;
}

function splitE01FleetList(loaded, work, changes) {
  return splitBilingualPair(loaded, work, changes, {
    work: 'TV E01', label: '英文舰种分段时间点 + 官方日文分句', cnStyle: 'CN-Main',
    start: '0:00:50.80', end: '0:00:56.24',
    segments: [
      { start: '0:00:50.80', end: '0:00:52.82', cn: '超弩级宇宙战舰一艘', jp: '超弩級宇宙戦艦 １(ヒト)' },
      { start: '0:00:52.84', end: '0:00:53.86', cn: '战舰七艘', jp: '戦艦 ７' },
      { start: '0:00:53.88', end: '0:00:55.26', cn: '巡洋舰二十二艘', jp: '巡洋艦 ２２(フタジュウフタ)' },
      { start: '0:00:55.26', end: '0:00:56.84', cn: '驱逐舰多艘', jp: '駆逐艦 多数' },
    ],
  });
}

function splitE08Anniversary(loaded, work, changes) {
  return splitBilingualPair(loaded, work, changes, {
    work: 'TV E08', label: '英文呼语时间点 + 官方日文分句', cnStyle: 'CN-Top',
    start: '0:02:57.51', end: '0:03:03.55',
    segments: [
      { start: '0:02:57.51', end: '0:02:58.51', cn: '总统，', jp: '総統' },
      { start: '0:02:58.51', end: '0:03:03.55', cn: '为庆祝加米拉斯帝国千年华诞，暨德拉斯政权建立103周年', jp: 'ガミラス帝国建国千年 ならびに デスラー紀元103年を' },
    ],
  });
}

function splitE08Announcement(loaded, work, changes) {
  if (work !== 'TV E08') return false;
  const start = '0:03:55.61';
  const end = '0:04:01.40';
  const split = '0:03:57.61';
  const pairs = loaded.lines.map((line, index) => ({ index, event: parseEvent(line) }))
    .filter(({ event }) => event && event.kind === 'Dialogue' && event.start === start && event.end === end && ['CN-Top', 'JP-Top'].includes(event.style));
  if (!pairs.length) {
    const already = loaded.lines.map(parseEvent).filter(Boolean).filter((event) =>
      event.kind === 'Dialogue' && event.start === start && event.end === split && ['CN-Top', 'JP-Top'].includes(event.style));
    if (already.length === 2) return false;
    throw new Error('E08 long announcement: expected original pair or completed split');
  }
  if (pairs.length !== 2) throw new Error(`E08 long announcement: expected 2 events, found ${pairs.length}`);

  const firstIndex = Math.min(...pairs.map(({ index }) => index));
  const cnSource = pairs.find(({ event }) => event.style === 'CN-Top').event;
  const jpSource = pairs.find(({ event }) => event.style === 'JP-Top').event;
  const make = (source, nextStart, nextEnd, nextText) => ({ ...source, start: nextStart, end: nextEnd, text: nextText });
  const replacement = [
    make(cnSource, start, split, '小麦哲伦云外缘地带，'),
    make(jpSource, start, split, '小マゼラン外縁部では'),
    make(cnSource, split, end, '也必须警惕来自外宇宙的蛮族入侵'),
    make(jpSource, split, end, '外宇宙からの蛮族侵入も 予断を許しません'),
  ];
  for (const { index } of [...pairs].sort((a, b) => b.index - a.index)) loaded.lines.splice(index, 1);
  loaded.lines.splice(firstIndex, 0, ...replacement.map(serializeEvent));
  changes.push([work, start, end, 'CN-Top/JP-Top', cnSource.text, replacement.map((event) => event.text).join(' | '), jpSource.text, '英文内部时间点 + 日文语义分句']);
  return true;
}

const files = fs.readdirSync(tvDir).filter((name) => name.endsWith('.ass')).sort().map((name) => path.join(tvDir, name));
files.push(movieFile);
const changes = [];
let changedFiles = 0;

for (const file of files) {
  const loaded = readAss(file);
  const work = workLabel(file);
  let fileChanged = splitE01FleetList(loaded, work, changes);
  fileChanged = splitE08Anniversary(loaded, work, changes) || fileChanged;
  fileChanged = splitE08Announcement(loaded, work, changes) || fileChanged;
  const events = loaded.lines.map(parseEvent);
  const jpByAxis = new Map(events.filter((event) => event && event.kind === 'Dialogue' && /^JP-(Main|Top)$/.test(event.style))
    .map((event) => [`${event.start}|${event.end}|${event.style}`, event]));

  for (let index = 0; index < loaded.lines.length; index++) {
    const event = parseEvent(loaded.lines[index]);
    if (!event || event.kind !== 'Dialogue' || !/^CN-(Main|Top)$/.test(event.style)) continue;
    const jpStyle = event.style === 'CN-Top' ? 'JP-Top' : 'JP-Main';
    const jp = jpByAxis.get(`${event.start}|${event.end}|${jpStyle}`);
    if (!jp) continue;
    const key = `${work}|${event.start}|${event.end}`;
    const replacement = overrides.has(key) ? overrides.get(key) : normalizeChinese(event.text, jp.text);
    if (replacement === event.text) continue;
    changes.push([work, event.start, event.end, event.style, event.text, replacement, jp.text, overrides.has(key) ? '人工审校' : '标点标准化']);
    event.text = replacement;
    loaded.lines[index] = serializeEvent(event);
    fileChanged = true;
  }
  if (fileChanged) {
    changedFiles++;
    if (apply) writeAss(file, loaded);
  }
}

fs.mkdirSync(path.dirname(reportFile), { recursive: true });
const tsv = [
  ['作品', '开始', '结束', '样式', '修改前', '修改后', '同轴日文', '修改类型'],
  ...changes,
].map((row) => row.map((cell) => String(cell ?? '').replace(/[\t\r\n]+/g, ' ').trim()).join('\t')).join('\n');
fs.writeFileSync(reportFile, tsv, 'utf8');

console.log(JSON.stringify({ apply, files: files.length, changedFiles, changes: changes.length, reportFile }, null, 2));
